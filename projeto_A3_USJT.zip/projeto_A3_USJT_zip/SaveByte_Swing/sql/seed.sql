-- ============================================================================
-- SaveByte Swing - Dados de exemplo (seed)
-- Executar DEPOIS do schema.sql
-- Senha padrao de todos: 123456 (hash BCrypt)
-- ============================================================================

USE savebyte;

-- ============================================================================
-- CLIENTES (5 clientes de teste)
-- Senha: 123456 -> BCrypt hash
-- ============================================================================
INSERT IGNORE INTO cliente (nome, email, senha, senha_visivel, telefone, endereco, numero, bairro, cidade, estado, cep, criado_em) VALUES
('Simone Almeida',    'simone@teste.com',    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11932525141', 'Rua Jose Antonio Romano', '123', 'Chacaras Reunidas Pilar', 'Pilar do Sul', 'SP', '18188036', NOW()),
('Carlos Oliveira',   'carlos@teste.com',    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11998765432', 'Av. Paulista', '1000', 'Bela Vista', 'Sao Paulo', 'SP', '01310100', NOW()),
('Maria Santos',      'maria@teste.com',     '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '21987654321', 'Rua Copacabana', '500', 'Copacabana', 'Rio de Janeiro', 'RJ', '22050002', NOW()),
('Joao Pedro Silva',  'joao@teste.com',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '31976543210', 'Rua da Bahia', '200', 'Centro', 'Belo Horizonte', 'MG', '30160011', NOW()),
('Ana Carolina Lima', 'ana@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '41965432109', 'Rua XV de Novembro', '300', 'Centro', 'Curitiba', 'PR', '80020310', NOW());

-- ============================================================================
-- 20 RESTAURANTES
-- Senha: 123456 -> BCrypt hash
-- ============================================================================
INSERT IGNORE INTO restaurante (nome, cnpj, email, senha, senha_visivel, telefone, endereco, numero, bairro, cidade, estado, cep, descricao, criado_em) VALUES
('Padaria Pao Quente',        '11.111.111/0001-01', 'padaria@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933331111', 'Rua Augusta',             '120',  'Consolacao',      'Sao Paulo',       'SP', '01304001', 'Padaria artesanal com paes frescos todos os dias. Evitamos desperdicio vendendo paes do dia com desconto!', NOW()),
('Sushi Zen',                  '22.222.222/0001-02', 'sushi@teste.com',         '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933332222', 'Rua Liberdade',           '88',   'Liberdade',       'Sao Paulo',       'SP', '01503000', 'Sushi fresco com ingredientes selecionados. Combos do dia com ate 50% de desconto!', NOW()),
('Cantina da Nonna',           '33.333.333/0001-03', 'cantina@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933333333', 'Rua Bela Cintra',         '456',  'Jardins',         'Sao Paulo',       'SP', '01415000', 'Massas caseiras italianas feitas com amor. Porções generosas e sabor de verdade.', NOW()),
('Burger House',               '44.444.444/0001-04', 'burger@teste.com',        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933334444', 'Av. Brigadeiro Faria Lima','1500', 'Pinheiros',       'Sao Paulo',       'SP', '05426200', 'Hamburguer artesanal com blend exclusivo. Batata rustica e milkshakes incriveis.', NOW()),
('Acai da Praia',              '55.555.555/0001-05', 'acai@teste.com',          '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '21933335555', 'Av. Atlantica',           '2000', 'Copacabana',      'Rio de Janeiro',  'RJ', '22021001', 'Acai puro da Amazonia com frutas frescas e granola artesanal.', NOW()),
('Churrascaria Fogo de Chao',  '66.666.666/0001-06', 'churrascaria@teste.com',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933336666', 'Av. Santo Amaro',         '800',  'Vila Olimpia',    'Sao Paulo',       'SP', '04506000', 'Carnes nobres na brasa, rodizio completo com buffet de saladas e acompanhamentos.', NOW()),
('Cafe & Cia',                 '77.777.777/0001-07', 'cafe@teste.com',          '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933337777', 'Rua Oscar Freire',        '300',  'Jardins',         'Sao Paulo',       'SP', '01426001', 'Cafes especiais, bolos caseiros e lanches leves. O lugar perfeito para uma pausa.', NOW()),
('Pizzaria Napoli',            '88.888.888/0001-08', 'pizza@teste.com',         '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933338888', 'Rua Mourato Coelho',      '150',  'Vila Madalena',   'Sao Paulo',       'SP', '05417010', 'Pizza napolitana assada em forno a lenha. Massa fermentada por 72 horas.', NOW()),
('Restaurante Mineiro',        '99.999.999/0001-09', 'mineiro@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '31933339999', 'Rua Espirito Santo',      '600',  'Centro',          'Belo Horizonte',  'MG', '30160030', 'Comida mineira de verdade: feijao tropeiro, frango com quiabo, tutu de feijao.', NOW()),
('Taco Loco',                  '10.101.010/0001-10', 'taco@teste.com',          '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933340000', 'Rua dos Pinheiros',       '700',  'Pinheiros',       'Sao Paulo',       'SP', '05422012', 'Tacos, burritos e nachos autenticos mexicanos. Guacamole feito na hora!', NOW()),
('Doceria Sweet',              '11.121.314/0001-11', 'doces@teste.com',         '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933341111', 'Rua Pamplona',            '250',  'Jardim Paulista', 'Sao Paulo',       'SP', '01405100', 'Doces finos, tortas e sobremesas artesanais. Brigadeiro gourmet e bolo no pote.', NOW()),
('Poke Bowl Hawaii',           '12.131.415/0001-12', 'poke@teste.com',          '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933342222', 'Rua Cardeal Arcoverde',   '400',  'Pinheiros',       'Sao Paulo',       'SP', '05407003', 'Bowls frescos e saudaveis com peixe, frutas e molhos especiais do Hawaii.', NOW()),
('Emporio Natural',            '13.141.516/0001-13', 'emporio@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933343333', 'Rua Harmonia',            '50',   'Vila Madalena',   'Sao Paulo',       'SP', '05435000', 'Alimentacao saudavel, sucos detox, saladas e wraps. 100% natural.', NOW()),
('Coxinha & Companhia',        '14.151.617/0001-14', 'coxinha@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933344444', 'Rua Vergueiro',           '1200', 'Liberdade',       'Sao Paulo',       'SP', '01504001', 'Salgados artesanais: coxinha, risole, bolinha de queijo. Tudo feito na hora!', NOW()),
('Sorveteria Gelato',          '15.161.718/0001-15', 'gelato@teste.com',        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '21933345555', 'Rua Visconde de Piraja',  '550',  'Ipanema',         'Rio de Janeiro',  'RJ', '22410003', 'Gelato italiano artesanal com frutas frescas. Mais de 30 sabores disponiveis.', NOW()),
('Pastelaria do Ze',           '16.171.819/0001-16', 'pastel@teste.com',        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933346666', 'Rua Galvao Bueno',        '80',   'Liberdade',       'Sao Paulo',       'SP', '01506000', 'Pasteis gigantes crocantes com recheios tradicionais e inovadores. Caldo de cana gelado.', NOW()),
('Bistrô Francês',            '17.181.920/0001-17', 'bistro@teste.com',        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933347777', 'Alameda Santos',          '900',  'Cerqueira Cesar', 'Sao Paulo',       'SP', '01418100', 'Gastronomia francesa com toque brasileiro. Crepes, quiches e vinhos selecionados.', NOW()),
('Acaraje da Bahia',           '18.192.021/0001-18', 'acaraje@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '71933348888', 'Rua Chile',               '35',   'Pelourinho',      'Salvador',        'BA', '40020000', 'Sabores da Bahia: acaraje, abara, vatapa e cocada. Tempero baiano de verdade!', NOW()),
('Yakisoba Express',           '19.202.122/0001-19', 'yakisoba@teste.com',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933349999', 'Rua Thomaz Gonzaga',      '60',   'Liberdade',       'Sao Paulo',       'SP', '01506020', 'Yakisoba, gyoza e lamem feitos na hora no wok. Rapidez e sabor oriental.', NOW()),
('Marmitaria Sabor Caseiro',   '20.212.223/0001-20', 'marmita@teste.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '123456', '11933350000', 'Rua Consolacao',          '350',  'Consolacao',      'Sao Paulo',       'SP', '01302000', 'Marmitas caseiras com comida de verdade. Arroz, feijao, carne e salada fresquinha.', NOW());

-- ============================================================================
-- PRODUTOS (variados por restaurante)
-- ============================================================================

-- Padaria Pao Quente (id depende da insercao, vamos usar variavel)
SET @r1 = (SELECT id FROM restaurante WHERE email = 'padaria@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r1, 'Pao Frances (10 unidades)',    'Pao frances quentinho do dia',           'Padaria',    5.00,  2.50, 30, 1, NOW()),
(@r1, 'Bolo de Cenoura',             'Bolo caseiro com cobertura de chocolate', 'Padaria',   28.00, 15.00, 8, 1, NOW()),
(@r1, 'Croissant de Chocolate',      'Croissant folhado com chocolate belga',   'Padaria',   12.00,  7.00, 15, 1, NOW()),
(@r1, 'Torta de Frango',             'Torta salgada de frango com catupiry',    'Salgados',  35.00, 20.00, 5, 1, NOW()),
(@r1, 'Rosca de Polvilho',           'Rosca crocante feita com polvilho',       'Padaria',    8.00,  4.50, 20, 1, NOW());

SET @r2 = (SELECT id FROM restaurante WHERE email = 'sushi@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r2, 'Combo Sushi 20 pecas',        'Mix de sushis variados',                  'Japonesa',  60.00, 35.00, 10, 1, NOW()),
(@r2, 'Temaki Salmao',               'Temaki de salmao com cream cheese',       'Japonesa',  28.00, 18.00, 12, 1, NOW()),
(@r2, 'Sashimi Salmao 10 fatias',    'Fatias frescas de salmao',                'Japonesa',  45.00, 28.00, 8, 1, NOW()),
(@r2, 'Hot Roll 8 pecas',            'Sushi empanado e frito crocante',         'Japonesa',  32.00, 20.00, 15, 1, NOW()),
(@r2, 'Missoshiru',                  'Sopa japonesa de miso com tofu',          'Japonesa',  15.00,  9.00, 20, 1, NOW());

SET @r3 = (SELECT id FROM restaurante WHERE email = 'cantina@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r3, 'Lasanha Bolonhesa',           'Lasanha com molho bolonhesa e bechamel',  'Italiana',  42.00, 25.00, 6, 1, NOW()),
(@r3, 'Espaguete Carbonara',         'Massa com bacon, ovo e parmesao',         'Italiana',  38.00, 22.00, 8, 1, NOW()),
(@r3, 'Ravioli de Ricota',           'Ravioli recheado com ricota e espinafre', 'Italiana',  40.00, 24.00, 7, 1, NOW()),
(@r3, 'Bruschetta Caprese',          'Pao italiano com tomate, mussarela e manjericao', 'Italiana', 22.00, 14.00, 10, 1, NOW()),
(@r3, 'Tiramisu',                    'Sobremesa italiana com mascarpone e cafe','Italiana',  25.00, 16.00, 5, 1, NOW());

SET @r4 = (SELECT id FROM restaurante WHERE email = 'burger@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r4, 'Smash Burger Duplo',          'Dois blends smash com cheddar e bacon',   'Hamburgueria', 38.00, 24.00, 12, 1, NOW()),
(@r4, 'Chicken Burger',              'Hamburguer de frango empanado',           'Hamburgueria', 32.00, 20.00, 10, 1, NOW()),
(@r4, 'Batata Rustica',              'Batata com casca, alecrim e flor de sal', 'Hamburgueria', 18.00, 11.00, 15, 1, NOW()),
(@r4, 'Milkshake Nutella',           'Milkshake cremoso de Nutella',            'Bebidas',      22.00, 14.00, 8, 1, NOW()),
(@r4, 'Onion Rings',                 'Aneis de cebola empanados e crocantes',   'Hamburgueria', 16.00, 10.00, 12, 1, NOW());

SET @r5 = (SELECT id FROM restaurante WHERE email = 'acai@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r5, 'Acai 500ml',                  'Acai puro com banana e granola',          'Acai',      25.00, 16.00, 20, 1, NOW()),
(@r5, 'Acai 700ml Premium',          'Acai com morango, kiwi e leite ninho',    'Acai',      35.00, 22.00, 15, 1, NOW()),
(@r5, 'Bowl de Pitaya',              'Pitaya com frutas tropicais e mel',       'Acai',      30.00, 19.00, 10, 1, NOW()),
(@r5, 'Suco Detox Verde',            'Couve, limao, gengibre e maca',           'Bebidas',   15.00,  9.00, 25, 1, NOW());

SET @r6 = (SELECT id FROM restaurante WHERE email = 'churrascaria@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r6, 'Picanha na Brasa 400g',       'Picanha premium grelhada no ponto',       'Churrasco', 65.00, 40.00, 8, 1, NOW()),
(@r6, 'Costela Barbecue',            'Costela defumada com molho barbecue',     'Churrasco', 55.00, 35.00, 6, 1, NOW()),
(@r6, 'Fraldinha Acebolada',         'Fraldinha grelhada com cebola caramelizada','Churrasco',48.00, 30.00, 7, 1, NOW()),
(@r6, 'Farofa Especial',             'Farofa com bacon, ovo e banana',          'Acompanhamento', 15.00, 9.00, 15, 1, NOW());

SET @r7 = (SELECT id FROM restaurante WHERE email = 'cafe@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r7, 'Cappuccino Especial',         'Cappuccino com canela e chantilly',       'Cafeteria', 16.00, 10.00, 20, 1, NOW()),
(@r7, 'Bolo Red Velvet (fatia)',     'Fatia de bolo red velvet com cream cheese','Cafeteria', 18.00, 11.00, 8, 1, NOW()),
(@r7, 'Pao de Queijo (6 unidades)',  'Pao de queijo mineiro quentinho',         'Cafeteria', 12.00,  7.00, 25, 1, NOW()),
(@r7, 'Cookie Americano',            'Cookie gigante com gotas de chocolate',    'Cafeteria', 10.00,  6.00, 15, 1, NOW());

SET @r8 = (SELECT id FROM restaurante WHERE email = 'pizza@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r8, 'Pizza Margherita',            'Molho de tomate, mussarela e manjericao', 'Pizza',     48.00, 30.00, 10, 1, NOW()),
(@r8, 'Pizza Calabresa',             'Calabresa, cebola e azeitona',            'Pizza',     45.00, 28.00, 10, 1, NOW()),
(@r8, 'Pizza Quatro Queijos',        'Mussarela, gorgonzola, parmesao e brie',  'Pizza',     55.00, 35.00, 8, 1, NOW()),
(@r8, 'Calzone de Presunto',         'Calzone recheado com presunto e queijo',  'Pizza',     35.00, 22.00, 6, 1, NOW());

SET @r9 = (SELECT id FROM restaurante WHERE email = 'mineiro@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r9, 'Feijao Tropeiro',             'Feijao com farinha, bacon, ovo e couve',  'Mineira',   35.00, 22.00, 10, 1, NOW()),
(@r9, 'Frango com Quiabo',           'Frango caipira com quiabo refogado',      'Mineira',   38.00, 24.00, 8, 1, NOW()),
(@r9, 'Tutu de Feijao',              'Puro feijao com farinha e temperos',      'Mineira',   28.00, 18.00, 12, 1, NOW()),
(@r9, 'Pao de Queijo Grande',        'Pao de queijo mineiro tradicional',       'Mineira',   10.00,  6.00, 30, 1, NOW());

SET @r10 = (SELECT id FROM restaurante WHERE email = 'taco@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r10, 'Taco de Carne',              'Taco com carne moida, alface e queijo',   'Mexicana',  22.00, 14.00, 15, 1, NOW()),
(@r10, 'Burrito Grande',             'Burrito recheado com frango e guacamole',  'Mexicana',  32.00, 20.00, 10, 1, NOW()),
(@r10, 'Nachos com Cheddar',         'Nachos crocantes com cheddar e jalapeño', 'Mexicana',  25.00, 16.00, 12, 1, NOW()),
(@r10, 'Guacamole Fresco',           'Guacamole feito na hora com totopos',     'Mexicana',  20.00, 12.00, 8, 1, NOW());

SET @r11 = (SELECT id FROM restaurante WHERE email = 'doces@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r11, 'Brigadeiro Gourmet (10 un)', 'Brigadeiro de chocolate belga',           'Doces',     30.00, 18.00, 12, 1, NOW()),
(@r11, 'Bolo no Pote Morango',       'Bolo de morango com chantilly no pote',   'Doces',     18.00, 11.00, 10, 1, NOW()),
(@r11, 'Torta de Limao',             'Torta de limao siciliano com merengue',   'Doces',     45.00, 28.00, 5, 1, NOW()),
(@r11, 'Brownie com Nozes',          'Brownie intenso com nozes pecã',          'Doces',     15.00,  9.00, 15, 1, NOW());

SET @r12 = (SELECT id FROM restaurante WHERE email = 'poke@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r12, 'Poke Salmao',                'Bowl com salmao, arroz, manga e edamame', 'Saudavel',  38.00, 24.00, 10, 1, NOW()),
(@r12, 'Poke Atum',                  'Bowl com atum, abacate e gergelim',       'Saudavel',  40.00, 25.00, 8, 1, NOW()),
(@r12, 'Poke Vegano',                'Bowl com tofu, cogumelos e legumes',      'Saudavel',  32.00, 20.00, 12, 1, NOW());

SET @r13 = (SELECT id FROM restaurante WHERE email = 'emporio@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r13, 'Salada Caesar',              'Alface romana, croutons, parmesao e molho Caesar', 'Saudavel', 28.00, 17.00, 10, 1, NOW()),
(@r13, 'Wrap de Frango Grelhado',    'Wrap integral com frango, alface e tomate','Saudavel', 25.00, 15.00, 12, 1, NOW()),
(@r13, 'Suco Verde 500ml',           'Couve, abacaxi, hortela e limao',         'Bebidas',  14.00,  8.00, 20, 1, NOW());

SET @r14 = (SELECT id FROM restaurante WHERE email = 'coxinha@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r14, 'Coxinha de Frango (5 un)',   'Coxinha crocante com catupiry',           'Salgados',  25.00, 15.00, 20, 1, NOW()),
(@r14, 'Risole de Carne',            'Risole recheado com carne moida',         'Salgados',   6.00,  3.50, 25, 1, NOW()),
(@r14, 'Bolinha de Queijo (10 un)',  'Bolinhas de queijo crocantes',            'Salgados',  20.00, 12.00, 15, 1, NOW()),
(@r14, 'Kibe Frito',                 'Kibe de carne com hortela',               'Salgados',   7.00,  4.00, 18, 1, NOW());

SET @r15 = (SELECT id FROM restaurante WHERE email = 'gelato@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r15, 'Gelato Pistache (2 bolas)',  'Gelato artesanal de pistache siciliano',  'Sorvetes',  22.00, 14.00, 15, 1, NOW()),
(@r15, 'Gelato Frutas Vermelhas',    'Mix de morango, framboesa e mirtilo',     'Sorvetes',  20.00, 12.00, 12, 1, NOW()),
(@r15, 'Sundae de Chocolate',        'Sorvete com calda quente e amendoim',     'Sorvetes',  25.00, 16.00, 10, 1, NOW());

SET @r16 = (SELECT id FROM restaurante WHERE email = 'pastel@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r16, 'Pastel de Carne',            'Pastel gigante de carne moida',           'Salgados',  12.00,  7.00, 20, 1, NOW()),
(@r16, 'Pastel de Queijo',           'Pastel crocante com queijo derretido',    'Salgados',  10.00,  6.00, 25, 1, NOW()),
(@r16, 'Pastel de Palmito',          'Pastel com palmito e catupiry',           'Salgados',  14.00,  8.00, 15, 1, NOW()),
(@r16, 'Caldo de Cana 500ml',        'Caldo de cana gelado puro',              'Bebidas',    8.00,  5.00, 30, 1, NOW());

SET @r17 = (SELECT id FROM restaurante WHERE email = 'bistro@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r17, 'Crepe de Nutella',           'Crepe frances com Nutella e morangos',    'Francesa',  28.00, 18.00, 8, 1, NOW()),
(@r17, 'Quiche Lorraine',            'Quiche de bacon com queijo gruyere',      'Francesa',  32.00, 20.00, 6, 1, NOW()),
(@r17, 'Croissant de Presunto',      'Croissant recheado com presunto e queijo','Francesa',  18.00, 11.00, 10, 1, NOW());

SET @r18 = (SELECT id FROM restaurante WHERE email = 'acaraje@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r18, 'Acaraje Completo',           'Acaraje com vatapa, caruru e camarao',    'Baiana',    20.00, 12.00, 15, 1, NOW()),
(@r18, 'Abara',                      'Bolinho de feijao cozido no vapor',       'Baiana',    15.00,  9.00, 12, 1, NOW()),
(@r18, 'Cocada (3 unidades)',        'Cocada branca e preta artesanal',         'Baiana',    12.00,  7.00, 20, 1, NOW());

SET @r19 = (SELECT id FROM restaurante WHERE email = 'yakisoba@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r19, 'Yakisoba Tradicional',       'Yakisoba de legumes, frango e carne',     'Oriental',  32.00, 20.00, 12, 1, NOW()),
(@r19, 'Gyoza (8 unidades)',         'Pasteis japoneses grelhados',             'Oriental',  25.00, 15.00, 10, 1, NOW()),
(@r19, 'Lamem de Frango',            'Sopa de lamem com frango e ovo',          'Oriental',  28.00, 18.00, 8, 1, NOW());

SET @r20 = (SELECT id FROM restaurante WHERE email = 'marmita@teste.com');
INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, criado_em) VALUES
(@r20, 'Marmita Completa',           'Arroz, feijao, bife, salada e farofa',    'Marmitaria', 25.00, 15.00, 20, 1, NOW()),
(@r20, 'Marmita Fitness',            'Arroz integral, frango grelhado e legumes','Marmitaria',28.00, 18.00, 15, 1, NOW()),
(@r20, 'Marmita Vegetariana',        'Arroz, feijao, legumes e ovo cozido',     'Marmitaria', 22.00, 14.00, 12, 1, NOW()),
(@r20, 'Sopa de Legumes 500ml',      'Sopa caseira de legumes da estacao',      'Marmitaria', 15.00,  9.00, 18, 1, NOW());

-- ============================================================================
-- COMBOS
-- ============================================================================
INSERT INTO combo (restaurante_id, nome, descricao, preco, quantidade, ativo, criado_em) VALUES
(@r1,  'Combo Cafe da Manha',     '5 paes + bolo de cenoura + 2 croissants',        30.00, 10, 1, NOW()),
(@r2,  'Combo Sushi Premium',     '20 sushis + 2 temakis + missoshiru',             65.00,  8, 1, NOW()),
(@r4,  'Combo Burger Duplo',      '2 smash burgers + batata rustica + milkshake',   55.00, 10, 1, NOW()),
(@r5,  'Combo Acai Familia',      '2 acais 500ml + 1 bowl de pitaya',               50.00,  8, 1, NOW()),
(@r8,  'Combo Pizza Noite',       '1 pizza margherita + 1 pizza calabresa',          50.00,  6, 1, NOW()),
(@r10, 'Combo Mexicano Festa',    '4 tacos + 1 burrito + nachos + guacamole',       65.00,  5, 1, NOW()),
(@r14, 'Combo Salgados Festa',    '5 coxinhas + 10 bolinhas + 5 risoles',           40.00, 10, 1, NOW()),
(@r16, 'Combo Pastel + Cana',     '3 pasteis (carne, queijo, palmito) + caldo cana',22.00, 15, 1, NOW()),
(@r20, 'Combo Semana Fit',        '5 marmitas fitness (segunda a sexta)',            80.00,  5, 1, NOW()),
(@r7,  'Combo Tarde Especial',    '1 cappuccino + 1 bolo red velvet + 3 pao de queijo', 25.00, 8, 1, NOW());

-- ============================================================================
-- PEDIDOS (vendas simuladas com datas variadas)
-- ============================================================================

-- Cliente 1 (Simone) compra na Padaria
SET @c1 = (SELECT id FROM cliente WHERE email = 'simone@teste.com');
INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, tipo_entrega, forma_pagamento, status_pagamento) VALUES
(@c1, @r1, DATE_SUB(NOW(), INTERVAL 15 DAY), 'ENTREGUE', 17.50, 'RETIRADA', 'PIX', 'PAGO'),
(@c1, @r2, DATE_SUB(NOW(), INTERVAL 12 DAY), 'ENTREGUE', 53.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c1, @r4, DATE_SUB(NOW(), INTERVAL 5 DAY),  'ENTREGUE', 59.00, 'RETIRADA', 'NA_ENTREGA', 'PAGO'),
(@c1, @r11, DATE_SUB(NOW(), INTERVAL 2 DAY), 'CONFIRMADO', 29.00, 'ENTREGA', 'PIX', 'PAGO');

-- Itens do pedido Simone na Padaria
SET @ped1 = (SELECT id FROM pedido WHERE cliente_id = @c1 AND restaurante_id = @r1 ORDER BY id DESC LIMIT 1);
SET @prod_pao = (SELECT id FROM produto WHERE restaurante_id = @r1 AND nome LIKE 'Pao Frances%' LIMIT 1);
SET @prod_crois = (SELECT id FROM produto WHERE restaurante_id = @r1 AND nome LIKE 'Croissant%' LIMIT 1);
INSERT INTO pedido_item (pedido_id, produto_id, descricao, quantidade, preco_unitario) VALUES
(@ped1, @prod_pao, 'Pao Frances (10 unidades)', 2, 2.50),
(@ped1, @prod_crois, 'Croissant de Chocolate', 1, 7.00);

-- Cliente 2 (Carlos) compra no Burger e no Sushi
SET @c2 = (SELECT id FROM cliente WHERE email = 'carlos@teste.com');
INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, tipo_entrega, forma_pagamento, status_pagamento) VALUES
(@c2, @r4, DATE_SUB(NOW(), INTERVAL 10 DAY), 'ENTREGUE', 48.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c2, @r2, DATE_SUB(NOW(), INTERVAL 7 DAY),  'ENTREGUE', 35.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c2, @r6, DATE_SUB(NOW(), INTERVAL 3 DAY),  'CONFIRMADO', 75.00, 'RETIRADA', 'NA_ENTREGA', 'PENDENTE'),
(@c2, @r8, DATE_SUB(NOW(), INTERVAL 1 DAY),  'PENDENTE', 58.00, 'ENTREGA', 'PIX', 'PAGO');

-- Cliente 3 (Maria) compra no Acai e Gelato
SET @c3 = (SELECT id FROM cliente WHERE email = 'maria@teste.com');
INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, tipo_entrega, forma_pagamento, status_pagamento) VALUES
(@c3, @r5, DATE_SUB(NOW(), INTERVAL 20 DAY), 'ENTREGUE', 38.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c3, @r15, DATE_SUB(NOW(), INTERVAL 14 DAY), 'ENTREGUE', 26.00, 'RETIRADA', 'NA_ENTREGA', 'PAGO'),
(@c3, @r5, DATE_SUB(NOW(), INTERVAL 8 DAY),  'ENTREGUE', 50.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c3, @r10, DATE_SUB(NOW(), INTERVAL 4 DAY), 'CONFIRMADO', 34.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c3, @r18, DATE_SUB(NOW(), INTERVAL 1 DAY), 'PENDENTE', 21.00, 'ENTREGA', 'NA_ENTREGA', 'PENDENTE');

-- Cliente 4 (Joao) compra em varios
SET @c4 = (SELECT id FROM cliente WHERE email = 'joao@teste.com');
INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, tipo_entrega, forma_pagamento, status_pagamento) VALUES
(@c4, @r9,  DATE_SUB(NOW(), INTERVAL 18 DAY), 'ENTREGUE', 46.00, 'RETIRADA', 'NA_ENTREGA', 'PAGO'),
(@c4, @r3,  DATE_SUB(NOW(), INTERVAL 13 DAY), 'ENTREGUE', 49.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c4, @r7,  DATE_SUB(NOW(), INTERVAL 9 DAY),  'ENTREGUE', 21.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c4, @r17, DATE_SUB(NOW(), INTERVAL 6 DAY),  'ENTREGUE', 38.00, 'RETIRADA', 'CARTAO', 'PAGO'),
(@c4, @r20, DATE_SUB(NOW(), INTERVAL 2 DAY),  'CONFIRMADO', 33.00, 'ENTREGA', 'PIX', 'PAGO');

-- Cliente 5 (Ana) compra em varios
SET @c5 = (SELECT id FROM cliente WHERE email = 'ana@teste.com');
INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, tipo_entrega, forma_pagamento, status_pagamento) VALUES
(@c5, @r12, DATE_SUB(NOW(), INTERVAL 16 DAY), 'ENTREGUE', 49.00, 'ENTREGA', 'PIX', 'PAGO'),
(@c5, @r13, DATE_SUB(NOW(), INTERVAL 11 DAY), 'ENTREGUE', 32.00, 'RETIRADA', 'NA_ENTREGA', 'PAGO'),
(@c5, @r14, DATE_SUB(NOW(), INTERVAL 7 DAY),  'ENTREGUE', 27.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c5, @r16, DATE_SUB(NOW(), INTERVAL 4 DAY),  'ENTREGUE', 21.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c5, @r19, DATE_SUB(NOW(), INTERVAL 1 DAY),  'PENDENTE', 35.00, 'RETIRADA', 'PIX', 'PAGO');

-- Mais pedidos para aumentar o volume
INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, tipo_entrega, forma_pagamento, status_pagamento) VALUES
(@c1, @r8,  DATE_SUB(NOW(), INTERVAL 25 DAY), 'ENTREGUE', 63.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c2, @r3,  DATE_SUB(NOW(), INTERVAL 22 DAY), 'ENTREGUE', 41.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c3, @r7,  DATE_SUB(NOW(), INTERVAL 19 DAY), 'ENTREGUE', 24.00, 'RETIRADA', 'NA_ENTREGA', 'PAGO'),
(@c4, @r14, DATE_SUB(NOW(), INTERVAL 17 DAY), 'ENTREGUE', 30.00, 'ENTREGA', 'PIX', 'PAGO'),
(@c5, @r1,  DATE_SUB(NOW(), INTERVAL 15 DAY), 'ENTREGUE', 20.00, 'RETIRADA', 'NA_ENTREGA', 'PAGO'),
(@c1, @r10, DATE_SUB(NOW(), INTERVAL 11 DAY), 'ENTREGUE', 46.00, 'ENTREGA', 'CARTAO', 'PAGO'),
(@c2, @r9,  DATE_SUB(NOW(), INTERVAL 9 DAY),  'ENTREGUE', 42.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c3, @r20, DATE_SUB(NOW(), INTERVAL 6 DAY),  'ENTREGUE', 33.00, 'ENTREGA', 'NA_ENTREGA', 'PAGO'),
(@c4, @r5,  DATE_SUB(NOW(), INTERVAL 3 DAY),  'CONFIRMADO', 22.00, 'RETIRADA', 'PIX', 'PAGO'),
(@c5, @r4,  NOW(),                             'PENDENTE', 38.00, 'ENTREGA', 'CARTAO', 'PENDENTE'),
(@c1, @r15, DATE_SUB(NOW(), INTERVAL 8 DAY),  'CANCELADO', 28.00, 'RETIRADA', 'PIX', 'ESTORNADO'),
(@c3, @r6,  DATE_SUB(NOW(), INTERVAL 5 DAY),  'CANCELADO', 40.00, 'ENTREGA', 'CARTAO', 'ESTORNADO');

-- ============================================================================
-- PROJETOS DE EXEMPLO (requisito do professor - ODS)
-- ============================================================================
INSERT IGNORE INTO projetos (codigo, descricao, ods, nome_responsavel, telefone, data_criacao, status) VALUES
('PRJ-001', 'Distribuicao de alimentos excedentes para comunidades carentes do centro de SP', 'ODS 2 - Fome Zero', 'Prof. Ricardo Mendes', '11999001122', DATE_SUB(CURDATE(), INTERVAL 60 DAY), 'Em andamento'),
('PRJ-002', 'Campanha de conscientizacao sobre desperdicio alimentar em escolas publicas', 'ODS 12 - Consumo e Producao Responsaveis', 'Profa. Lucia Ferreira', '11999003344', DATE_SUB(CURDATE(), INTERVAL 45 DAY), 'Em andamento'),
('PRJ-003', 'Parceria com ONGs para coleta de alimentos em restaurantes parceiros do SaveByte', 'ODS 2 - Fome Zero', 'Ana Paula Costa', '11999005566', DATE_SUB(CURDATE(), INTERVAL 30 DAY), 'Em andamento'),
('PRJ-004', 'Sistema de logistica reversa para embalagens de alimentos', 'ODS 12 - Consumo e Producao Responsaveis', 'Marcos Vieira', '11999007788', DATE_SUB(CURDATE(), INTERVAL 90 DAY), 'Concluido'),
('PRJ-005', 'Programa de educacao alimentar em comunidades vulneraveis', 'ODS 3 - Saude e Bem-Estar', 'Dra. Camila Rocha', '11999009900', DATE_SUB(CURDATE(), INTERVAL 15 DAY), 'Em andamento');
