-- ============================================================================
-- SaveByte Swing - Script SQL completo
-- Cria o banco 'savebyte' e todas as tabelas necessarias
--
-- COMO USAR:
--   1. Abra o MySQL Workbench (ou terminal MySQL)
--   2. Execute este arquivo inteiro
--   3. Pronto: banco, tabelas e admin padrao serao criados
--
-- Se o banco ja existir, as tabelas sao criadas apenas se nao existirem.
-- Dados existentes NAO sao apagados.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS savebyte
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE savebyte;

-- ============================================================================
-- TABELAS DO SISTEMA FOOD RESCUE
-- ============================================================================

CREATE TABLE IF NOT EXISTS cliente (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    nome        VARCHAR(120) NOT NULL,
    email       VARCHAR(120) NOT NULL,
    senha       VARCHAR(60)  NOT NULL,
    telefone    VARCHAR(20)  NULL,
    endereco    VARCHAR(200) NULL,
    numero      VARCHAR(20)  NULL,
    bairro      VARCHAR(80)  NULL,
    cidade      VARCHAR(80)  NULL,
    estado      CHAR(2)      NULL,
    cep         VARCHAR(10)  NULL,
    imagem_url  VARCHAR(500) NULL,
    criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_cliente_email (email)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS restaurante (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    nome        VARCHAR(120) NOT NULL,
    cnpj        VARCHAR(18)  NULL,
    email       VARCHAR(120) NOT NULL,
    senha       VARCHAR(60)  NOT NULL,
    telefone    VARCHAR(20)  NULL,
    endereco    VARCHAR(200) NULL,
    numero      VARCHAR(10)  NULL,
    complemento VARCHAR(80)  NULL,
    bairro      VARCHAR(80)  NULL,
    cidade      VARCHAR(80)  NULL,
    estado      CHAR(2)      NULL,
    cep         VARCHAR(10)  NULL,
    descricao   TEXT         NULL,
    imagem_url  VARCHAR(500) NULL,
    criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_restaurante_email (email)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS produto (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    restaurante_id BIGINT        NOT NULL,
    nome           VARCHAR(120)  NOT NULL,
    descricao      TEXT          NULL,
    categoria      VARCHAR(50)   NULL,
    preco_original DECIMAL(10,2) NOT NULL,
    preco_desconto DECIMAL(10,2) NOT NULL,
    quantidade     INT           NOT NULL DEFAULT 0,
    ativo          TINYINT(1)    NOT NULL DEFAULT 1,
    imagem_url     VARCHAR(500)  NULL,
    criado_em      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY fk_produto_restaurante (restaurante_id),
    CONSTRAINT fk_produto_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS combo (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    restaurante_id BIGINT        NOT NULL,
    nome           VARCHAR(120)  NOT NULL,
    descricao      TEXT          NULL,
    preco          DECIMAL(10,2) NOT NULL,
    quantidade     INT           NOT NULL DEFAULT 0,
    ativo          TINYINT(1)    NOT NULL DEFAULT 1,
    imagem_url     VARCHAR(500)  NULL,
    criado_em      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY fk_combo_restaurante (restaurante_id),
    CONSTRAINT fk_combo_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS combo_item (
    id         BIGINT NOT NULL AUTO_INCREMENT,
    combo_id   BIGINT NOT NULL,
    produto_id BIGINT NOT NULL,
    quantidade INT    NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY fk_ci_combo (combo_id),
    KEY fk_ci_produto (produto_id),
    CONSTRAINT fk_ci_combo FOREIGN KEY (combo_id)
        REFERENCES combo (id),
    CONSTRAINT fk_ci_produto FOREIGN KEY (produto_id)
        REFERENCES produto (id)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS pedido (
    id               BIGINT        NOT NULL AUTO_INCREMENT,
    cliente_id       BIGINT        NOT NULL,
    restaurante_id   BIGINT        NOT NULL,
    data_pedido      DATETIME      NOT NULL,
    status           VARCHAR(20)   NOT NULL DEFAULT 'PENDENTE',
    valor_total      DECIMAL(10,2) NOT NULL,
    observacao       VARCHAR(500)  NULL,
    tipo_entrega     VARCHAR(20)   NULL,
    endereco_entrega VARCHAR(300)  NULL,
    forma_pagamento  VARCHAR(20)   NULL,
    status_pagamento VARCHAR(20)   NULL,
    cartao_final     VARCHAR(4)    NULL,
    valor_dinheiro   DECIMAL(10,2) NULL,
    troco            DECIMAL(10,2) NULL,
    PRIMARY KEY (id),
    KEY fk_pedido_cliente (cliente_id),
    KEY fk_pedido_restaurante (restaurante_id),
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (cliente_id)
        REFERENCES cliente (id),
    CONSTRAINT fk_pedido_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS pedido_item (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    pedido_id      BIGINT        NOT NULL,
    produto_id     BIGINT        NULL,
    combo_id       BIGINT        NULL,
    descricao      VARCHAR(200)  NOT NULL,
    quantidade     INT           NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (id),
    KEY fk_pi_pedido (pedido_id),
    KEY fk_pi_produto (produto_id),
    KEY fk_pi_combo (combo_id),
    CONSTRAINT fk_pi_pedido FOREIGN KEY (pedido_id)
        REFERENCES pedido (id),
    CONSTRAINT fk_pi_produto FOREIGN KEY (produto_id)
        REFERENCES produto (id),
    CONSTRAINT fk_pi_combo FOREIGN KEY (combo_id)
        REFERENCES combo (id)
) ENGINE = InnoDB;

-- ============================================================================
-- TABELAS DO REQUISITO DO PROFESSOR (CRUD usuarios + projetos)
-- ============================================================================

CREATE TABLE IF NOT EXISTS usuarios (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    usuario     VARCHAR(50)  NOT NULL UNIQUE,
    nome        VARCHAR(120) NOT NULL,
    email       VARCHAR(120) NOT NULL UNIQUE,
    senha       VARCHAR(60)  NOT NULL,
    telefone    VARCHAR(20),
    criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS projetos (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    codigo              VARCHAR(20)  NOT NULL UNIQUE,
    descricao           TEXT         NOT NULL,
    ods                 VARCHAR(100) NOT NULL,
    nome_responsavel    VARCHAR(120) NOT NULL,
    telefone            VARCHAR(20),
    data_criacao        DATE         NOT NULL,
    status              VARCHAR(30)  NOT NULL DEFAULT 'Em andamento',
    criado_em           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

-- ============================================================================
-- GRUPO DE ACESSO (sistema de permissoes do restaurante)
-- ============================================================================
CREATE TABLE IF NOT EXISTS grupo_acesso (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    restaurante_id  BIGINT       NOT NULL,
    nome            VARCHAR(50)  NOT NULL,
    pode_ver_vendas     TINYINT(1) NOT NULL DEFAULT 0,
    pode_ver_faturamento TINYINT(1) NOT NULL DEFAULT 0,
    pode_gerenciar_produtos TINYINT(1) NOT NULL DEFAULT 0,
    pode_gerenciar_pedidos  TINYINT(1) NOT NULL DEFAULT 0,
    pode_gerenciar_usuarios TINYINT(1) NOT NULL DEFAULT 0,
    pode_alterar_precos     TINYINT(1) NOT NULL DEFAULT 0,
    criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY fk_grupo_restaurante (restaurante_id),
    CONSTRAINT fk_grupo_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

-- ============================================================================
-- ADMIN PADRAO (login: admin / senha: admin123)
-- ============================================================================
INSERT IGNORE INTO usuarios (usuario, nome, email, senha, telefone)
VALUES ('admin', 'Administrador', 'admin@savebyte.com', 'admin123', '(11) 99999-0000');

-- ============================================================================
-- Se o banco ja existia (migracao do app web), adicionar colunas novas
-- Ignora o erro caso a coluna ja exista
-- ============================================================================
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='savebyte' AND TABLE_NAME='cliente' AND COLUMN_NAME='numero') = 0,
    'ALTER TABLE cliente ADD COLUMN numero VARCHAR(20) NULL AFTER endereco',
    'SELECT 1'));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='savebyte' AND TABLE_NAME='cliente' AND COLUMN_NAME='imagem_url') = 0,
    'ALTER TABLE cliente ADD COLUMN imagem_url VARCHAR(500) NULL AFTER cep',
    'SELECT 1'));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='savebyte' AND TABLE_NAME='cliente' AND COLUMN_NAME='senha_visivel') = 0,
    'ALTER TABLE cliente ADD COLUMN senha_visivel VARCHAR(120) NULL AFTER senha',
    'SELECT 1'));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='savebyte' AND TABLE_NAME='restaurante' AND COLUMN_NAME='senha_visivel') = 0,
    'ALTER TABLE restaurante ADD COLUMN senha_visivel VARCHAR(120) NULL AFTER senha',
    'SELECT 1'));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='savebyte' AND TABLE_NAME='usuarios' AND COLUMN_NAME='restaurante_id') = 0,
    'ALTER TABLE usuarios ADD COLUMN restaurante_id BIGINT NULL AFTER id',
    'SELECT 1'));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='savebyte' AND TABLE_NAME='usuarios' AND COLUMN_NAME='grupo_acesso_id') = 0,
    'ALTER TABLE usuarios ADD COLUMN grupo_acesso_id INT NULL AFTER restaurante_id',
    'SELECT 1'));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
