package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Pedido;
import br.com.usjt.savebyte.model.PedidoItem;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public long inserir(Pedido p) {
        String sql = "INSERT INTO pedido (cliente_id, restaurante_id, data_pedido, status, valor_total, observacao, tipo_entrega, endereco_entrega, forma_pagamento, status_pagamento, cartao_final, valor_dinheiro, troco) VALUES (?,?,NOW(),?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, p.getClienteId());
            ps.setLong(2, p.getRestauranteId());
            ps.setString(3, p.getStatus() != null ? p.getStatus() : "PENDENTE");
            ps.setBigDecimal(4, p.getValorTotal());
            ps.setString(5, p.getObservacao());
            ps.setString(6, p.getTipoEntrega());
            ps.setString(7, p.getEnderecoEntrega());
            ps.setString(8, p.getFormaPagamento());
            ps.setString(9, p.getStatusPagamento());
            ps.setString(10, p.getCartaoFinal());
            ps.setBigDecimal(11, p.getValorDinheiro());
            ps.setBigDecimal(12, p.getTroco());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                long id = keys.getLong(1);
                p.setId(id);
                for (PedidoItem item : p.getItens()) {
                    inserirItem(conn, id, item);
                }
                return id;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return -1;
    }

    private void inserirItem(Connection conn, long pedidoId, PedidoItem item) throws SQLException {
        String sql = "INSERT INTO pedido_item (pedido_id, produto_id, combo_id, descricao, quantidade, preco_unitario) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, pedidoId);
            if (item.getProdutoId() != null) ps.setLong(2, item.getProdutoId()); else ps.setNull(2, Types.BIGINT);
            if (item.getComboId() != null) ps.setLong(3, item.getComboId()); else ps.setNull(3, Types.BIGINT);
            ps.setString(4, item.getDescricao());
            ps.setInt(5, item.getQuantidade());
            ps.setBigDecimal(6, item.getPrecoUnitario());
            ps.executeUpdate();
        }
    }

    public List<Pedido> listarTodos() {
        return listar("SELECT p.*, c.nome AS cli_nome, r.nome AS rest_nome FROM pedido p JOIN cliente c ON p.cliente_id = c.id JOIN restaurante r ON p.restaurante_id = r.id ORDER BY p.data_pedido DESC");
    }

    public List<Pedido> listarPorCliente(long clienteId) {
        return listar("SELECT p.*, c.nome AS cli_nome, r.nome AS rest_nome FROM pedido p JOIN cliente c ON p.cliente_id = c.id JOIN restaurante r ON p.restaurante_id = r.id WHERE p.cliente_id = " + clienteId + " ORDER BY p.data_pedido DESC");
    }

    public List<Pedido> listarPorRestaurante(long restauranteId) {
        return listar("SELECT p.*, c.nome AS cli_nome, r.nome AS rest_nome FROM pedido p JOIN cliente c ON p.cliente_id = c.id JOIN restaurante r ON p.restaurante_id = r.id WHERE p.restaurante_id = " + restauranteId + " ORDER BY p.data_pedido DESC");
    }

    public boolean alterarStatus(long pedidoId, String novoStatus) {
        String sql = "UPDATE pedido SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, novoStatus);
            ps.setLong(2, pedidoId);
            // Se entregue e pagamento na entrega, marcar como pago
            if ("ENTREGUE".equals(novoStatus)) {
                PreparedStatement up = conn.prepareStatement("UPDATE pedido SET status_pagamento = 'PAGO' WHERE id = ? AND forma_pagamento = 'NA_ENTREGA'");
                up.setLong(1, pedidoId);
                up.executeUpdate();
            }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<PedidoItem> listarItens(long pedidoId) {
        List<PedidoItem> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedido_item WHERE pedido_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, pedidoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                PedidoItem item = new PedidoItem();
                item.setId(rs.getLong("id"));
                item.setPedidoId(rs.getLong("pedido_id"));
                long prodId = rs.getLong("produto_id");
                item.setProdutoId(rs.wasNull() ? null : prodId);
                long cmbId = rs.getLong("combo_id");
                item.setComboId(rs.wasNull() ? null : cmbId);
                item.setDescricao(rs.getString("descricao"));
                item.setQuantidade(rs.getInt("quantidade"));
                item.setPrecoUnitario(rs.getBigDecimal("preco_unitario"));
                lista.add(item);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public void decrementarEstoque(Long produtoId, Long comboId, int qtd) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (produtoId != null) {
                PreparedStatement ps = conn.prepareStatement("UPDATE produto SET quantidade = quantidade - ? WHERE id = ? AND quantidade >= ?");
                ps.setInt(1, qtd); ps.setLong(2, produtoId); ps.setInt(3, qtd);
                ps.executeUpdate();
            }
            if (comboId != null) {
                PreparedStatement ps = conn.prepareStatement("UPDATE combo SET quantidade = quantidade - ? WHERE id = ? AND quantidade >= ?");
                ps.setInt(1, qtd); ps.setLong(2, comboId); ps.setInt(3, qtd);
                ps.executeUpdate();
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private List<Pedido> listar(String sql) {
        List<Pedido> lista = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    private Pedido mapear(ResultSet rs) throws SQLException {
        Pedido p = new Pedido();
        p.setId(rs.getLong("id"));
        p.setClienteId(rs.getLong("cliente_id"));
        p.setRestauranteId(rs.getLong("restaurante_id"));
        try { p.setClienteNome(rs.getString("cli_nome")); } catch (SQLException ignored) {}
        try { p.setRestauranteNome(rs.getString("rest_nome")); } catch (SQLException ignored) {}
        Timestamp ts = rs.getTimestamp("data_pedido");
        if (ts != null) p.setDataPedido(ts.toLocalDateTime());
        p.setStatus(rs.getString("status"));
        p.setValorTotal(rs.getBigDecimal("valor_total"));
        p.setObservacao(rs.getString("observacao"));
        p.setTipoEntrega(rs.getString("tipo_entrega"));
        p.setEnderecoEntrega(rs.getString("endereco_entrega"));
        p.setFormaPagamento(rs.getString("forma_pagamento"));
        p.setStatusPagamento(rs.getString("status_pagamento"));
        p.setCartaoFinal(rs.getString("cartao_final"));
        p.setValorDinheiro(rs.getBigDecimal("valor_dinheiro"));
        p.setTroco(rs.getBigDecimal("troco"));
        return p;
    }
}
