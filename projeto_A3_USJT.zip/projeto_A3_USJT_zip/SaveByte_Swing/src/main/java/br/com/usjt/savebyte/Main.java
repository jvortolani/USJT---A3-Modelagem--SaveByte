package br.com.usjt.savebyte;

import br.com.usjt.savebyte.view.LoginFrame;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class Main {
    public static void main(String[] args) {
        // Usar look and feel cross-platform para respeitar cores customizadas
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            // Definir ícone global para todas as janelas
            URL logoUrl = Main.class.getResource("/img/logo.png");
            if (logoUrl != null) {
                Image icon = new ImageIcon(logoUrl).getImage();
                // Tenta usar setIconImages em todas as janelas via Toolkit (Java 9+)
                try {
                    Taskbar.getTaskbar().setIconImage(icon);
                } catch (Exception ignored2) {}
                // Fallback: definir no LoginFrame e propagar
                LoginFrame login = new LoginFrame();
                login.setIconImage(icon);
                login.setVisible(true);
            } else {
                new LoginFrame().setVisible(true);
            }
        });
    }
}
