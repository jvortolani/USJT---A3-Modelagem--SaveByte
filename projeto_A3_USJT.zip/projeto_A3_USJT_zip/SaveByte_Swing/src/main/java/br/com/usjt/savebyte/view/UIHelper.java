package br.com.usjt.savebyte.view;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Componentes visuais modernos reutilizáveis.
 */
public class UIHelper {

    static final Color VERDE = new Color(26, 107, 42);
    static final Color VERDE_ESCURO = new Color(13, 63, 21);
    static final Color VERDE_CLARO = new Color(232, 245, 233);
    static final Color AZUL = new Color(30, 136, 229);
    static final Color VERMELHO = new Color(211, 47, 47);
    static final Color LARANJA = new Color(245, 124, 0);
    static final Color FUNDO = new Color(245, 247, 250);
    static final Color CARD_BG = Color.WHITE;
    static final Color BORDA_CARD = new Color(228, 228, 228);
    static final Color TEXTO = new Color(33, 33, 33);
    static final Color TEXTO_SEC = new Color(117, 117, 117);
    static final Font TITULO = new Font("SansSerif", Font.BOLD, 24);
    static final Font SUBTITULO = new Font("SansSerif", Font.BOLD, 16);
    static final Font CORPO = new Font("SansSerif", Font.PLAIN, 13);
    static final Font CORPO_PEQUENO = new Font("SansSerif", Font.PLAIN, 11);
    static final Font BOTAO_FONT = new Font("SansSerif", Font.BOLD, 13);

    // Diretório de uploads
    static final String UPLOADS_DIR;
    static {
        File dir = new File(System.getProperty("user.dir"));
        File uploadsDir = new File(dir.getParent(), "uploads");
        if (!uploadsDir.exists()) uploadsDir = new File(dir, "uploads");
        UPLOADS_DIR = uploadsDir.getAbsolutePath();
    }

    /** Cria um botão moderno com cantos arredondados */
    static JButton botaoModerno(String texto, Color cor) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(cor.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(cor.brighter());
                } else {
                    g2.setColor(cor);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        btn.setFont(BOTAO_FONT);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 36));
        return btn;
    }

    /** Cria um painel de card com cantos arredondados e sombra sutil */
    static JPanel cardPanel() {
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Sombra
                g2.setColor(new Color(0, 0, 0, 20));
                g2.fillRoundRect(3, 3, getWidth() - 3, getHeight() - 3, 16, 16);
                // Card
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 4, 16, 16);
                // Borda
                g2.setColor(BORDA_CARD);
                g2.drawRoundRect(0, 0, getWidth() - 5, getHeight() - 5, 16, 16);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        return card;
    }

    /** Cria um título de seção estilizado */
    static JPanel tituloSecao(String titulo, String subtitulo) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        JLabel lbl = new JLabel(titulo);
        lbl.setFont(TITULO);
        lbl.setForeground(VERDE_ESCURO);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lbl);
        if (subtitulo != null) {
            JLabel sub = new JLabel(subtitulo);
            sub.setFont(CORPO_PEQUENO);
            sub.setForeground(TEXTO_SEC);
            sub.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(sub);
        }
        p.add(Box.createVerticalStrut(10));
        return p;
    }

    /** Carrega imagem de arquivo ou URL */
    static ImageIcon carregarImagem(String imagemUrl, int largura, int altura) {
        if (imagemUrl == null || imagemUrl.isBlank()) return null;
        try {
            File file;
            if (imagemUrl.startsWith("/uploads/")) {
                file = new File(UPLOADS_DIR, imagemUrl.replace("/uploads/", ""));
            } else {
                file = new File(imagemUrl);
            }
            if (file.exists()) {
                BufferedImage img = ImageIO.read(file);
                if (img != null) {
                    Image scaled = img.getScaledInstance(largura, altura, Image.SCALE_SMOOTH);
                    return new ImageIcon(scaled);
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** Cria um label de imagem com placeholder */
    static JLabel labelImagem(String imagemUrl, int largura, int altura) {
        JLabel lbl = new JLabel();
        lbl.setHorizontalAlignment(SwingConstants.CENTER);
        lbl.setPreferredSize(new Dimension(largura, altura));
        lbl.setMinimumSize(new Dimension(largura, altura));
        lbl.setMaximumSize(new Dimension(largura, altura));
        ImageIcon icon = carregarImagem(imagemUrl, largura, altura);
        if (icon != null) {
            lbl.setIcon(icon);
        } else {
            lbl.setOpaque(true);
            lbl.setBackground(VERDE_CLARO);
            lbl.setForeground(VERDE);
            lbl.setFont(new Font("SansSerif", Font.PLAIN, 32));
            lbl.setText("\uD83C\uDF7D");
        }
        return lbl;
    }

    /** Sidebar moderna com gradiente */
    static JPanel criarSidebarBase() {
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, VERDE_ESCURO, 0, getHeight(), new Color(8, 45, 12));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(18, 12, 18, 12));
        return sidebar;
    }

    /** Botão de sidebar moderno */
    static JButton btnSidebar(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover() || getModel().isPressed()) {
                    g2.setColor(new Color(255, 255, 255, 35));
                } else {
                    g2.setColor(new Color(255, 255, 255, 15));
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = 15;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(196, 38));
        btn.setPreferredSize(new Dimension(196, 38));
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Painel de conteúdo com fundo suave */
    static JPanel painelConteudo() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setBackground(FUNDO);
        p.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        return p;
    }

    /** Escolher arquivo de imagem */
    static File escolherImagem(Component parent) {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Selecionar imagem");
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Imagens (JPG, PNG)", "jpg", "jpeg", "png", "gif"));
        if (fc.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
            return fc.getSelectedFile();
        }
        return null;
    }

    /** Salva imagem na pasta de uploads e retorna o caminho relativo */
    static String salvarImagem(File origem, String subpasta) {
        try {
            File destDir = new File(UPLOADS_DIR, subpasta);
            if (!destDir.exists()) destDir.mkdirs();
            String nomeArquivo = System.currentTimeMillis() + "_" + origem.getName();
            File destino = new File(destDir, nomeArquivo);
            BufferedImage img = ImageIO.read(origem);
            String ext = origem.getName().substring(origem.getName().lastIndexOf('.') + 1).toLowerCase();
            if (ext.equals("jpg")) ext = "jpeg";
            ImageIO.write(img, ext, destino);
            return "/uploads/" + subpasta + "/" + nomeArquivo;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Painel "Quem Somos" com logo e missao do SaveByte */
    static JPanel criarPainelQuemSomos() {
        JPanel card = cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
                card.getBorder(),
                BorderFactory.createEmptyBorder(18, 25, 18, 25)));
        card.setMaximumSize(new Dimension(800, 400));
        card.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Icone ODS
        JLabel lblOds = new JLabel("ODS 2 - Fome Zero e Agricultura Sustentavel");
        lblOds.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblOds.setForeground(new Color(215, 165, 30));
        lblOds.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblOds);
        card.add(Box.createVerticalStrut(6));

        JLabel lblTitulo = new JLabel("Quem Somos?");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTitulo.setForeground(VERDE_ESCURO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblTitulo);
        card.add(Box.createVerticalStrut(8));

        String texto = "<html><div style='text-align:center; line-height:1.5;'>"
                + "O <b>SaveByte</b> e uma plataforma de resgate de alimentos que conecta "
                + "restaurantes e consumidores com um objetivo claro: <b>reduzir o desperdicio de alimentos</b>."
                + "<br><br>"
                + "Milhoes de toneladas de comida sao desperdicadas todos os dias enquanto milhoes de pessoas "
                + "passam fome. Nosso aplicativo permite que restaurantes oferecam produtos proximos ao vencimento "
                + "ou excedentes com <b>precos especiais</b>, evitando que alimentos perfeitamente bons acabem no lixo."
                + "<br><br>"
                + "Estamos alinhados ao <b>Objetivo de Desenvolvimento Sustentavel 2 da ONU</b>: "
                + "<i>Fome Zero e Agricultura Sustentavel</i>, contribuindo para um sistema alimentar mais "
                + "justo, acessivel e sustentavel."
                + "<br><br>"
                + "<b>Cada refeicao salva faz a diferenca.</b>"
                + "</div></html>";

        JLabel lblTexto = new JLabel(texto);
        lblTexto.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblTexto.setForeground(TEXTO);
        lblTexto.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblTexto);
        card.add(Box.createVerticalStrut(10));

        // Badges
        JPanel badges = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        badges.setOpaque(false);
        badges.add(criarBadgeOds("Menos desperdicio", new Color(76, 175, 80)));
        badges.add(criarBadgeOds("Precos acessiveis", new Color(33, 150, 243)));
        badges.add(criarBadgeOds("Sustentabilidade", new Color(255, 152, 0)));
        card.add(badges);

        return card;
    }

    private static JLabel criarBadgeOds(String texto, Color cor) {
        JLabel badge = new JLabel("  " + texto + "  ");
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setForeground(Color.WHITE);
        badge.setOpaque(true);
        badge.setBackground(cor);
        badge.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        return badge;
    }

    /** Layout que funciona como FlowLayout mas quebra linha automaticamente dentro de JScrollPane */
    static class WrapLayout extends FlowLayout {
        WrapLayout(int align, int hgap, int vgap) { super(align, hgap, vgap); }

        @Override
        public Dimension preferredLayoutSize(Container target) {
            return layoutSize(target, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container target) {
            return layoutSize(target, false);
        }

        private Dimension layoutSize(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                int targetWidth = target.getWidth();
                // Se dentro de um JScrollPane, usar a largura do viewport
                if (targetWidth == 0 || target.getParent() instanceof javax.swing.JViewport) {
                    Container parent = target.getParent();
                    if (parent instanceof javax.swing.JViewport) {
                        targetWidth = parent.getWidth();
                    }
                }
                if (targetWidth == 0) targetWidth = Integer.MAX_VALUE;

                Insets insets = target.getInsets();
                int maxWidth = targetWidth - insets.left - insets.right;
                int x = 0, y = insets.top, rowHeight = 0;

                for (int i = 0; i < target.getComponentCount(); i++) {
                    Component m = target.getComponent(i);
                    if (m.isVisible()) {
                        Dimension d = preferred ? m.getPreferredSize() : m.getMinimumSize();
                        if (x > 0 && x + d.width > maxWidth) {
                            y += rowHeight + getVgap();
                            x = 0;
                            rowHeight = 0;
                        }
                        x += d.width + getHgap();
                        rowHeight = Math.max(rowHeight, d.height);
                    }
                }
                y += rowHeight + insets.bottom;
                return new Dimension(maxWidth + insets.left + insets.right, y);
            }
        }
    }

    /** Painel que respeita a largura do viewport do JScrollPane para o WrapLayout funcionar */
    static class WrapPanel extends JPanel implements Scrollable {
        WrapPanel(LayoutManager layout) {
            super(layout);
            addComponentListener(new java.awt.event.ComponentAdapter() {
                @Override public void componentResized(java.awt.event.ComponentEvent e) {
                    revalidate();
                }
            });
        }

        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) { return 16; }
        @Override public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) { return 64; }
        @Override public boolean getScrollableTracksViewportWidth() { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
    }
}
