package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.*;
import br.com.usjt.savebyte.model.*;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class LoginFrame extends JFrame {

    private final JTextField txtEmail = new JTextField(20);
    private final JPasswordField txtSenha = new JPasswordField(20);

    static final Color VERDE = new Color(26, 107, 42);
    static final Color VERDE_ESCURO = new Color(13, 63, 21);

    public LoginFrame() {
        setTitle("SaveByte - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(VERDE_ESCURO);

        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        // Logo
        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(140, 140, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(img));
            lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
            painel.add(lblLogo);
            painel.add(Box.createVerticalStrut(5));
        }

        JLabel lblSubtitulo = new JLabel("Aproveite mais, desperdice menos");
        lblSubtitulo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSubtitulo.setForeground(Color.GRAY);
        lblSubtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblSubtitulo);
        painel.add(Box.createVerticalStrut(20));

        // Campos
        painel.add(criarLabel("E-mail ou usuario"));
        painel.add(Box.createVerticalStrut(4));
        txtEmail.setAlignmentX(Component.CENTER_ALIGNMENT);
        txtEmail.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        painel.add(txtEmail);
        painel.add(Box.createVerticalStrut(12));

        painel.add(criarLabel("Senha"));
        painel.add(Box.createVerticalStrut(4));
        txtSenha.setAlignmentX(Component.CENTER_ALIGNMENT);
        txtSenha.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        painel.add(txtSenha);
        painel.add(Box.createVerticalStrut(20));

        // Botão Entrar
        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnEntrar.setBackground(VERDE);
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setFocusPainted(false);
        btnEntrar.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnEntrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnEntrar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        btnEntrar.addActionListener(e -> autenticar());
        painel.add(btnEntrar);
        painel.add(Box.createVerticalStrut(12));

        // Link cadastro
        JButton btnCadastro = new JButton("Não tem conta? Cadastre-se");
        btnCadastro.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCadastro.setBorderPainted(false);
        btnCadastro.setContentAreaFilled(false);
        btnCadastro.setForeground(VERDE);
        btnCadastro.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCadastro.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btnCadastro.addActionListener(e -> {
            dispose();
            new CadastroFrame().setVisible(true);
        });
        painel.add(btnCadastro);

        getRootPane().setDefaultButton(btnEntrar);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(VERDE_ESCURO);
        wrapper.add(painel);
        add(wrapper);
        setSize(420, 500);
        setLocationRelativeTo(null);
    }

    private JLabel criarLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        lbl.setHorizontalAlignment(SwingConstants.LEFT);
        lbl.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));
        return lbl;
    }

    private void autenticar() {
        String login = txtEmail.getText().trim();
        String senha = new String(txtSenha.getPassword());
        if (login.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha os campos.", "Atencao", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Tenta usuario do sistema (admin ou funcionario de restaurante)
        Usuario u = new UsuarioDAO().autenticar(login, senha);
        if (u != null) {
            if (u.getRestauranteId() != null) {
                // Usuario vinculado a um restaurante -- abrir RestauranteFrame com permissoes
                Restaurante r = new RestauranteDAO().buscarPorId(u.getRestauranteId());
                if (r != null) {
                    GrupoAcesso grupo = null;
                    if (u.getGrupoAcessoId() != null) {
                        grupo = new GrupoAcessoDAO().buscarPorId(u.getGrupoAcessoId());
                    }
                    dispose();
                    new RestauranteFrame(r, u, grupo).setVisible(true);
                    return;
                }
            }
            // Admin do sistema (sem restaurante_id)
            dispose(); new AdminFrame(u).setVisible(true); return;
        }

        // Tenta cliente (por e-mail)
        Cliente c = new ClienteDAO().autenticar(login, senha);
        if (c != null) { dispose(); new ClienteFrame(c).setVisible(true); return; }

        // Tenta restaurante (por e-mail)
        Restaurante r = new RestauranteDAO().autenticar(login, senha);
        if (r != null) { dispose(); new RestauranteFrame(r).setVisible(true); return; }

        JOptionPane.showMessageDialog(this, "Credenciais invalidas.", "Erro", JOptionPane.ERROR_MESSAGE);
        txtSenha.setText("");
        txtSenha.requestFocus();
    }
}
