package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.GrupoAcessoDAO;
import br.com.usjt.savebyte.dao.UsuarioDAO;
import br.com.usjt.savebyte.model.GrupoAcesso;
import br.com.usjt.savebyte.model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UsuarioPanel extends JPanel {

    private static final Color VERDE = new Color(26, 107, 42);
    private final UsuarioDAO dao = new UsuarioDAO();
    private final GrupoAcessoDAO grupoDAO = new GrupoAcessoDAO();
    private final DefaultTableModel tableModel;
    private final JTable tabela;
    private final JTextField txtBusca = new JTextField(20);
    private List<Usuario> listaAtual;
    private final Long restauranteId;
    private final Integer loggedUserId; // ID do usuario logado (para impedir auto-edicao de grupo)

    /** Construtor para admin (mostra todos os usuarios) */
    public UsuarioPanel() {
        this(null, null);
    }

    /** Construtor para restaurante (mostra apenas usuarios deste restaurante, filtra admin) */
    public UsuarioPanel(Long restauranteId) {
        this(restauranteId, null);
    }

    /** Construtor completo com ID do usuario logado */
    public UsuarioPanel(Long restauranteId, Integer loggedUserId) {
        this.restauranteId = restauranteId;
        this.loggedUserId = loggedUserId;
        setLayout(new BorderLayout(0, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Gerenciamento de Usuarios");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitulo.setForeground(VERDE);

        JPanel barraAcoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        barraAcoes.setBackground(Color.WHITE);

        JButton btnNovo = botao("Novo", VERDE);
        btnNovo.addActionListener(e -> abrirFormulario(null));
        JButton btnEditar = botao("Editar", new Color(30, 136, 229));
        btnEditar.addActionListener(e -> editarSelecionado());
        JButton btnExcluir = botao("Excluir", new Color(211, 47, 47));
        btnExcluir.addActionListener(e -> excluirSelecionado());

        barraAcoes.add(btnNovo);
        barraAcoes.add(btnEditar);
        barraAcoes.add(btnExcluir);
        barraAcoes.add(Box.createHorizontalStrut(20));
        barraAcoes.add(new JLabel("Buscar:"));
        barraAcoes.add(txtBusca);
        JButton btnBuscar = botao("Buscar", Color.DARK_GRAY);
        btnBuscar.addActionListener(e -> carregar());
        barraAcoes.add(btnBuscar);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(Color.WHITE);
        topo.add(lblTitulo, BorderLayout.NORTH);
        topo.add(Box.createVerticalStrut(10), BorderLayout.CENTER);
        topo.add(barraAcoes, BorderLayout.SOUTH);
        add(topo, BorderLayout.NORTH);

        String[] colunas = {"ID", "Usuario", "Nome", "E-mail", "Telefone", "Grupo de Acesso"};
        tableModel = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(tableModel);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setRowHeight(26);
        tabela.getColumnModel().getColumn(0).setMaxWidth(50);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        carregar();
    }

    private void carregar() {
        String termo = txtBusca.getText().trim();
        if (restauranteId != null) {
            listaAtual = termo.isEmpty() ? dao.listarPorRestaurante(restauranteId) : dao.buscarPorRestaurante(restauranteId, termo);
        } else {
            listaAtual = termo.isEmpty() ? dao.listar() : dao.buscar(termo);
        }
        tableModel.setRowCount(0);
        for (Usuario u : listaAtual) {
            // Filtrar admin do sistema na visao do restaurante
            if (restauranteId != null && "admin".equals(u.getUsuario()) && u.getRestauranteId() == null) continue;
            String grupo = u.getGrupoAcessoNome() != null ? u.getGrupoAcessoNome() : "-";
            tableModel.addRow(new Object[]{u.getId(), u.getUsuario(), u.getNome(), u.getEmail(), u.getTelefone(), grupo});
        }
    }

    private void editarSelecionado() {
        int row = tabela.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecione um usuario na tabela."); return; }
        abrirFormulario(listaAtual.get(row));
    }

    private void excluirSelecionado() {
        int row = tabela.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecione um usuario na tabela."); return; }
        Usuario u = listaAtual.get(row);
        if ("admin".equals(u.getUsuario())) { JOptionPane.showMessageDialog(this, "Nao e possivel excluir o admin do sistema."); return; }
        int resp = JOptionPane.showConfirmDialog(this, "Excluir o usuario \"" + u.getNome() + "\"?", "Confirmacao", JOptionPane.YES_NO_OPTION);
        if (resp == JOptionPane.YES_OPTION) {
            if (dao.excluir(u.getId())) {
                JOptionPane.showMessageDialog(this, "Usuario excluido.");
                carregar();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void abrirFormulario(Usuario existente) {
        JTextField txtUsuario = new JTextField(existente != null ? existente.getUsuario() : "");
        JTextField txtNome = new JTextField(existente != null ? existente.getNome() : "");
        JTextField txtEmail = new JTextField(existente != null ? existente.getEmail() : "");
        JPasswordField txtSenha = new JPasswordField(existente != null ? existente.getSenha() : "");
        JTextField txtTelefone = new JTextField(existente != null ? existente.getTelefone() : "");

        // Grupo de acesso combo
        List<GrupoAcesso> grupos;
        if (restauranteId != null) {
            grupos = grupoDAO.listarPorRestaurante(restauranteId);
        } else {
            grupos = new java.util.ArrayList<>();
        }
        JComboBox<String> cmbGrupo = new JComboBox<>();
        cmbGrupo.addItem("-- Nenhum --");
        for (GrupoAcesso g : grupos) cmbGrupo.addItem(g.getNome());
        if (existente != null && existente.getGrupoAcessoNome() != null) {
            cmbGrupo.setSelectedItem(existente.getGrupoAcessoNome());
        }

        // Impedir que o usuario edite seu proprio grupo de acesso
        boolean isEditandoSiMesmo = existente != null && loggedUserId != null && existente.getId() == loggedUserId;
        if (isEditandoSiMesmo) {
            cmbGrupo.setEnabled(false);
            cmbGrupo.setToolTipText("Voce nao pode alterar seu proprio grupo de acesso");
        }

        JPanel form = new JPanel(new GridLayout(6, 2, 8, 8));
        form.add(new JLabel("Usuario:")); form.add(txtUsuario);
        form.add(new JLabel("Nome:")); form.add(txtNome);
        form.add(new JLabel("E-mail:")); form.add(txtEmail);
        form.add(new JLabel("Senha:")); form.add(txtSenha);
        form.add(new JLabel("Telefone:")); form.add(txtTelefone);
        form.add(new JLabel("Grupo de Acesso:")); form.add(cmbGrupo);

        String titulo = existente != null ? "Editar Usuario" : "Novo Usuario";
        int resp = JOptionPane.showConfirmDialog(this, form, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resp != JOptionPane.OK_OPTION) return;

        String usuario = txtUsuario.getText().trim();
        String nome = txtNome.getText().trim();
        String email = txtEmail.getText().trim();
        String senha = new String(txtSenha.getPassword()).trim();

        if (usuario.isEmpty() || nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha os campos obrigatorios (usuario, nome, e-mail e senha).", "Atencao", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Usuario u = existente != null ? existente : new Usuario();
        u.setUsuario(usuario);
        u.setNome(nome);
        u.setEmail(email);
        u.setSenha(senha);
        u.setTelefone(txtTelefone.getText().trim());
        u.setRestauranteId(restauranteId);

        // Mapear grupo selecionado
        int grupoIdx = cmbGrupo.getSelectedIndex();
        if (grupoIdx > 0 && grupoIdx <= grupos.size()) {
            u.setGrupoAcessoId(grupos.get(grupoIdx - 1).getId());
        } else {
            u.setGrupoAcessoId(null);
        }

        boolean ok = existente != null ? dao.atualizar(u) : dao.inserir(u);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Usuario salvo com sucesso!");
            carregar();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar. Verifique se o usuario ou e-mail ja existe.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton botao(String texto, Color cor) {
        JButton btn = new JButton(texto);
        btn.setBackground(cor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
