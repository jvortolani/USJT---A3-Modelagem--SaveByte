package br.com.usjt.savebyte.model;

public class GrupoAcesso {
    private int id;
    private long restauranteId;
    private String nome;
    private boolean podeVerVendas;
    private boolean podeVerFaturamento;
    private boolean podeGerenciarProdutos;
    private boolean podeGerenciarPedidos;
    private boolean podeGerenciarUsuarios;
    private boolean podeAlterarPrecos;

    public GrupoAcesso() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public long getRestauranteId() { return restauranteId; }
    public void setRestauranteId(long restauranteId) { this.restauranteId = restauranteId; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public boolean isPodeVerVendas() { return podeVerVendas; }
    public void setPodeVerVendas(boolean podeVerVendas) { this.podeVerVendas = podeVerVendas; }

    public boolean isPodeVerFaturamento() { return podeVerFaturamento; }
    public void setPodeVerFaturamento(boolean podeVerFaturamento) { this.podeVerFaturamento = podeVerFaturamento; }

    public boolean isPodeGerenciarProdutos() { return podeGerenciarProdutos; }
    public void setPodeGerenciarProdutos(boolean podeGerenciarProdutos) { this.podeGerenciarProdutos = podeGerenciarProdutos; }

    public boolean isPodeGerenciarPedidos() { return podeGerenciarPedidos; }
    public void setPodeGerenciarPedidos(boolean podeGerenciarPedidos) { this.podeGerenciarPedidos = podeGerenciarPedidos; }

    public boolean isPodeGerenciarUsuarios() { return podeGerenciarUsuarios; }
    public void setPodeGerenciarUsuarios(boolean podeGerenciarUsuarios) { this.podeGerenciarUsuarios = podeGerenciarUsuarios; }

    public boolean isPodeAlterarPrecos() { return podeAlterarPrecos; }
    public void setPodeAlterarPrecos(boolean podeAlterarPrecos) { this.podeAlterarPrecos = podeAlterarPrecos; }

    @Override
    public String toString() { return nome; }
}
