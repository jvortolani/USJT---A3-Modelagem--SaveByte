package br.com.usjt.savebyte.model;

import java.time.LocalDate;

public class Projeto {
    private int id;
    private String codigo;
    private String descricao;
    private String ods;
    private String nomeResponsavel;
    private String telefone;
    private LocalDate dataCriacao;
    private String status;

    public Projeto() {
        this.status = "Em andamento";
        this.dataCriacao = LocalDate.now();
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getOds() { return ods; }
    public void setOds(String ods) { this.ods = ods; }

    public String getNomeResponsavel() { return nomeResponsavel; }
    public void setNomeResponsavel(String nomeResponsavel) { this.nomeResponsavel = nomeResponsavel; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public LocalDate getDataCriacao() { return dataCriacao; }
    public void setDataCriacao(LocalDate dataCriacao) { this.dataCriacao = dataCriacao; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
