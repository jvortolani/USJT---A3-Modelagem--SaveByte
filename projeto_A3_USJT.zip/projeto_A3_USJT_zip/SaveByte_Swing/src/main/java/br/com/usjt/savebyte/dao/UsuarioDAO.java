package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public Usuario autenticar(String usuario, String senha) {
        String sql = "SELECT u.*, g.nome AS grupo_nome FROM usuarios u " +
                "LEFT JOIN grupo_acesso g ON u.grupo_acesso_id = g.id " +
                "WHERE u.usuario = ? AND u.senha = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usuario);
            ps.setString(2, senha);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.*, g.nome AS grupo_nome FROM usuarios u " +
                "LEFT JOIN grupo_acesso g ON u.grupo_acesso_id = g.id ORDER BY u.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public List<Usuario> listarPorRestaurante(long restauranteId) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.*, g.nome AS grupo_nome FROM usuarios u " +
                "LEFT JOIN grupo_acesso g ON u.grupo_acesso_id = g.id " +
                "WHERE u.restaurante_id = ? ORDER BY u.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, restauranteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public List<Usuario> buscar(String termo) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.*, g.nome AS grupo_nome FROM usuarios u " +
                "LEFT JOIN grupo_acesso g ON u.grupo_acesso_id = g.id " +
                "WHERE u.nome LIKE ? OR u.usuario LIKE ? OR u.email LIKE ? ORDER BY u.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + termo + "%";
            ps.setString(1, like); ps.setString(2, like); ps.setString(3, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public List<Usuario> buscarPorRestaurante(long restauranteId, String termo) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.*, g.nome AS grupo_nome FROM usuarios u " +
                "LEFT JOIN grupo_acesso g ON u.grupo_acesso_id = g.id " +
                "WHERE u.restaurante_id = ? AND (u.nome LIKE ? OR u.usuario LIKE ? OR u.email LIKE ?) ORDER BY u.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, restauranteId);
            String like = "%" + termo + "%";
            ps.setString(2, like); ps.setString(3, like); ps.setString(4, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public boolean inserir(Usuario u) {
        String sql = "INSERT INTO usuarios (restaurante_id, grupo_acesso_id, usuario, nome, email, senha, telefone) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if (u.getRestauranteId() != null) ps.setLong(1, u.getRestauranteId()); else ps.setNull(1, Types.BIGINT);
            if (u.getGrupoAcessoId() != null) ps.setInt(2, u.getGrupoAcessoId()); else ps.setNull(2, Types.INTEGER);
            ps.setString(3, u.getUsuario());
            ps.setString(4, u.getNome());
            ps.setString(5, u.getEmail());
            ps.setString(6, u.getSenha());
            ps.setString(7, u.getTelefone());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean atualizar(Usuario u) {
        String sql = "UPDATE usuarios SET restaurante_id=?, grupo_acesso_id=?, usuario=?, nome=?, email=?, senha=?, telefone=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if (u.getRestauranteId() != null) ps.setLong(1, u.getRestauranteId()); else ps.setNull(1, Types.BIGINT);
            if (u.getGrupoAcessoId() != null) ps.setInt(2, u.getGrupoAcessoId()); else ps.setNull(2, Types.INTEGER);
            ps.setString(3, u.getUsuario());
            ps.setString(4, u.getNome());
            ps.setString(5, u.getEmail());
            ps.setString(6, u.getSenha());
            ps.setString(7, u.getTelefone());
            ps.setInt(8, u.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean excluir(int id) {
        String sql = "DELETE FROM usuarios WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    private Usuario mapear(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setId(rs.getInt("id"));
        try { long rid = rs.getLong("restaurante_id"); if (!rs.wasNull()) u.setRestauranteId(rid); } catch (SQLException ignored) {}
        try { int gid = rs.getInt("grupo_acesso_id"); if (!rs.wasNull()) u.setGrupoAcessoId(gid); } catch (SQLException ignored) {}
        try { u.setGrupoAcessoNome(rs.getString("grupo_nome")); } catch (SQLException ignored) {}
        u.setUsuario(rs.getString("usuario"));
        u.setNome(rs.getString("nome"));
        u.setEmail(rs.getString("email"));
        u.setSenha(rs.getString("senha"));
        u.setTelefone(rs.getString("telefone"));
        Timestamp ts = rs.getTimestamp("criado_em");
        if (ts != null) u.setCriadoEm(ts.toLocalDateTime());
        return u;
    }
}
