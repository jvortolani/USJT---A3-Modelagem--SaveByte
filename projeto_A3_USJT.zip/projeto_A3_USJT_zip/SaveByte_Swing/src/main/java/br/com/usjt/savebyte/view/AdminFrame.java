package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.*;
import br.com.usjt.savebyte.model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;

public class AdminFrame extends JFrame {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private final Usuario admin;
    private final JPanel conteudo = new JPanel(new CardLayout());

    public AdminFrame(Usuario admin) {
        this.admin = admin;
        setTitle("SaveByte - Administracao");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        java.net.URL iconUrl = getClass().getResource("/img/logo.png");
        if (iconUrl != null) setIconImage(new ImageIcon(iconUrl).getImage());

        JPanel principal = new JPanel(new BorderLayout());
        principal.add(criarSidebar(), BorderLayout.WEST);

        conteudo.add(criarPainelDashboard(), "DASHBOARD");
        conteudo.add(criarPainelClientes(), "CLIENTES");
        conteudo.add(criarPainelRestaurantes(), "RESTAURANTES");
        conteudo.add(criarPainelPedidos(), "PEDIDOS");
        conteudo.add(criarPainelProdutos(), "PRODUTOS");
        conteudo.add(criarPainelCombos(), "COMBOS");
        conteudo.add(new UsuarioPanel(), "USUARIOS");
        conteudo.add(new ProjetoPanel(), "PROJETOS");
        principal.add(conteudo, BorderLayout.CENTER);

        add(principal);
    }

    private void mostrar(String card) {
        ((CardLayout) conteudo.getLayout()).show(conteudo, card);
    }

    // ============================================================== SIDEBAR
    private JPanel criarSidebar() {
        JPanel sidebar = UIHelper.criarSidebarBase();

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(img));
            lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(lblLogo);
            sidebar.add(Box.createVerticalStrut(6));
        }

        JLabel lblAdmin = new JLabel("ADMINISTRADOR");
        lblAdmin.setFont(new Font("SansSerif", Font.BOLD, 11));
        lblAdmin.setForeground(new Color(255, 200, 50));
        lblAdmin.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lblAdmin);
        sidebar.add(Box.createVerticalStrut(12));

        sidebar.add(btn("Dashboard", "DASHBOARD"));
        sidebar.add(Box.createVerticalStrut(4));

        sep(sidebar, "Cadastros");
        sidebar.add(btn("Clientes", "CLIENTES"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(btn("Restaurantes", "RESTAURANTES"));
        sidebar.add(Box.createVerticalStrut(4));

        sep(sidebar, "Operacoes");
        sidebar.add(btn("Pedidos", "PEDIDOS"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(btn("Produtos", "PRODUTOS"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(btn("Combos", "COMBOS"));
        sidebar.add(Box.createVerticalStrut(4));

        sep(sidebar, "Sistema");
        sidebar.add(btn("Usuarios", "USUARIOS"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(btn("Projetos", "PROJETOS"));

        sidebar.add(Box.createVerticalGlue());

        JLabel lblUser = new JLabel(admin.getNome());
        lblUser.setForeground(new Color(200, 230, 201));
        lblUser.setFont(UIHelper.CORPO_PEQUENO);
        lblUser.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lblUser);
        sidebar.add(Box.createVerticalStrut(6));

        JButton btnSair = UIHelper.btnSidebar("Sair");
        btnSair.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });
        sidebar.add(btnSair);
        return sidebar;
    }

    private JButton btn(String txt, String card) {
        JButton b = UIHelper.btnSidebar(txt);
        b.addActionListener(e -> mostrar(card));
        return b;
    }

    private void sep(JPanel sidebar, String titulo) {
        sidebar.add(Box.createVerticalStrut(8));
        JSeparator s = new JSeparator();
        s.setMaximumSize(new Dimension(196, 1));
        s.setForeground(new Color(255, 255, 255, 40));
        sidebar.add(s);
        sidebar.add(Box.createVerticalStrut(4));
        JLabel lbl = new JLabel(titulo);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 9));
        lbl.setForeground(new Color(200, 230, 201));
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lbl);
        sidebar.add(Box.createVerticalStrut(4));
    }

    // ============================================================== DASHBOARD
    private JPanel criarPainelDashboard() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UIHelper.FUNDO);

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setOpaque(false);
        centro.setBorder(BorderFactory.createEmptyBorder(40, 30, 20, 30));

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
            JLabel lbl = new JLabel(new ImageIcon(img));
            lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            centro.add(lbl);
            centro.add(Box.createVerticalStrut(8));
        }
        JLabel l1 = new JLabel("Painel Administrativo");
        l1.setFont(new Font("SansSerif", Font.BOLD, 26));
        l1.setForeground(UIHelper.VERDE_ESCURO);
        l1.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(l1);
        JLabel l2 = new JLabel("Controle total do sistema SaveByte");
        l2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        l2.setForeground(UIHelper.TEXTO_SEC);
        l2.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(l2);
        centro.add(Box.createVerticalStrut(14));

        JPanel stats = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        stats.setOpaque(false);
        stats.add(statCard("Clientes", String.valueOf(new ClienteDAO().listar().size()), UIHelper.VERDE));
        stats.add(statCard("Restaurantes", String.valueOf(new RestauranteDAO().listar().size()), UIHelper.AZUL));
        stats.add(statCard("Produtos", String.valueOf(new ProdutoDAO().listarTodos().size()), UIHelper.LARANJA));
        stats.add(statCard("Pedidos", String.valueOf(new PedidoDAO().listarTodos().size()), UIHelper.VERMELHO));
        centro.add(stats);
        centro.add(Box.createVerticalStrut(10));

        // Quem Somos
        centro.add(UIHelper.criarPainelQuemSomos());

        JScrollPane scroll = new JScrollPane(centro);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private JPanel statCard(String titulo, String valor, Color cor) {
        JPanel card = UIHelper.cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(150, 90));
        JLabel lblV = new JLabel(valor);
        lblV.setFont(new Font("SansSerif", Font.BOLD, 32));
        lblV.setForeground(cor);
        lblV.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(Box.createVerticalStrut(8));
        card.add(lblV);
        JLabel lblT = new JLabel(titulo);
        lblT.setFont(UIHelper.CORPO);
        lblT.setForeground(UIHelper.TEXTO_SEC);
        lblT.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblT);
        return card;
    }

    // ============================================================== CLIENTES
    private DefaultTableModel cliModel;
    private List<Cliente> clientesAtuais = new ArrayList<>();
    private JTextField txtBuscaCli;

    private JPanel criarPainelClientes() {
        JPanel p = UIHelper.painelConteudo();
        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Clientes cadastrados", "Gerencie todos os clientes do sistema"), BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        acoes.setOpaque(false);
        txtBuscaCli = new JTextField(15);
        JButton btnBuscar = UIHelper.botaoModerno("Buscar", UIHelper.VERDE);
        btnBuscar.addActionListener(e -> refreshClientes());
        JButton btnExcluir = UIHelper.botaoModerno("Excluir", UIHelper.VERMELHO);
        btnExcluir.addActionListener(e -> excluirCliente());
        JButton btnEditar = UIHelper.botaoModerno("Editar", UIHelper.AZUL);
        btnEditar.addActionListener(e -> editarCliente());
        acoes.add(txtBuscaCli); acoes.add(btnBuscar); acoes.add(btnEditar); acoes.add(btnExcluir);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        String[] cols = {"ID", "Nome", "E-mail", "Senha", "Telefone", "Endereco", "Bairro", "Cidade", "Estado", "CEP"};
        cliModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = criarTabela(cliModel);
        p.add(new JScrollPane(tabela), BorderLayout.CENTER);

        refreshClientes();
        return p;
    }

    private void refreshClientes() {
        String termo = txtBuscaCli != null ? txtBuscaCli.getText().trim() : "";
        clientesAtuais = termo.isEmpty() ? new ClienteDAO().listar() : new ClienteDAO().buscar(termo);
        cliModel.setRowCount(0);
        for (Cliente c : clientesAtuais) {
            cliModel.addRow(new Object[]{c.getId(), c.getNome(), c.getEmail(), c.getSenhaVisivel() != null ? c.getSenhaVisivel() : "(hash)", c.getTelefone(),
                    c.getEndereco(), c.getBairro(), c.getCidade(), c.getEstado(), c.getCep()});
        }
    }

    private void editarCliente() {
        int row = getSelectedRow("CLIENTES");
        if (row < 0) return;
        Cliente c = clientesAtuais.get(row);
        JTextField txtNome = new JTextField(c.getNome(), 20);
        JTextField txtTel = new JTextField(c.getTelefone(), 15);
        JTextField txtSenha = new JTextField(c.getSenhaVisivel() != null ? c.getSenhaVisivel() : "", 15);
        JTextField txtEnd = new JTextField(c.getEndereco(), 20);
        JTextField txtBairro = new JTextField(c.getBairro(), 15);
        JTextField txtCidade = new JTextField(c.getCidade(), 15);
        JTextField txtEstado = new JTextField(c.getEstado(), 5);
        JTextField txtCep = new JTextField(c.getCep(), 10);

        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5));
        form.add(new JLabel("Nome:")); form.add(txtNome);
        form.add(new JLabel("Telefone:")); form.add(txtTel);
        form.add(new JLabel("Senha:")); form.add(txtSenha);
        form.add(new JLabel("CEP:")); form.add(txtCep);
        form.add(new JLabel("Endereco:")); form.add(txtEnd);
        form.add(new JLabel("Bairro:")); form.add(txtBairro);
        form.add(new JLabel("Cidade:")); form.add(txtCidade);
        form.add(new JLabel("Estado:")); form.add(txtEstado);

        if (JOptionPane.showConfirmDialog(this, form, "Editar Cliente - " + c.getNome(), JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            c.setNome(txtNome.getText().trim());
            c.setTelefone(txtTel.getText().trim());
            c.setEndereco(txtEnd.getText().trim());
            c.setBairro(txtBairro.getText().trim());
            c.setCidade(txtCidade.getText().trim());
            c.setEstado(txtEstado.getText().trim());
            c.setCep(txtCep.getText().trim());
            String novaSenha = txtSenha.getText().trim();
            if (!novaSenha.isEmpty()) {
                c.setSenhaVisivel(novaSenha);
            }
            if (new ClienteDAO().atualizar(c)) {
                JOptionPane.showMessageDialog(this, "Cliente atualizado!");
                refreshClientes();
            }
        }
    }

    private void excluirCliente() {
        int row = getSelectedRow("CLIENTES");
        if (row < 0) return;
        Cliente c = clientesAtuais.get(row);
        if (JOptionPane.showConfirmDialog(this, "Excluir cliente \"" + c.getNome() + "\"?\n\nTodos os pedidos deste cliente serao removidos.", "Confirmar exclusao", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
            if (new ClienteDAO().excluir(c.getId())) {
                JOptionPane.showMessageDialog(this, "Cliente excluido!");
                refreshClientes();
            }
        }
    }

    // ============================================================== RESTAURANTES
    private DefaultTableModel restModel;
    private List<Restaurante> restaurantesAtuais = new ArrayList<>();
    private JTextField txtBuscaRest;

    private JPanel criarPainelRestaurantes() {
        JPanel p = UIHelper.painelConteudo();
        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Restaurantes cadastrados", "Gerencie todos os restaurantes do sistema"), BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        acoes.setOpaque(false);
        txtBuscaRest = new JTextField(15);
        JButton btnBuscar = UIHelper.botaoModerno("Buscar", UIHelper.VERDE);
        btnBuscar.addActionListener(e -> refreshRestaurantes());
        JButton btnExcluir = UIHelper.botaoModerno("Excluir", UIHelper.VERMELHO);
        btnExcluir.addActionListener(e -> excluirRestaurante());
        JButton btnEditar = UIHelper.botaoModerno("Editar", UIHelper.AZUL);
        btnEditar.addActionListener(e -> editarRestaurante());
        JButton btnProdutos = UIHelper.botaoModerno("Ver Produtos", UIHelper.LARANJA);
        btnProdutos.addActionListener(e -> verProdutosRestaurante());
        acoes.add(txtBuscaRest); acoes.add(btnBuscar); acoes.add(btnEditar); acoes.add(btnProdutos); acoes.add(btnExcluir);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        String[] cols = {"ID", "Nome", "CNPJ", "E-mail", "Senha", "Telefone", "Rua", "Numero", "Bairro", "Cidade", "Estado", "CEP"};
        restModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = criarTabela(restModel);
        p.add(new JScrollPane(tabela), BorderLayout.CENTER);

        refreshRestaurantes();
        return p;
    }

    private void refreshRestaurantes() {
        String termo = txtBuscaRest != null ? txtBuscaRest.getText().trim() : "";
        restaurantesAtuais = termo.isEmpty() ? new RestauranteDAO().listar() : new RestauranteDAO().buscar(termo);
        restModel.setRowCount(0);
        for (Restaurante r : restaurantesAtuais) {
            restModel.addRow(new Object[]{r.getId(), r.getNome(), r.getCnpj(), r.getEmail(), r.getSenhaVisivel() != null ? r.getSenhaVisivel() : "(hash)", r.getTelefone(),
                    r.getEndereco(), r.getNumero(), r.getBairro(), r.getCidade(), r.getEstado(), r.getCep()});
        }
    }

    private void editarRestaurante() {
        int row = getSelectedRow("RESTAURANTES");
        if (row < 0) return;
        Restaurante r = restaurantesAtuais.get(row);
        JTextField txtNome = new JTextField(r.getNome(), 20);
        JTextField txtCnpj = new JTextField(r.getCnpj(), 18);
        JTextField txtTel = new JTextField(r.getTelefone(), 15);
        JTextField txtSenha = new JTextField(r.getSenhaVisivel() != null ? r.getSenhaVisivel() : "", 15);
        JTextArea txtDesc = new JTextArea(r.getDescricao(), 2, 20);
        txtDesc.setLineWrap(true);
        JTextField txtEnd = new JTextField(r.getEndereco(), 20);
        JTextField txtBairro = new JTextField(r.getBairro(), 15);
        JTextField txtCidade = new JTextField(r.getCidade(), 15);
        JTextField txtEstado = new JTextField(r.getEstado(), 5);
        JTextField txtCep = new JTextField(r.getCep(), 10);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 3, 3, 3); gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        int rw = 0;
        addF(form, gbc, rw++, "Nome:", txtNome);
        addF(form, gbc, rw++, "CNPJ:", txtCnpj);
        addF(form, gbc, rw++, "Telefone:", txtTel);
        addF(form, gbc, rw++, "Senha:", txtSenha);
        gbc.gridx = 0; gbc.gridy = rw; form.add(new JLabel("Descricao:"), gbc);
        gbc.gridx = 1; form.add(new JScrollPane(txtDesc), gbc); rw++;
        addF(form, gbc, rw++, "CEP:", txtCep);
        addF(form, gbc, rw++, "Endereco:", txtEnd);
        addF(form, gbc, rw++, "Bairro:", txtBairro);
        addF(form, gbc, rw++, "Cidade:", txtCidade);
        addF(form, gbc, rw++, "Estado:", txtEstado);

        if (JOptionPane.showConfirmDialog(this, form, "Editar Restaurante - " + r.getNome(), JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            r.setNome(txtNome.getText().trim());
            r.setCnpj(txtCnpj.getText().trim());
            r.setTelefone(txtTel.getText().trim());
            r.setDescricao(txtDesc.getText().trim());
            r.setEndereco(txtEnd.getText().trim());
            r.setBairro(txtBairro.getText().trim());
            r.setCidade(txtCidade.getText().trim());
            r.setEstado(txtEstado.getText().trim());
            r.setCep(txtCep.getText().trim());
            String novaSenha = txtSenha.getText().trim();
            if (!novaSenha.isEmpty()) {
                r.setSenhaVisivel(novaSenha);
            }
            if (new RestauranteDAO().atualizar(r)) {
                JOptionPane.showMessageDialog(this, "Restaurante atualizado!");
                refreshRestaurantes();
            }
        }
    }

    private void excluirRestaurante() {
        int row = getSelectedRow("RESTAURANTES");
        if (row < 0) return;
        Restaurante r = restaurantesAtuais.get(row);
        if (JOptionPane.showConfirmDialog(this, "Excluir restaurante \"" + r.getNome() + "\"?\n\nTodos os produtos, combos e pedidos serao removidos.", "Confirmar exclusao", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
            if (new RestauranteDAO().excluir(r.getId())) {
                JOptionPane.showMessageDialog(this, "Restaurante excluido!");
                refreshRestaurantes();
            }
        }
    }

    private void verProdutosRestaurante() {
        int row = getSelectedRow("RESTAURANTES");
        if (row < 0) return;
        Restaurante r = restaurantesAtuais.get(row);
        List<Produto> produtos = new ProdutoDAO().listarPorRestaurante(r.getId());
        List<Combo> combos = new ComboDAO().listarPorRestaurante(r.getId());

        StringBuilder sb = new StringBuilder();
        sb.append("Restaurante: ").append(r.getNome()).append("\n\n");
        sb.append("=== PRODUTOS (").append(produtos.size()).append(") ===\n");
        for (Produto pr : produtos) {
            sb.append("  ").append(pr.isAtivo() ? "[Ativo]" : "[Inativo]").append(" ")
              .append(pr.getNome()).append(" - R$ ").append(pr.getPrecoDesconto())
              .append(" (estoque: ").append(pr.getQuantidade()).append(")\n");
        }
        sb.append("\n=== COMBOS (").append(combos.size()).append(") ===\n");
        for (Combo cb : combos) {
            sb.append("  ").append(cb.isAtivo() ? "[Ativo]" : "[Inativo]").append(" ")
              .append(cb.getNome()).append(" - R$ ").append(cb.getPreco())
              .append(" (estoque: ").append(cb.getQuantidade()).append(")\n");
        }
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(UIHelper.CORPO);
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(480, 350));
        JOptionPane.showMessageDialog(this, sp, "Produtos e Combos - " + r.getNome(), JOptionPane.PLAIN_MESSAGE);
    }

    // ============================================================== PEDIDOS
    private DefaultTableModel pedModel;
    private List<Pedido> pedidosAtuais = new ArrayList<>();

    private JPanel criarPainelPedidos() {
        JPanel p = UIHelper.painelConteudo();
        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Todos os pedidos", "Visualize e gerencie todos os pedidos do sistema"), BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        acoes.setOpaque(false);
        JButton btnRefresh = UIHelper.botaoModerno("Atualizar", UIHelper.VERDE);
        btnRefresh.addActionListener(e -> refreshPedidos());
        JButton btnDetalhes = UIHelper.botaoModerno("Detalhes", UIHelper.AZUL);
        btnDetalhes.addActionListener(e -> verDetalhesPedido());
        JButton btnConfirmar = UIHelper.botaoModerno("Confirmar", UIHelper.VERDE);
        btnConfirmar.addActionListener(e -> alterarStatusPedido("CONFIRMADO"));
        JButton btnEntregar = UIHelper.botaoModerno("Entregar", UIHelper.LARANJA);
        btnEntregar.addActionListener(e -> alterarStatusPedido("ENTREGUE"));
        JButton btnCancelar = UIHelper.botaoModerno("Cancelar", UIHelper.VERMELHO);
        btnCancelar.addActionListener(e -> alterarStatusPedido("CANCELADO"));
        acoes.add(btnRefresh); acoes.add(btnDetalhes); acoes.add(btnConfirmar); acoes.add(btnEntregar); acoes.add(btnCancelar);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        String[] cols = {"#", "Cliente", "Restaurante", "Data", "Status", "Pagamento", "Total"};
        pedModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = criarTabela(pedModel);
        // Renderer de cor por status (coluna 4 = Status)
        tabela.getColumnModel().getColumn(4).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object value, boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, sel, foc, row, col);
                if (!sel && value != null) {
                    String status = value.toString();
                    switch (status) {
                        case "ENTREGUE":   c.setBackground(new Color(220, 245, 220)); c.setForeground(new Color(30, 120, 30)); break;
                        case "CONFIRMADO": c.setBackground(new Color(220, 235, 255)); c.setForeground(new Color(30, 80, 170)); break;
                        case "PENDENTE":   c.setBackground(new Color(255, 243, 220)); c.setForeground(new Color(180, 100, 0)); break;
                        case "CANCELADO":  c.setBackground(new Color(255, 220, 220)); c.setForeground(new Color(170, 30, 30)); break;
                        default:           c.setBackground(Color.WHITE); c.setForeground(Color.BLACK); break;
                    }
                } else if (sel) {
                    c.setBackground(tabela.getSelectionBackground());
                    c.setForeground(Color.BLACK);
                }
                setHorizontalAlignment(CENTER);
                setFont(new Font("SansSerif", Font.BOLD, 12));
                return c;
            }
        });
        p.add(new JScrollPane(tabela), BorderLayout.CENTER);

        refreshPedidos();
        return p;
    }

    private void refreshPedidos() {
        pedidosAtuais = new PedidoDAO().listarTodos();
        pedModel.setRowCount(0);
        for (Pedido pe : pedidosAtuais) {
            pedModel.addRow(new Object[]{pe.getId(), pe.getClienteNome(), pe.getRestauranteNome(),
                    pe.getDataPedido() != null ? pe.getDataPedido().format(FMT) : "",
                    pe.getStatus(), ClienteFrame.traduzirPagamento(pe.getFormaPagamento()),
                    "R$ " + pe.getValorTotal()});
        }
    }

    private void verDetalhesPedido() {
        int row = getSelectedRow("PEDIDOS");
        if (row < 0) return;
        Pedido ped = pedidosAtuais.get(row);
        List<PedidoItem> itens = new PedidoDAO().listarItens(ped.getId());
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido #").append(ped.getId()).append("\n");
        sb.append("Cliente: ").append(ped.getClienteNome()).append("\n");
        sb.append("Restaurante: ").append(ped.getRestauranteNome()).append("\n");
        sb.append("Status: ").append(ped.getStatus()).append("\n");
        sb.append("Entrega: ").append(ClienteFrame.traduzirEntrega(ped.getTipoEntrega())).append("\n");
        if (ped.getEnderecoEntrega() != null) sb.append("Endereco: ").append(ped.getEnderecoEntrega()).append("\n");
        sb.append("Pagamento: ").append(ClienteFrame.traduzirPagamento(ped.getFormaPagamento())).append("\n");
        if (ped.getTroco() != null && ped.getTroco().compareTo(BigDecimal.ZERO) > 0)
            sb.append("Troco: R$ ").append(ped.getTroco()).append("\n");
        sb.append("\nItens:\n");
        for (PedidoItem it : itens) {
            sb.append("  - ").append(it.getDescricao()).append(" x").append(it.getQuantidade())
              .append(" = R$ ").append(it.getPrecoUnitario().multiply(BigDecimal.valueOf(it.getQuantidade()))).append("\n");
        }
        sb.append("\nTotal: R$ ").append(ped.getValorTotal());
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(UIHelper.CORPO);
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(450, 330));
        JOptionPane.showMessageDialog(this, sp, "Detalhes do pedido", JOptionPane.PLAIN_MESSAGE);
    }

    private void alterarStatusPedido(String novoStatus) {
        int row = getSelectedRow("PEDIDOS");
        if (row < 0) return;
        Pedido ped = pedidosAtuais.get(row);
        if (new PedidoDAO().alterarStatus(ped.getId(), novoStatus)) {
            JOptionPane.showMessageDialog(this, "Status atualizado para " + novoStatus);
            refreshPedidos();
        }
    }

    // ============================================================== PRODUTOS
    private DefaultTableModel prodModel;

    private JPanel criarPainelProdutos() {
        JPanel p = UIHelper.painelConteudo();
        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Todos os produtos", "Visualize todos os produtos de todos os restaurantes"), BorderLayout.WEST);

        JButton btnRefresh = UIHelper.botaoModerno("Atualizar", UIHelper.VERDE);
        btnRefresh.addActionListener(e -> refreshProdutos());
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        acoes.setOpaque(false);
        acoes.add(btnRefresh);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        String[] cols = {"ID", "Produto", "Restaurante", "Categoria", "Preco orig.", "Preco especial", "Estoque", "Ativo"};
        prodModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = criarTabela(prodModel);
        p.add(new JScrollPane(tabela), BorderLayout.CENTER);

        refreshProdutos();
        return p;
    }

    private void refreshProdutos() {
        List<Produto> lista = new ProdutoDAO().listarTodos();
        prodModel.setRowCount(0);
        for (Produto pr : lista) {
            prodModel.addRow(new Object[]{pr.getId(), pr.getNome(), pr.getRestauranteNome(), pr.getCategoria(),
                    "R$ " + pr.getPrecoOriginal(), "R$ " + pr.getPrecoDesconto(), pr.getQuantidade(),
                    pr.isAtivo() ? "Sim" : "Nao"});
        }
    }

    // ============================================================== COMBOS
    private DefaultTableModel comboModel;

    private JPanel criarPainelCombos() {
        JPanel p = UIHelper.painelConteudo();
        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Todos os combos", "Visualize todos os combos de todos os restaurantes"), BorderLayout.WEST);

        JButton btnRefresh = UIHelper.botaoModerno("Atualizar", UIHelper.VERDE);
        btnRefresh.addActionListener(e -> refreshCombos());
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        acoes.setOpaque(false);
        acoes.add(btnRefresh);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        String[] cols = {"ID", "Combo", "Restaurante", "Preco", "Estoque", "Ativo"};
        comboModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = criarTabela(comboModel);
        p.add(new JScrollPane(tabela), BorderLayout.CENTER);

        refreshCombos();
        return p;
    }

    private void refreshCombos() {
        List<Combo> lista = new ComboDAO().listarAtivos();
        comboModel.setRowCount(0);
        for (Combo cb : lista) {
            comboModel.addRow(new Object[]{cb.getId(), cb.getNome(), cb.getRestauranteNome(),
                    "R$ " + cb.getPreco(), cb.getQuantidade(), cb.isAtivo() ? "Sim" : "Nao"});
        }
    }

    // ============================================================== UTILS
    private JTable criarTabela(DefaultTableModel model) {
        JTable tabela = new JTable(model);
        tabela.setRowHeight(30);
        tabela.setFont(UIHelper.CORPO);
        tabela.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        tabela.getTableHeader().setBackground(UIHelper.VERDE_CLARO);
        tabela.setSelectionBackground(new Color(200, 230, 201));
        tabela.setGridColor(new Color(230, 230, 230));
        tabela.setShowVerticalLines(false);
        return tabela;
    }

    private int getSelectedRow(String card) {
        int idx;
        switch (card) {
            case "CLIENTES": idx = 1; break;
            case "RESTAURANTES": idx = 2; break;
            case "PEDIDOS": idx = 3; break;
            case "PRODUTOS": idx = 4; break;
            case "COMBOS": idx = 5; break;
            default: return -1;
        }
        JTable tabela = findTableIn(conteudo.getComponent(idx));
        if (tabela == null || tabela.getSelectedRow() < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um item na tabela.");
            return -1;
        }
        return tabela.getSelectedRow();
    }

    private JTable findTableIn(Component comp) {
        if (comp instanceof JTable) return (JTable) comp;
        if (comp instanceof JViewport) return findTableIn(((JViewport) comp).getView());
        if (comp instanceof Container) {
            for (Component c : ((Container) comp).getComponents()) {
                JTable t = findTableIn(c);
                if (t != null) return t;
            }
        }
        return null;
    }

    private void addF(JPanel p, GridBagConstraints gbc, int row, String label, JComponent campo) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        p.add(new JLabel(label), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        p.add(campo, gbc);
    }
}
