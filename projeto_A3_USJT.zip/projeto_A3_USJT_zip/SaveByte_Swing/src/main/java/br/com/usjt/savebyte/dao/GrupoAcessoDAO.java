package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.GrupoAcesso;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GrupoAcessoDAO {

    public List<GrupoAcesso> listarPorRestaurante(long restauranteId) {
        List<GrupoAcesso> lista = new ArrayList<>();
        String sql = "SELECT * FROM grupo_acesso WHERE restaurante_id = ? ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, restauranteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public GrupoAcesso buscarPorId(int id) {
        String sql = "SELECT * FROM grupo_acesso WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean inserir(GrupoAcesso g) {
        String sql = "INSERT INTO grupo_acesso (restaurante_id, nome, pode_ver_vendas, pode_ver_faturamento, " +
                "pode_gerenciar_produtos, pode_gerenciar_pedidos, pode_gerenciar_usuarios, pode_alterar_precos) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, g.getRestauranteId());
            ps.setString(2, g.getNome());
            ps.setBoolean(3, g.isPodeVerVendas());
            ps.setBoolean(4, g.isPodeVerFaturamento());
            ps.setBoolean(5, g.isPodeGerenciarProdutos());
            ps.setBoolean(6, g.isPodeGerenciarPedidos());
            ps.setBoolean(7, g.isPodeGerenciarUsuarios());
            ps.setBoolean(8, g.isPodeAlterarPrecos());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean atualizar(GrupoAcesso g) {
        String sql = "UPDATE grupo_acesso SET nome=?, pode_ver_vendas=?, pode_ver_faturamento=?, " +
                "pode_gerenciar_produtos=?, pode_gerenciar_pedidos=?, pode_gerenciar_usuarios=?, " +
                "pode_alterar_precos=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, g.getNome());
            ps.setBoolean(2, g.isPodeVerVendas());
            ps.setBoolean(3, g.isPodeVerFaturamento());
            ps.setBoolean(4, g.isPodeGerenciarProdutos());
            ps.setBoolean(5, g.isPodeGerenciarPedidos());
            ps.setBoolean(6, g.isPodeGerenciarUsuarios());
            ps.setBoolean(7, g.isPodeAlterarPrecos());
            ps.setInt(8, g.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean excluir(int id) {
        String sql = "DELETE FROM grupo_acesso WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private GrupoAcesso mapear(ResultSet rs) throws SQLException {
        GrupoAcesso g = new GrupoAcesso();
        g.setId(rs.getInt("id"));
        g.setRestauranteId(rs.getLong("restaurante_id"));
        g.setNome(rs.getString("nome"));
        g.setPodeVerVendas(rs.getBoolean("pode_ver_vendas"));
        g.setPodeVerFaturamento(rs.getBoolean("pode_ver_faturamento"));
        g.setPodeGerenciarProdutos(rs.getBoolean("pode_gerenciar_produtos"));
        g.setPodeGerenciarPedidos(rs.getBoolean("pode_gerenciar_pedidos"));
        g.setPodeGerenciarUsuarios(rs.getBoolean("pode_gerenciar_usuarios"));
        g.setPodeAlterarPrecos(rs.getBoolean("pode_alterar_precos"));
        return g;
    }
}
