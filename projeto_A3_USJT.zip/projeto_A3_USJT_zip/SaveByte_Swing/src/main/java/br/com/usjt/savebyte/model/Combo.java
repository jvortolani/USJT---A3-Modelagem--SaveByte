package br.com.usjt.savebyte.model;

import java.math.BigDecimal;

public class Combo {
    private long id;
    private long restauranteId;
    private String restauranteNome;
    private String nome;
    private String descricao;
    private BigDecimal preco;
    private int quantidade;
    private boolean ativo;
    private String imagemUrl;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getRestauranteId() { return restauranteId; }
    public void setRestauranteId(long restauranteId) { this.restauranteId = restauranteId; }
    public String getRestauranteNome() { return restauranteNome; }
    public void setRestauranteNome(String restauranteNome) { this.restauranteNome = restauranteNome; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
}
