package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Cliente;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;

public class ClienteDAO {

    public Cliente autenticar(String email, String senha) {
        String sql = "SELECT * FROM cliente WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String hash = rs.getString("senha");
                if (BCrypt.checkpw(senha, hash)) return mapear(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean emailExiste(String email) {
        String sql = "SELECT 1 FROM cliente WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            return ps.executeQuery().next();
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean inserir(Cliente c, String senhaPlana) {
        String sql = "INSERT INTO cliente (nome, email, senha, senha_visivel, telefone, endereco, numero, bairro, cidade, estado, cep, criado_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getNome());
            ps.setString(2, c.getEmail());
            ps.setString(3, BCrypt.hashpw(senhaPlana, BCrypt.gensalt()));
            ps.setString(4, senhaPlana);
            ps.setString(5, c.getTelefone());
            ps.setString(6, c.getEndereco());
            ps.setString(7, c.getNumero());
            ps.setString(8, c.getBairro());
            ps.setString(9, c.getCidade());
            ps.setString(10, c.getEstado());
            ps.setString(11, c.getCep());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) c.setId(keys.getLong(1));
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean atualizar(Cliente c) {
        String sql;
        boolean atualizaSenha = c.getSenhaVisivel() != null && !c.getSenhaVisivel().isBlank();
        if (atualizaSenha) {
            sql = "UPDATE cliente SET nome=?, telefone=?, endereco=?, numero=?, bairro=?, cidade=?, estado=?, cep=?, imagem_url=?, senha=?, senha_visivel=? WHERE id=?";
        } else {
            sql = "UPDATE cliente SET nome=?, telefone=?, endereco=?, numero=?, bairro=?, cidade=?, estado=?, cep=?, imagem_url=? WHERE id=?";
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getNome());
            ps.setString(2, c.getTelefone());
            ps.setString(3, c.getEndereco());
            ps.setString(4, c.getNumero());
            ps.setString(5, c.getBairro());
            ps.setString(6, c.getCidade());
            ps.setString(7, c.getEstado());
            ps.setString(8, c.getCep());
            ps.setString(9, c.getImagemUrl());
            if (atualizaSenha) {
                ps.setString(10, BCrypt.hashpw(c.getSenhaVisivel(), BCrypt.gensalt()));
                ps.setString(11, c.getSenhaVisivel());
                ps.setLong(12, c.getId());
            } else {
                ps.setLong(10, c.getId());
            }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean alterarSenha(long id, String senhaAtual, String novaSenha) {
        String sql = "SELECT senha FROM cliente WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next() && BCrypt.checkpw(senhaAtual, rs.getString("senha"))) {
                PreparedStatement up = conn.prepareStatement("UPDATE cliente SET senha=?, senha_visivel=? WHERE id=?");
                up.setString(1, BCrypt.hashpw(novaSenha, BCrypt.gensalt()));
                up.setString(2, novaSenha);
                up.setLong(3, id);
                return up.executeUpdate() > 0;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public java.util.List<Cliente> listar() {
        java.util.List<Cliente> lista = new java.util.ArrayList<>();
        String sql = "SELECT * FROM cliente ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public java.util.List<Cliente> buscar(String termo) {
        java.util.List<Cliente> lista = new java.util.ArrayList<>();
        String sql = "SELECT * FROM cliente WHERE nome LIKE ? OR email LIKE ? OR cidade LIKE ? ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + termo + "%";
            ps.setString(1, like); ps.setString(2, like); ps.setString(3, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public boolean excluir(long id) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.prepareStatement("DELETE FROM pedido_item WHERE pedido_id IN (SELECT id FROM pedido WHERE cliente_id = " + id + ")").executeUpdate();
            conn.prepareStatement("DELETE FROM pedido WHERE cliente_id = " + id).executeUpdate();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM cliente WHERE id = ?");
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public Cliente buscarPorId(long id) {
        String sql = "SELECT * FROM cliente WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    private Cliente mapear(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getLong("id"));
        c.setNome(rs.getString("nome"));
        c.setEmail(rs.getString("email"));
        c.setSenha(rs.getString("senha"));
        try { c.setSenhaVisivel(rs.getString("senha_visivel")); } catch (SQLException ignored) {}
        c.setTelefone(rs.getString("telefone"));
        c.setEndereco(rs.getString("endereco"));
        try { c.setNumero(rs.getString("numero")); } catch (SQLException ignored) {}
        c.setBairro(rs.getString("bairro"));
        c.setCidade(rs.getString("cidade"));
        c.setEstado(rs.getString("estado"));
        c.setCep(rs.getString("cep"));
        try { c.setImagemUrl(rs.getString("imagem_url")); } catch (SQLException ignored) {}
        return c;
    }
}
