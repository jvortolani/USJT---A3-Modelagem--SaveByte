package br.com.usjt.savebyte.model;

import java.math.BigDecimal;

public class PedidoItem {
    private long id;
    private long pedidoId;
    private Long produtoId;
    private Long comboId;
    private String descricao;
    private int quantidade;
    private BigDecimal precoUnitario;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getPedidoId() { return pedidoId; }
    public void setPedidoId(long pedidoId) { this.pedidoId = pedidoId; }
    public Long getProdutoId() { return produtoId; }
    public void setProdutoId(Long produtoId) { this.produtoId = produtoId; }
    public Long getComboId() { return comboId; }
    public void setComboId(Long comboId) { this.comboId = comboId; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public BigDecimal getPrecoUnitario() { return precoUnitario; }
    public void setPrecoUnitario(BigDecimal precoUnitario) { this.precoUnitario = precoUnitario; }
}
