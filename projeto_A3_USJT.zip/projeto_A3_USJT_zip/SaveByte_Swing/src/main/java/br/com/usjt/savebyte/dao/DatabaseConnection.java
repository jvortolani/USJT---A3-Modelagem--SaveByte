package br.com.usjt.savebyte.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/savebyte?useSSL=false&serverTimezone=America/Sao_Paulo&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "JV1234";
    private static boolean migrated = false;

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        if (!migrated) {
            migrated = true;
            runMigrations(conn);
        }
        return conn;
    }

    private static void runMigrations(Connection conn) {
        try (Statement st = conn.createStatement()) {
            // grupo_acesso
            st.executeUpdate("CREATE TABLE IF NOT EXISTS grupo_acesso (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "restaurante_id BIGINT NOT NULL, " +
                    "nome VARCHAR(50) NOT NULL, " +
                    "pode_ver_vendas TINYINT(1) NOT NULL DEFAULT 0, " +
                    "pode_ver_faturamento TINYINT(1) NOT NULL DEFAULT 0, " +
                    "pode_gerenciar_produtos TINYINT(1) NOT NULL DEFAULT 0, " +
                    "pode_gerenciar_pedidos TINYINT(1) NOT NULL DEFAULT 0, " +
                    "pode_gerenciar_usuarios TINYINT(1) NOT NULL DEFAULT 0, " +
                    "pode_alterar_precos TINYINT(1) NOT NULL DEFAULT 0, " +
                    "criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP" +
                    ") ENGINE=InnoDB");

            // colunas extras em usuarios
            addColumnIfNotExists(st, "usuarios", "restaurante_id", "BIGINT NULL AFTER id");
            addColumnIfNotExists(st, "usuarios", "grupo_acesso_id", "INT NULL AFTER restaurante_id");

            // colunas extras em cliente
            addColumnIfNotExists(st, "cliente", "numero", "VARCHAR(20) NULL AFTER endereco");
            addColumnIfNotExists(st, "cliente", "imagem_url", "VARCHAR(500) NULL AFTER cep");
            addColumnIfNotExists(st, "cliente", "senha_visivel", "VARCHAR(120) NULL AFTER senha");

            // colunas extras em restaurante
            addColumnIfNotExists(st, "restaurante", "senha_visivel", "VARCHAR(120) NULL AFTER senha");

        } catch (SQLException e) {
            System.err.println("Aviso: migracao automatica falhou (nao critico): " + e.getMessage());
        }
    }

    private static void addColumnIfNotExists(Statement st, String table, String column, String definition) {
        try {
            st.executeUpdate("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
        } catch (SQLException ignored) {
            // coluna ja existe - ok
        }
    }
}
