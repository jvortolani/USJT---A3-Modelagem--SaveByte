package br.com.usjt.savebyte.model;

import java.time.LocalDateTime;

public class Usuario {
    private int id;
    private Long restauranteId;
    private Integer grupoAcessoId;
    private String grupoAcessoNome;
    private String usuario;
    private String nome;
    private String email;
    private String senha;
    private String telefone;
    private LocalDateTime criadoEm;

    public Usuario() {}

    public Usuario(String usuario, String nome, String email, String senha, String telefone) {
        this.usuario = usuario;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Long getRestauranteId() { return restauranteId; }
    public void setRestauranteId(Long restauranteId) { this.restauranteId = restauranteId; }

    public Integer getGrupoAcessoId() { return grupoAcessoId; }
    public void setGrupoAcessoId(Integer grupoAcessoId) { this.grupoAcessoId = grupoAcessoId; }

    public String getGrupoAcessoNome() { return grupoAcessoNome; }
    public void setGrupoAcessoNome(String grupoAcessoNome) { this.grupoAcessoNome = grupoAcessoNome; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
}
