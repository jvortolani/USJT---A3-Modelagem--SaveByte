package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Produto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    public List<Produto> listarTodos() {
        return listar("SELECT p.*, r.nome AS rest_nome FROM produto p JOIN restaurante r ON p.restaurante_id = r.id ORDER BY p.nome");
    }

    public List<Produto> listarAtivos() {
        return listar("SELECT p.*, r.nome AS rest_nome FROM produto p JOIN restaurante r ON p.restaurante_id = r.id WHERE p.ativo = 1 AND p.quantidade > 0 ORDER BY p.nome");
    }

    public List<Produto> listarPorRestaurante(long restauranteId) {
        List<Produto> lista = new ArrayList<>();
        String sql = "SELECT p.*, r.nome AS rest_nome FROM produto p JOIN restaurante r ON p.restaurante_id = r.id WHERE p.restaurante_id = ? ORDER BY p.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, restauranteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public List<Produto> buscar(String termo) {
        List<Produto> lista = new ArrayList<>();
        String sql = "SELECT p.*, r.nome AS rest_nome FROM produto p JOIN restaurante r ON p.restaurante_id = r.id WHERE p.ativo = 1 AND p.quantidade > 0 AND (p.nome LIKE ? OR p.categoria LIKE ? OR r.nome LIKE ?) ORDER BY p.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + termo + "%";
            ps.setString(1, like); ps.setString(2, like); ps.setString(3, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public Produto buscarPorId(long id) {
        String sql = "SELECT p.*, r.nome AS rest_nome FROM produto p JOIN restaurante r ON p.restaurante_id = r.id WHERE p.id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean inserir(Produto p) {
        String sql = "INSERT INTO produto (restaurante_id, nome, descricao, categoria, preco_original, preco_desconto, quantidade, ativo, imagem_url, criado_em) VALUES (?,?,?,?,?,?,?,?,?,NOW())";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, p.getRestauranteId());
            ps.setString(2, p.getNome());
            ps.setString(3, p.getDescricao());
            ps.setString(4, p.getCategoria());
            ps.setBigDecimal(5, p.getPrecoOriginal());
            ps.setBigDecimal(6, p.getPrecoDesconto());
            ps.setInt(7, p.getQuantidade());
            ps.setBoolean(8, p.isAtivo());
            ps.setString(9, p.getImagemUrl());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) p.setId(keys.getLong(1));
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean atualizar(Produto p) {
        String sql = "UPDATE produto SET nome=?, descricao=?, categoria=?, preco_original=?, preco_desconto=?, quantidade=?, ativo=?, imagem_url=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getDescricao());
            ps.setString(3, p.getCategoria());
            ps.setBigDecimal(4, p.getPrecoOriginal());
            ps.setBigDecimal(5, p.getPrecoDesconto());
            ps.setInt(6, p.getQuantidade());
            ps.setBoolean(7, p.isAtivo());
            ps.setString(8, p.getImagemUrl());
            ps.setLong(9, p.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean alternarAtivo(long id) {
        String sql = "UPDATE produto SET ativo = NOT ativo WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    private List<Produto> listar(String sql) {
        List<Produto> lista = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    private Produto mapear(ResultSet rs) throws SQLException {
        Produto p = new Produto();
        p.setId(rs.getLong("id"));
        p.setRestauranteId(rs.getLong("restaurante_id"));
        try { p.setRestauranteNome(rs.getString("rest_nome")); } catch (SQLException ignored) {}
        p.setNome(rs.getString("nome"));
        p.setDescricao(rs.getString("descricao"));
        p.setCategoria(rs.getString("categoria"));
        p.setPrecoOriginal(rs.getBigDecimal("preco_original"));
        p.setPrecoDesconto(rs.getBigDecimal("preco_desconto"));
        p.setQuantidade(rs.getInt("quantidade"));
        p.setAtivo(rs.getBoolean("ativo"));
        p.setImagemUrl(rs.getString("imagem_url"));
        return p;
    }
}
