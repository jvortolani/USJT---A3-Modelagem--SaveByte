package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.model.Usuario;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class MainFrame extends JFrame {

    private static final Color VERDE = new Color(26, 107, 42);
    private static final Color VERDE_ESCURO = new Color(13, 63, 21);

    private final JPanel conteudo = new JPanel(new CardLayout());
    private final Usuario usuarioLogado;

    public MainFrame(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
        setTitle("SaveByte - Painel Principal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);

        // Menu superior
        setJMenuBar(criarMenu());

        // Painel lateral + conteúdo
        JPanel painelPrincipal = new JPanel(new BorderLayout());

        // Sidebar
        JPanel sidebar = criarSidebar();
        painelPrincipal.add(sidebar, BorderLayout.WEST);

        // Conteúdo central
        conteudo.add(criarPainelHome(), "HOME");
        conteudo.add(new UsuarioPanel(), "USUARIOS");
        conteudo.add(new ProjetoPanel(), "PROJETOS");
        painelPrincipal.add(conteudo, BorderLayout.CENTER);

        add(painelPrincipal);
    }

    private JMenuBar criarMenu() {
        JMenuBar bar = new JMenuBar();
        bar.setBackground(VERDE_ESCURO);

        JMenu menuArquivo = new JMenu("Arquivo");
        menuArquivo.setForeground(Color.WHITE);
        JMenuItem itemSair = new JMenuItem("Sair");
        itemSair.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
        menuArquivo.add(itemSair);

        JMenu menuCadastros = new JMenu("Cadastros");
        menuCadastros.setForeground(Color.WHITE);
        JMenuItem itemUsuarios = new JMenuItem("Usuários");
        itemUsuarios.addActionListener(e -> mostrar("USUARIOS"));
        JMenuItem itemProjetos = new JMenuItem("Projetos");
        itemProjetos.addActionListener(e -> mostrar("PROJETOS"));
        menuCadastros.add(itemUsuarios);
        menuCadastros.add(itemProjetos);

        JMenu menuAjuda = new JMenu("Ajuda");
        menuAjuda.setForeground(Color.WHITE);
        JMenuItem itemSobre = new JMenuItem("Sobre");
        itemSobre.addActionListener(e ->
                JOptionPane.showMessageDialog(this,
                        "SaveByte v1.0\nProjeto A3 - USJT\nAproveite mais, desperdice menos.",
                        "Sobre", JOptionPane.INFORMATION_MESSAGE));
        menuAjuda.add(itemSobre);

        bar.add(menuArquivo);
        bar.add(menuCadastros);
        bar.add(menuAjuda);
        return bar;
    }

    private JPanel criarSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(VERDE_ESCURO);
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));

        // Logo
        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(img));
            lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(lblLogo);
            sidebar.add(Box.createVerticalStrut(5));
        }

        JLabel lblNome = new JLabel("SaveByte");
        lblNome.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblNome.setForeground(Color.WHITE);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lblNome);
        sidebar.add(Box.createVerticalStrut(25));

        sidebar.add(criarBotaoSidebar("Início", "HOME"));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(criarBotaoSidebar("Usuários", "USUARIOS"));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(criarBotaoSidebar("Projetos", "PROJETOS"));

        sidebar.add(Box.createVerticalGlue());

        // Rodapé: usuário logado
        JLabel lblUser = new JLabel("Logado: " + usuarioLogado.getNome());
        lblUser.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblUser.setForeground(new Color(200, 230, 201));
        lblUser.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lblUser);
        sidebar.add(Box.createVerticalStrut(8));

        JButton btnLogout = criarBotaoSidebar("Sair", null);
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
        sidebar.add(btnLogout);

        return sidebar;
    }

    private JButton criarBotaoSidebar(String texto, String card) {
        JButton btn = new JButton(texto);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(180, 36));
        btn.setBackground(VERDE);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        if (card != null) {
            btn.addActionListener(e -> mostrar(card));
        }
        return btn;
    }

    private void mostrar(String card) {
        CardLayout cl = (CardLayout) conteudo.getLayout();
        cl.show(conteudo, card);
    }

    private JPanel criarPainelHome() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(Color.WHITE);

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setBackground(Color.WHITE);

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(160, 160, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(img));
            lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
            centro.add(lblLogo);
            centro.add(Box.createVerticalStrut(10));
        }

        JLabel lbl1 = new JLabel("Bem-vindo ao SaveByte!");
        lbl1.setFont(new Font("SansSerif", Font.BOLD, 24));
        lbl1.setForeground(VERDE);
        lbl1.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(lbl1);
        centro.add(Box.createVerticalStrut(8));

        JLabel lbl2 = new JLabel("Aproveite mais, desperdice menos.");
        lbl2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lbl2.setForeground(Color.GRAY);
        lbl2.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(lbl2);
        centro.add(Box.createVerticalStrut(5));

        JLabel lbl3 = new JLabel("Olá, " + usuarioLogado.getNome() + "! Use o menu lateral para navegar.");
        lbl3.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lbl3.setForeground(Color.DARK_GRAY);
        lbl3.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(lbl3);

        painel.add(centro);
        return painel;
    }
}
