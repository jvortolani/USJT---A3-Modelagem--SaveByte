package br.com.usjt.savebyte.model;

import java.math.BigDecimal;

public class Produto {
    private long id;
    private long restauranteId;
    private String restauranteNome;
    private String nome;
    private String descricao;
    private String categoria;
    private BigDecimal precoOriginal;
    private BigDecimal precoDesconto;
    private int quantidade;
    private boolean ativo;
    private String imagemUrl;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getRestauranteId() { return restauranteId; }
    public void setRestauranteId(long restauranteId) { this.restauranteId = restauranteId; }
    public String getRestauranteNome() { return restauranteNome; }
    public void setRestauranteNome(String restauranteNome) { this.restauranteNome = restauranteNome; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public BigDecimal getPrecoOriginal() { return precoOriginal; }
    public void setPrecoOriginal(BigDecimal precoOriginal) { this.precoOriginal = precoOriginal; }
    public BigDecimal getPrecoDesconto() { return precoDesconto; }
    public void setPrecoDesconto(BigDecimal precoDesconto) { this.precoDesconto = precoDesconto; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
}
