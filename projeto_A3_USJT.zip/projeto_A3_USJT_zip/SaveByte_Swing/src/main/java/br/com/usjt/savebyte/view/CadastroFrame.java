package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.ClienteDAO;
import br.com.usjt.savebyte.dao.RestauranteDAO;
import br.com.usjt.savebyte.model.Cliente;
import br.com.usjt.savebyte.model.Restaurante;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CadastroFrame extends JFrame {

    private final JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Cliente", "Restaurante"});
    private final JTextField txtNome = new JTextField(20);
    private final JTextField txtEmail = new JTextField(20);
    private final JPasswordField txtSenha = new JPasswordField(20);
    private final JTextField txtTelefone = new JTextField(20);
    private final JTextField txtCep = new JTextField(10);
    private final JTextField txtEndereco = new JTextField(20);
    private final JTextField txtBairro = new JTextField(15);
    private final JTextField txtCidade = new JTextField(15);
    private final JTextField txtEstado = new JTextField(5);
    // Campos extras restaurante
    private final JTextField txtCnpj = new JTextField(20);
    private final JTextField txtNumero = new JTextField(8);
    private final JTextArea txtDescricao = new JTextArea(3, 20);

    private final JLabel lblCnpj = new JLabel("CNPJ:");
    private final JLabel lblNumero = new JLabel("Número:");
    private final JLabel lblDescricao = new JLabel("Descrição:");
    private final JPanel pnlExtras = new JPanel(new GridLayout(2, 2, 8, 4));

    public CadastroFrame() {
        setTitle("SaveByte - Cadastro");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 600);
        setLocationRelativeTo(null);

        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        JLabel lblTitulo = new JLabel("Cadastro");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTitulo.setForeground(LoginFrame.VERDE);
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        painel.add(lblTitulo, gbc);
        gbc.gridwidth = 1;

        row++;
        cmbTipo.addActionListener(e -> toggleExtras());
        addField(painel, gbc, row++, "Tipo:", cmbTipo);
        addField(painel, gbc, row++, "Nome:", txtNome);
        addField(painel, gbc, row++, "E-mail:", txtEmail);
        addField(painel, gbc, row++, "Senha:", txtSenha);
        addField(painel, gbc, row++, "Telefone:", txtTelefone);
        addField(painel, gbc, row++, "CEP:", txtCep);

        // Botão buscar CEP
        JButton btnCep = new JButton("Buscar CEP");
        btnCep.setBackground(LoginFrame.VERDE);
        btnCep.setForeground(Color.WHITE);
        btnCep.addActionListener(e -> buscarCep());
        gbc.gridx = 1; gbc.gridy = row++;
        painel.add(btnCep, gbc);

        addField(painel, gbc, row++, "Endereço:", txtEndereco);
        addField(painel, gbc, row++, "Número:", txtNumero);
        addField(painel, gbc, row++, "Bairro:", txtBairro);
        addField(painel, gbc, row++, "Cidade:", txtCidade);
        addField(painel, gbc, row++, "Estado:", txtEstado);

        // Extras restaurante
        pnlExtras.add(lblCnpj); pnlExtras.add(txtCnpj);
        lblDescricao.setVerticalAlignment(SwingConstants.TOP);
        pnlExtras.add(lblDescricao); pnlExtras.add(new JScrollPane(txtDescricao));
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        painel.add(pnlExtras, gbc);
        gbc.gridwidth = 1;
        pnlExtras.setVisible(false);

        // Botões
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton btnSalvar = new JButton("Cadastrar");
        btnSalvar.setBackground(LoginFrame.VERDE);
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.addActionListener(e -> salvar());

        JButton btnVoltar = new JButton("Voltar ao login");
        btnVoltar.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });

        botoes.add(btnSalvar);
        botoes.add(btnVoltar);
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        painel.add(botoes, gbc);

        add(new JScrollPane(painel));
    }

    private void toggleExtras() {
        pnlExtras.setVisible(cmbTipo.getSelectedIndex() == 1);
        revalidate();
    }

    private void addField(JPanel p, GridBagConstraints gbc, int row, String label, JComponent campo) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        p.add(new JLabel(label), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        p.add(campo, gbc);
    }

    private void buscarCep() {
        String cep = txtCep.getText().replaceAll("\\D", "");
        if (cep.length() != 8) { JOptionPane.showMessageDialog(this, "CEP deve ter 8 dígitos."); return; }
        try {
            URL url = new URL("https://viacep.com.br/ws/" + cep + "/json/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            String json = sb.toString();
            if (json.contains("\"erro\"")) { JOptionPane.showMessageDialog(this, "CEP não encontrado."); return; }
            txtEndereco.setText(extrair(json, "logradouro"));
            txtBairro.setText(extrair(json, "bairro"));
            txtCidade.setText(extrair(json, "localidade"));
            txtEstado.setText(extrair(json, "uf"));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar CEP: " + ex.getMessage());
        }
    }

    private String extrair(String json, String campo) {
        int idx = json.indexOf("\"" + campo + "\"");
        if (idx < 0) return "";
        int start = json.indexOf("\"", idx + campo.length() + 3) + 1;
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }

    private void salvar() {
        String nome = txtNome.getText().trim();
        String email = txtEmail.getText().trim();
        String senha = new String(txtSenha.getPassword()).trim();

        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha nome, e-mail e senha.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (senha.length() < 6) {
            JOptionPane.showMessageDialog(this, "A senha deve ter pelo menos 6 caracteres.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (cmbTipo.getSelectedIndex() == 0) {
            if (new ClienteDAO().emailExiste(email)) {
                JOptionPane.showMessageDialog(this, "E-mail já cadastrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Cliente c = new Cliente();
            c.setNome(nome); c.setEmail(email);
            c.setTelefone(txtTelefone.getText().trim());
            c.setEndereco(txtEndereco.getText().trim());
            c.setBairro(txtBairro.getText().trim());
            c.setCidade(txtCidade.getText().trim());
            c.setEstado(txtEstado.getText().trim());
            c.setCep(txtCep.getText().trim());
            if (new ClienteDAO().inserir(c, senha)) {
                JOptionPane.showMessageDialog(this, "Cadastro realizado! Faça login.");
                dispose(); new LoginFrame().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            Restaurante r = new Restaurante();
            r.setNome(nome); r.setEmail(email);
            r.setTelefone(txtTelefone.getText().trim());
            r.setEndereco(txtEndereco.getText().trim());
            r.setBairro(txtBairro.getText().trim());
            r.setCidade(txtCidade.getText().trim());
            r.setEstado(txtEstado.getText().trim());
            r.setCep(txtCep.getText().trim());
            r.setCnpj(txtCnpj.getText().trim());
            r.setNumero(txtNumero.getText().trim());
            r.setDescricao(txtDescricao.getText().trim());
            if (new RestauranteDAO().inserir(r, senha)) {
                JOptionPane.showMessageDialog(this, "Cadastro realizado! Faça login.");
                dispose(); new LoginFrame().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar. E-mail já existe?", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
