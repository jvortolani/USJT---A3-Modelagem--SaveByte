package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.PedidoDAO;
import br.com.usjt.savebyte.model.Cliente;
import br.com.usjt.savebyte.model.Pedido;
import br.com.usjt.savebyte.model.PedidoItem;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class CheckoutDialog extends JDialog {

    private final Cliente cliente;
    private final List<ClienteFrame.ItemCarrinho> carrinho;

    private final JComboBox<String> cmbEntrega = new JComboBox<>(new String[]{"Retirada no local", "Entrega"});
    private final JTextField txtEnderecoEntrega = new JTextField(25);
    private final JComboBox<String> cmbPagamento = new JComboBox<>(new String[]{"Pagar na retirada/entrega", "Pix (simulado)", "Cartao (simulado)"});
    private final JTextField txtCartao = new JTextField(18);
    private final JTextField txtValorDinheiro = new JTextField(10);
    private final JLabel lblTroco = new JLabel("R$ 0.00");
    private final JTextField txtObservacao = new JTextField(25);

    private final JPanel pnlEndereco = new JPanel(new BorderLayout(8, 0));
    private final JPanel pnlCartao = new JPanel(new BorderLayout(8, 0));
    private final JPanel pnlDinheiro = new JPanel(new BorderLayout(8, 0));

    public CheckoutDialog(JFrame parent, Cliente cliente, List<ClienteFrame.ItemCarrinho> carrinho) {
        super(parent, "Finalizar Pedido", true);
        this.cliente = cliente;
        this.carrinho = carrinho;
        setSize(520, 620);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        // ====== Titulo ======
        JLabel lblTitulo = new JLabel("Finalizar Pedido");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTitulo.setForeground(UIHelper.VERDE_ESCURO);
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(lblTitulo);
        painel.add(Box.createVerticalStrut(15));

        // ====== Card de resumo ======
        BigDecimal total = BigDecimal.ZERO;
        Map<Long, List<ClienteFrame.ItemCarrinho>> grupos = carrinho.stream()
                .collect(Collectors.groupingBy(ic -> ic.restauranteId, LinkedHashMap::new, Collectors.toList()));

        JPanel resumoCard = criarCard();
        JLabel lblResumo = new JLabel("Resumo do pedido");
        lblResumo.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblResumo.setForeground(UIHelper.VERDE_ESCURO);
        resumoCard.add(lblResumo);
        resumoCard.add(Box.createVerticalStrut(8));

        for (var entry : grupos.entrySet()) {
            JLabel lblRest = new JLabel(entry.getValue().get(0).restauranteNome);
            lblRest.setFont(new Font("SansSerif", Font.BOLD, 13));
            lblRest.setForeground(UIHelper.TEXTO);
            resumoCard.add(lblRest);
            for (ClienteFrame.ItemCarrinho ic : entry.getValue()) {
                BigDecimal sub = ic.preco.multiply(BigDecimal.valueOf(ic.quantidade));
                total = total.add(sub);
                JPanel itemRow = new JPanel(new BorderLayout());
                itemRow.setOpaque(false);
                itemRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
                JLabel lblItem = new JLabel("  " + ic.nome + "  x" + ic.quantidade);
                lblItem.setFont(UIHelper.CORPO_PEQUENO);
                lblItem.setForeground(new Color(100, 100, 100));
                itemRow.add(lblItem, BorderLayout.WEST);
                JLabel lblSub = new JLabel("R$ " + sub + "  ");
                lblSub.setFont(new Font("SansSerif", Font.BOLD, 12));
                lblSub.setForeground(UIHelper.TEXTO);
                itemRow.add(lblSub, BorderLayout.EAST);
                resumoCard.add(itemRow);
            }
            resumoCard.add(Box.createVerticalStrut(4));
        }

        if (grupos.size() > 1) {
            resumoCard.add(Box.createVerticalStrut(4));
            JLabel aviso = new JLabel("Serao criados " + grupos.size() + " pedidos separados");
            aviso.setFont(new Font("SansSerif", Font.BOLD, 11));
            aviso.setForeground(UIHelper.LARANJA);
            resumoCard.add(aviso);
        }

        // Linha separadora
        resumoCard.add(Box.createVerticalStrut(8));
        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        resumoCard.add(sep);
        resumoCard.add(Box.createVerticalStrut(6));

        JPanel totalRow = new JPanel(new BorderLayout());
        totalRow.setOpaque(false);
        totalRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        JLabel lblTotalLabel = new JLabel("Total");
        lblTotalLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblTotalLabel.setForeground(UIHelper.TEXTO);
        totalRow.add(lblTotalLabel, BorderLayout.WEST);
        JLabel lblTotalValor = new JLabel("R$ " + total);
        lblTotalValor.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTotalValor.setForeground(UIHelper.VERDE);
        totalRow.add(lblTotalValor, BorderLayout.EAST);
        resumoCard.add(totalRow);

        painel.add(resumoCard);
        painel.add(Box.createVerticalStrut(12));

        // ====== Card de entrega ======
        JPanel entregaCard = criarCard();
        JLabel lblEntrega = new JLabel("Entrega");
        lblEntrega.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblEntrega.setForeground(UIHelper.VERDE_ESCURO);
        entregaCard.add(lblEntrega);
        entregaCard.add(Box.createVerticalStrut(8));

        estilizarCombo(cmbEntrega);
        cmbEntrega.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        cmbEntrega.setAlignmentX(Component.LEFT_ALIGNMENT);
        entregaCard.add(cmbEntrega);
        entregaCard.add(Box.createVerticalStrut(6));

        pnlEndereco.setOpaque(false);
        pnlEndereco.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        pnlEndereco.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lblEnd = new JLabel("Endereco:");
        lblEnd.setFont(UIHelper.CORPO);
        pnlEndereco.add(lblEnd, BorderLayout.WEST);
        estilizarCampo(txtEnderecoEntrega);
        pnlEndereco.add(txtEnderecoEntrega, BorderLayout.CENTER);
        if (cliente.getEndereco() != null) {
            String endCompleto = cliente.getEndereco();
            if (cliente.getBairro() != null) endCompleto += ", " + cliente.getBairro();
            if (cliente.getCidade() != null) endCompleto += " - " + cliente.getCidade() + "/" + cliente.getEstado();
            txtEnderecoEntrega.setText(endCompleto);
        }
        pnlEndereco.setVisible(false);
        entregaCard.add(pnlEndereco);

        cmbEntrega.addActionListener(e -> pnlEndereco.setVisible(cmbEntrega.getSelectedIndex() == 1));

        painel.add(entregaCard);
        painel.add(Box.createVerticalStrut(12));

        // ====== Card de pagamento ======
        JPanel pagCard = criarCard();
        JLabel lblPag = new JLabel("Pagamento");
        lblPag.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblPag.setForeground(UIHelper.VERDE_ESCURO);
        pagCard.add(lblPag);
        pagCard.add(Box.createVerticalStrut(8));

        estilizarCombo(cmbPagamento);
        cmbPagamento.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        cmbPagamento.setAlignmentX(Component.LEFT_ALIGNMENT);
        pagCard.add(cmbPagamento);
        pagCard.add(Box.createVerticalStrut(6));

        // Cartao
        pnlCartao.setOpaque(false);
        pnlCartao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        pnlCartao.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lblCartao = new JLabel("N. Cartao:");
        lblCartao.setFont(UIHelper.CORPO);
        pnlCartao.add(lblCartao, BorderLayout.WEST);
        estilizarCampo(txtCartao);
        pnlCartao.add(txtCartao, BorderLayout.CENTER);
        pnlCartao.setVisible(false);
        pagCard.add(pnlCartao);

        // Dinheiro
        final BigDecimal totalFinal = total;
        pnlDinheiro.setOpaque(false);
        pnlDinheiro.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        pnlDinheiro.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel dinheiroInner = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        dinheiroInner.setOpaque(false);
        JLabel lblDin = new JLabel("Valor (R$):");
        lblDin.setFont(UIHelper.CORPO);
        dinheiroInner.add(lblDin);
        estilizarCampo(txtValorDinheiro);
        txtValorDinheiro.setPreferredSize(new Dimension(100, 30));
        dinheiroInner.add(txtValorDinheiro);
        JLabel lblTrocoLabel = new JLabel("Troco:");
        lblTrocoLabel.setFont(UIHelper.CORPO);
        dinheiroInner.add(lblTrocoLabel);
        lblTroco.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblTroco.setForeground(UIHelper.VERDE);
        dinheiroInner.add(lblTroco);
        pnlDinheiro.add(dinheiroInner, BorderLayout.CENTER);
        pnlDinheiro.setVisible(false);
        pagCard.add(pnlDinheiro);

        txtValorDinheiro.addCaretListener(e -> calcularTroco(totalFinal));

        cmbPagamento.addActionListener(e -> {
            int idx = cmbPagamento.getSelectedIndex();
            pnlDinheiro.setVisible(idx == 0);
            pnlCartao.setVisible(idx == 2);
        });

        painel.add(pagCard);
        painel.add(Box.createVerticalStrut(12));

        // ====== Card de observacao ======
        JPanel obsCard = criarCard();
        JLabel lblObs = new JLabel("Observacao");
        lblObs.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblObs.setForeground(UIHelper.VERDE_ESCURO);
        obsCard.add(lblObs);
        obsCard.add(Box.createVerticalStrut(6));
        estilizarCampo(txtObservacao);
        txtObservacao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        txtObservacao.setAlignmentX(Component.LEFT_ALIGNMENT);
        obsCard.add(txtObservacao);
        painel.add(obsCard);
        painel.add(Box.createVerticalStrut(18));

        // ====== Botao confirmar ======
        JButton btnConfirmar = UIHelper.botaoModerno("Confirmar pedido", UIHelper.VERDE);
        btnConfirmar.setFont(new Font("SansSerif", Font.BOLD, 16));
        btnConfirmar.setPreferredSize(new Dimension(250, 44));
        btnConfirmar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btnConfirmar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnConfirmar.addActionListener(e -> confirmar(totalFinal, grupos));
        painel.add(btnConfirmar);

        JScrollPane scroll = new JScrollPane(painel);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll);
    }

    private JPanel criarCard() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 500));
        return card;
    }

    private void estilizarCampo(JTextField campo) {
        campo.setFont(UIHelper.CORPO);
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
    }

    private void estilizarCombo(JComboBox<String> combo) {
        combo.setFont(UIHelper.CORPO);
        combo.setBackground(Color.WHITE);
    }

    private void calcularTroco(BigDecimal total) {
        try {
            String txt = txtValorDinheiro.getText().replace(",", ".").trim();
            if (txt.isEmpty()) { lblTroco.setText("R$ 0.00"); lblTroco.setForeground(UIHelper.VERDE); return; }
            BigDecimal valor = new BigDecimal(txt);
            BigDecimal troco = valor.subtract(total);
            if (troco.compareTo(BigDecimal.ZERO) < 0) {
                lblTroco.setText("Insuficiente!");
                lblTroco.setForeground(UIHelper.VERMELHO);
            } else {
                lblTroco.setText("R$ " + troco.setScale(2));
                lblTroco.setForeground(UIHelper.VERDE);
            }
        } catch (NumberFormatException ex) {
            lblTroco.setText("Invalido");
            lblTroco.setForeground(UIHelper.VERMELHO);
        }
    }

    private void confirmar(BigDecimal totalGeral, Map<Long, List<ClienteFrame.ItemCarrinho>> grupos) {
        String tipoEntrega = cmbEntrega.getSelectedIndex() == 0 ? "RETIRADA" : "ENTREGA";
        String enderecoEntrega = cmbEntrega.getSelectedIndex() == 1 ? txtEnderecoEntrega.getText().trim() : null;
        String formaPagamento;
        switch (cmbPagamento.getSelectedIndex()) {
            case 1: formaPagamento = "PIX"; break;
            case 2: formaPagamento = "CARTAO"; break;
            default: formaPagamento = "NA_ENTREGA";
        }

        String statusPag = "NA_ENTREGA".equals(formaPagamento) ? "PENDENTE" : "PAGO";
        String cartaoFinal = null;
        if ("CARTAO".equals(formaPagamento)) {
            String num = txtCartao.getText().replaceAll("\\D", "");
            if (num.length() < 4) {
                JOptionPane.showMessageDialog(this, "Informe o numero do cartao.");
                return;
            }
            cartaoFinal = num.substring(num.length() - 4);
        }

        BigDecimal valorDinheiro = null;
        BigDecimal troco = null;
        if ("NA_ENTREGA".equals(formaPagamento)) {
            String txt = txtValorDinheiro.getText().replace(",", ".").trim();
            if (!txt.isEmpty()) {
                try {
                    valorDinheiro = new BigDecimal(txt);
                    troco = valorDinheiro.subtract(totalGeral);
                    if (troco.compareTo(BigDecimal.ZERO) < 0) {
                        JOptionPane.showMessageDialog(this, "Valor em dinheiro insuficiente!");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Valor em dinheiro invalido.");
                    return;
                }
            }
        }

        PedidoDAO pedidoDAO = new PedidoDAO();
        List<Long> pedidoIds = new ArrayList<>();

        for (var entry : grupos.entrySet()) {
            long restauranteId = entry.getKey();
            List<ClienteFrame.ItemCarrinho> itens = entry.getValue();

            BigDecimal subtotal = BigDecimal.ZERO;
            Pedido ped = new Pedido();
            ped.setClienteId(cliente.getId());
            ped.setRestauranteId(restauranteId);
            ped.setStatus("PENDENTE");
            ped.setObservacao(txtObservacao.getText().trim());
            ped.setTipoEntrega(tipoEntrega);
            ped.setEnderecoEntrega(enderecoEntrega);
            ped.setFormaPagamento(formaPagamento);
            ped.setStatusPagamento(statusPag);
            ped.setCartaoFinal(cartaoFinal);

            for (ClienteFrame.ItemCarrinho ic : itens) {
                PedidoItem pi = new PedidoItem();
                if ("PRODUTO".equals(ic.tipo)) pi.setProdutoId(ic.itemId);
                else pi.setComboId(ic.itemId);
                pi.setDescricao(ic.nome);
                pi.setQuantidade(ic.quantidade);
                pi.setPrecoUnitario(ic.preco);
                ped.getItens().add(pi);
                subtotal = subtotal.add(ic.preco.multiply(BigDecimal.valueOf(ic.quantidade)));

                pedidoDAO.decrementarEstoque(
                        "PRODUTO".equals(ic.tipo) ? ic.itemId : null,
                        "COMBO".equals(ic.tipo) ? ic.itemId : null,
                        ic.quantidade);
            }

            ped.setValorTotal(subtotal);
            if (pedidoIds.isEmpty()) {
                ped.setValorDinheiro(valorDinheiro);
                ped.setTroco(troco);
            }

            long id = pedidoDAO.inserir(ped);
            if (id > 0) pedidoIds.add(id);
        }

        if (!pedidoIds.isEmpty()) {
            carrinho.clear();
            JOptionPane.showMessageDialog(this,
                    "Pedido(s) criado(s) com sucesso!\nNumero(s): " + pedidoIds);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao criar pedido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
