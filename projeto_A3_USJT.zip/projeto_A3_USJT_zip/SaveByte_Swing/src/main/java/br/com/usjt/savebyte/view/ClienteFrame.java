package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.*;
import br.com.usjt.savebyte.model.*;

import javax.swing.*;

import java.awt.*;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.net.URL;

public class ClienteFrame extends JFrame {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private Cliente cliente;
    private final JPanel conteudo = new JPanel(new CardLayout());
    private final List<ItemCarrinho> carrinho = new ArrayList<>();
    private JButton btnCarrinhoSidebar;

    public ClienteFrame(Cliente cliente) {
        this.cliente = cliente;
        setTitle("SaveByte - Olá, " + cliente.getNome());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        URL iconUrl = getClass().getResource("/img/logo.png");
        if (iconUrl != null) setIconImage(new ImageIcon(iconUrl).getImage());

        JPanel principal = new JPanel(new BorderLayout());
        principal.add(criarSidebar(), BorderLayout.WEST);

        conteudo.add(criarPainelHome(), "HOME");
        conteudo.add(criarPainelRestaurantes(), "RESTAURANTES");
        conteudo.add(criarPainelProdutos(), "PRODUTOS");
        conteudo.add(criarPainelCombos(), "COMBOS");
        conteudo.add(criarPainelCarrinho(), "CARRINHO");
        conteudo.add(criarPainelPedidos(), "PEDIDOS");
        conteudo.add(criarPainelPerfil(), "PERFIL");
        principal.add(conteudo, BorderLayout.CENTER);

        add(principal);
    }

    private void mostrar(String card) {
        if ("RESTAURANTES".equals(card)) refreshRestaurantes();
        if ("PRODUTOS".equals(card)) refreshProdutos();
        if ("COMBOS".equals(card)) refreshCombos();
        if ("CARRINHO".equals(card)) refreshCarrinho();
        if ("PEDIDOS".equals(card)) refreshPedidos();
        ((CardLayout) conteudo.getLayout()).show(conteudo, card);
    }

    private void atualizarBadgeCarrinho() {
        int total = carrinho.stream().mapToInt(ic -> ic.quantidade).sum();
        btnCarrinhoSidebar.setText(total > 0 ? "Carrinho (" + total + ")" : "Carrinho");
    }

    // ============================================================== SIDEBAR
    private JPanel criarSidebar() {
        JPanel sidebar = UIHelper.criarSidebarBase();

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(img));
            lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(lblLogo);
            sidebar.add(Box.createVerticalStrut(15));
        }

        sidebar.add(criarBtnSidebar("Inicio", "HOME"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(criarBtnSidebar("Restaurantes", "RESTAURANTES"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(criarBtnSidebar("Produtos", "PRODUTOS"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(criarBtnSidebar("Combos", "COMBOS"));
        sidebar.add(Box.createVerticalStrut(4));
        btnCarrinhoSidebar = UIHelper.btnSidebar("Carrinho");
        btnCarrinhoSidebar.addActionListener(e -> mostrar("CARRINHO"));
        sidebar.add(btnCarrinhoSidebar);
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(criarBtnSidebar("Meus Pedidos", "PEDIDOS"));
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(criarBtnSidebar("Meu Perfil", "PERFIL"));

        sidebar.add(Box.createVerticalGlue());

        JLabel lblUser = new JLabel("<html><center>Ola, " + cliente.getNome() + "</center></html>");
        lblUser.setForeground(new Color(200, 230, 201));
        lblUser.setFont(UIHelper.CORPO_PEQUENO);
        lblUser.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lblUser);
        sidebar.add(Box.createVerticalStrut(8));

        JButton btnSair = UIHelper.btnSidebar("Sair");
        btnSair.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });
        sidebar.add(btnSair);
        return sidebar;
    }

    private JButton criarBtnSidebar(String txt, String card) {
        JButton btn = UIHelper.btnSidebar(txt);
        btn.addActionListener(e -> mostrar(card));
        return btn;
    }

    // ============================================================== HOME
    private JPanel criarPainelHome() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UIHelper.FUNDO);

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setOpaque(false);
        centro.setBorder(BorderFactory.createEmptyBorder(15, 30, 10, 30));

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            JLabel lbl = new JLabel(new ImageIcon(img));
            lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            centro.add(lbl);
            centro.add(Box.createVerticalStrut(8));
        }
        JLabel l1 = new JLabel("Bem-vindo ao SaveByte!");
        l1.setFont(new Font("SansSerif", Font.BOLD, 24));
        l1.setForeground(UIHelper.VERDE_ESCURO);
        l1.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(l1);
        centro.add(Box.createVerticalStrut(3));
        JLabel l2 = new JLabel("Aproveite mais, desperdice menos.");
        l2.setFont(new Font("SansSerif", Font.PLAIN, 13));
        l2.setForeground(Color.GRAY);
        l2.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(l2);
        centro.add(Box.createVerticalStrut(10));

        // Botoes de acao rapida
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        acoes.setOpaque(false);
        JButton btnVerRest = UIHelper.botaoModerno("Ver Restaurantes", UIHelper.VERDE);
        btnVerRest.setPreferredSize(new Dimension(170, 38));
        btnVerRest.addActionListener(e -> mostrar("RESTAURANTES"));
        JButton btnVerProd = UIHelper.botaoModerno("Ver Produtos", UIHelper.AZUL);
        btnVerProd.setPreferredSize(new Dimension(170, 38));
        btnVerProd.addActionListener(e -> mostrar("PRODUTOS"));
        JButton btnVerCombos = UIHelper.botaoModerno("Ver Combos", new Color(56, 142, 60));
        btnVerCombos.setPreferredSize(new Dimension(170, 38));
        btnVerCombos.addActionListener(e -> mostrar("COMBOS"));
        acoes.add(btnVerRest); acoes.add(btnVerProd); acoes.add(btnVerCombos);
        centro.add(acoes);
        centro.add(Box.createVerticalStrut(10));

        // Quem Somos
        centro.add(UIHelper.criarPainelQuemSomos());

        JScrollPane scroll = new JScrollPane(centro);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ============================================================== RESTAURANTES
    private JPanel restCardsPanel;
    private JTextField txtBuscaRest;

    private JPanel criarPainelRestaurantes() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = criarTopo("Restaurantes", "Busque por nome ou cidade...");
        txtBuscaRest = (JTextField) ((JPanel) topo.getComponent(2)).getComponent(1);
        JButton btnBuscar = (JButton) ((JPanel) topo.getComponent(2)).getComponent(2);
        btnBuscar.addActionListener(e -> refreshRestaurantes());
        p.add(topo, BorderLayout.NORTH);

        restCardsPanel = new JPanel();
        restCardsPanel.setLayout(new BoxLayout(restCardsPanel, BoxLayout.Y_AXIS));
        restCardsPanel.setBackground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(restCardsPanel);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        p.add(scroll, BorderLayout.CENTER);

        refreshRestaurantes();
        return p;
    }

    private void refreshRestaurantes() {
        List<Restaurante> restaurantes = new RestauranteDAO().listar();
        String termo = txtBuscaRest != null ? txtBuscaRest.getText().trim().toLowerCase() : "";
        restCardsPanel.removeAll();

        for (Restaurante r : restaurantes) {
            if (!termo.isEmpty() && !r.getNome().toLowerCase().contains(termo)
                    && (r.getCidade() == null || !r.getCidade().toLowerCase().contains(termo))) continue;

            JPanel card = new JPanel(new BorderLayout(15, 0));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(230, 230, 230)),
                    BorderFactory.createEmptyBorder(12, 12, 12, 12)));
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

            // Imagem do restaurante
            JLabel lblImg = new JLabel();
            lblImg.setPreferredSize(new Dimension(90, 90));
            lblImg.setHorizontalAlignment(SwingConstants.CENTER);
            ImageIcon imgIcon = UIHelper.carregarImagem(r.getImagemUrl(), 90, 90);
            if (imgIcon != null) {
                lblImg.setIcon(imgIcon);
            } else {
                lblImg.setOpaque(true);
                lblImg.setBackground(UIHelper.VERDE_CLARO);
                lblImg.setForeground(UIHelper.VERDE);
                lblImg.setFont(new Font("SansSerif", Font.BOLD, 30));
                lblImg.setText(r.getNome().substring(0, 1).toUpperCase());
            }
            card.add(lblImg, BorderLayout.WEST);

            // Info
            JPanel info = new JPanel();
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.setBackground(Color.WHITE);
            JLabel lblNome = new JLabel(r.getNome());
            lblNome.setFont(new Font("SansSerif", Font.BOLD, 16));
            lblNome.setForeground(UIHelper.VERDE_ESCURO);
            info.add(lblNome);

            if (r.getDescricao() != null && !r.getDescricao().isBlank()) {
                String desc = r.getDescricao().length() > 80 ? r.getDescricao().substring(0, 80) + "..." : r.getDescricao();
                JLabel lblDesc = new JLabel(desc);
                lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));
                lblDesc.setForeground(Color.GRAY);
                info.add(lblDesc);
            }

            String endereco = r.getEnderecoCompleto();
            if (!endereco.isBlank()) {
                JLabel lblEnd = new JLabel(endereco);
                lblEnd.setFont(new Font("SansSerif", Font.PLAIN, 11));
                lblEnd.setForeground(new Color(120, 120, 120));
                info.add(lblEnd);
            }
            card.add(info, BorderLayout.CENTER);

            // Botão ver produtos
            JButton btnVer = new JButton("Ver produtos");
            btnVer.setBackground(UIHelper.VERDE);
            btnVer.setForeground(Color.WHITE);
            btnVer.setFocusPainted(false);
            btnVer.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btnVer.setPreferredSize(new Dimension(130, 36));
            final long restId = r.getId();
            final String restNome = r.getNome();
            btnVer.addActionListener(e -> abrirProdutosDoRestaurante(restId, restNome));
            JPanel btnPanel = new JPanel(new GridBagLayout());
            btnPanel.setBackground(Color.WHITE);
            btnPanel.add(btnVer);
            card.add(btnPanel, BorderLayout.EAST);

            restCardsPanel.add(card);
        }

        if (restCardsPanel.getComponentCount() == 0) {
            JLabel lblVazio = new JLabel("Nenhum restaurante encontrado.");
            lblVazio.setForeground(Color.GRAY);
            lblVazio.setFont(new Font("SansSerif", Font.ITALIC, 14));
            lblVazio.setAlignmentX(Component.CENTER_ALIGNMENT);
            restCardsPanel.add(Box.createVerticalStrut(30));
            restCardsPanel.add(lblVazio);
        }

        restCardsPanel.revalidate();
        restCardsPanel.repaint();
    }

    private void abrirProdutosDoRestaurante(long restauranteId, String restauranteNome) {
        // Criar painel temporário com produtos do restaurante
        List<Produto> produtos = new ProdutoDAO().listarPorRestaurante(restauranteId);
        List<Combo> combos = new ComboDAO().listarPorRestaurante(restauranteId);

        JPanel painel = new JPanel(new BorderLayout(0, 10));
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Topo com nome do restaurante e botão voltar
        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(Color.WHITE);
        JButton btnVoltar = new JButton("< Voltar");
        btnVoltar.setBackground(Color.DARK_GRAY);
        btnVoltar.setForeground(Color.WHITE);
        btnVoltar.setFocusPainted(false);
        btnVoltar.addActionListener(e -> {
            conteudo.remove(painel);
            mostrar("RESTAURANTES");
        });
        topo.add(btnVoltar, BorderLayout.WEST);
        JLabel lblTitulo = new JLabel(restauranteNome);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTitulo.setForeground(UIHelper.VERDE);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        topo.add(lblTitulo, BorderLayout.CENTER);
        painel.add(topo, BorderLayout.NORTH);

        // Cards
        JPanel cards = new UIHelper.WrapPanel(new UIHelper.WrapLayout(FlowLayout.LEFT, 15, 15));
        cards.setBackground(Color.WHITE);

        // Produtos
        for (Produto pr : produtos) {
            if (pr.isAtivo() && pr.getQuantidade() > 0) cards.add(criarCardProduto(pr));
        }
        // Combos
        for (Combo cb : combos) {
            if (cb.isAtivo() && cb.getQuantidade() > 0) cards.add(criarCardCombo(cb));
        }

        if (cards.getComponentCount() == 0) {
            JLabel lblVazio = new JLabel("Nenhum item disponível neste restaurante.");
            lblVazio.setForeground(Color.GRAY);
            cards.add(lblVazio);
        }

        JScrollPane scroll = new JScrollPane(cards);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Color.WHITE);
        painel.add(scroll, BorderLayout.CENTER);

        conteudo.add(painel, "RESTAURANTE_DETALHE");
        ((CardLayout) conteudo.getLayout()).show(conteudo, "RESTAURANTE_DETALHE");
    }

    // ============================================================== PRODUTOS
    private JPanel prodCardsPanel;
    private JTextField txtBuscaProd;

    private JPanel criarPainelProdutos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = criarTopo("Produtos com preco especial", "Busque por nome, categoria ou restaurante...");
        txtBuscaProd = (JTextField) ((JPanel) topo.getComponent(2)).getComponent(1);
        JButton btnBuscar = (JButton) ((JPanel) topo.getComponent(2)).getComponent(2);
        btnBuscar.addActionListener(e -> refreshProdutos());
        p.add(topo, BorderLayout.NORTH);

        prodCardsPanel = new UIHelper.WrapPanel(new UIHelper.WrapLayout(FlowLayout.LEFT, 15, 15));
        prodCardsPanel.setBackground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(prodCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Color.WHITE);
        p.add(scroll, BorderLayout.CENTER);

        refreshProdutos();
        return p;
    }

    private void refreshProdutos() {
        String termo = txtBuscaProd != null ? txtBuscaProd.getText().trim() : "";
        ProdutoDAO dao = new ProdutoDAO();
        List<Produto> lista = termo.isEmpty() ? dao.listarAtivos() : dao.buscar(termo);
        prodCardsPanel.removeAll();
        for (Produto pr : lista) prodCardsPanel.add(criarCardProduto(pr));
        if (lista.isEmpty()) {
            JLabel lblVazio = new JLabel("Nenhum produto disponivel no momento.");
            lblVazio.setForeground(Color.GRAY);
            lblVazio.setFont(new Font("SansSerif", Font.ITALIC, 14));
            prodCardsPanel.add(lblVazio);
        }
        prodCardsPanel.revalidate();
        prodCardsPanel.repaint();
    }

    // ============================================================== COMBOS
    private JPanel comboCardsPanel;
    private JTextField txtBuscaCombo;

    private JPanel criarPainelCombos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = criarTopo("Combos especiais", "Busque por nome...");
        txtBuscaCombo = (JTextField) ((JPanel) topo.getComponent(2)).getComponent(1);
        JButton btnBuscar = (JButton) ((JPanel) topo.getComponent(2)).getComponent(2);
        btnBuscar.addActionListener(e -> refreshCombos());
        p.add(topo, BorderLayout.NORTH);

        comboCardsPanel = new UIHelper.WrapPanel(new UIHelper.WrapLayout(FlowLayout.LEFT, 15, 15));
        comboCardsPanel.setBackground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(comboCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Color.WHITE);
        p.add(scroll, BorderLayout.CENTER);

        refreshCombos();
        return p;
    }

    private void refreshCombos() {
        List<Combo> lista = new ComboDAO().listarAtivos();
        String termo = txtBuscaCombo != null ? txtBuscaCombo.getText().trim().toLowerCase() : "";
        comboCardsPanel.removeAll();
        for (Combo cb : lista) {
            if (!termo.isEmpty() && !cb.getNome().toLowerCase().contains(termo)) continue;
            comboCardsPanel.add(criarCardCombo(cb));
        }
        if (comboCardsPanel.getComponentCount() == 0) {
            JLabel lblVazio = new JLabel("Nenhum combo disponivel no momento.");
            lblVazio.setForeground(Color.GRAY);
            lblVazio.setFont(new Font("SansSerif", Font.ITALIC, 14));
            comboCardsPanel.add(lblVazio);
        }
        comboCardsPanel.revalidate();
        comboCardsPanel.repaint();
    }

    // ============================================================== CARDS
    private JPanel criarCardProduto(Produto pr) {
        JPanel card = criarCardBase();

        // Imagem
        JLabel lblImg = UIHelper.labelImagem(pr.getImagemUrl(), 196, 130);
        card.add(lblImg);
        card.add(Box.createVerticalStrut(8));

        // Badge desconto
        if (pr.getPrecoOriginal() != null && pr.getPrecoDesconto() != null
                && pr.getPrecoOriginal().compareTo(BigDecimal.ZERO) > 0) {
            int desconto = 100 - pr.getPrecoDesconto().multiply(BigDecimal.valueOf(100))
                    .divide(pr.getPrecoOriginal(), 0, java.math.RoundingMode.HALF_UP).intValue();
            if (desconto > 0) {
                JLabel lblBadge = new JLabel("-" + desconto + "%");
                lblBadge.setFont(new Font("SansSerif", Font.BOLD, 11));
                lblBadge.setForeground(Color.WHITE);
                lblBadge.setOpaque(true);
                lblBadge.setBackground(UIHelper.VERMELHO);
                lblBadge.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
                lblBadge.setAlignmentX(Component.CENTER_ALIGNMENT);
                card.add(lblBadge);
                card.add(Box.createVerticalStrut(4));
            }
        }

        // Nome
        JLabel lblNome = new JLabel("<html><center>" + pr.getNome() + "</center></html>");
        lblNome.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblNome);

        // Restaurante
        JLabel lblRest = new JLabel(pr.getRestauranteNome());
        lblRest.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblRest.setForeground(Color.GRAY);
        lblRest.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblRest);
        card.add(Box.createVerticalStrut(6));

        // Precos
        JPanel precos = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        precos.setBackground(Color.WHITE);
        precos.setMaximumSize(new Dimension(200, 25));
        JLabel lblOrig = new JLabel("<html><s>R$ " + pr.getPrecoOriginal() + "</s></html>");
        lblOrig.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblOrig.setForeground(Color.GRAY);
        precos.add(lblOrig);
        JLabel lblPreco = new JLabel("R$ " + pr.getPrecoDesconto());
        lblPreco.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblPreco.setForeground(UIHelper.VERDE);
        precos.add(lblPreco);
        card.add(precos);

        // Disponivel
        JLabel lblDisp = new JLabel(pr.getQuantidade() + " disponivel(is)");
        lblDisp.setFont(new Font("SansSerif", Font.PLAIN, 9));
        lblDisp.setForeground(new Color(150, 150, 150));
        lblDisp.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblDisp);
        card.add(Box.createVerticalGlue());

        // Botao
        JButton btnAdd = criarBotaoCard("Adicionar");
        btnAdd.addActionListener(e -> adicionarAoCarrinho("PRODUTO", pr.getId(), pr.getNome(),
                pr.getPrecoDesconto(), pr.getQuantidade(), pr.getRestauranteId(), pr.getRestauranteNome()));
        card.add(btnAdd);

        return card;
    }

    private JPanel criarCardCombo(Combo cb) {
        JPanel card = criarCardBase();

        JLabel lblImg = UIHelper.labelImagem(cb.getImagemUrl(), 196, 130);
        card.add(lblImg);
        card.add(Box.createVerticalStrut(8));

        // Badge combo
        JLabel lblBadge = new JLabel("COMBO");
        lblBadge.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblBadge.setForeground(Color.WHITE);
        lblBadge.setOpaque(true);
        lblBadge.setBackground(UIHelper.AZUL);
        lblBadge.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
        lblBadge.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblBadge);
        card.add(Box.createVerticalStrut(4));

        JLabel lblNome = new JLabel("<html><center>" + cb.getNome() + "</center></html>");
        lblNome.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblNome);

        JLabel lblRest = new JLabel(cb.getRestauranteNome());
        lblRest.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblRest.setForeground(Color.GRAY);
        lblRest.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblRest);
        card.add(Box.createVerticalStrut(6));

        JLabel lblPreco = new JLabel("R$ " + cb.getPreco());
        lblPreco.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblPreco.setForeground(UIHelper.VERDE);
        lblPreco.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblPreco);

        JLabel lblDisp = new JLabel(cb.getQuantidade() + " disponivel(is)");
        lblDisp.setFont(new Font("SansSerif", Font.PLAIN, 9));
        lblDisp.setForeground(new Color(150, 150, 150));
        lblDisp.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblDisp);
        card.add(Box.createVerticalGlue());

        JButton btnAdd = criarBotaoCard("Adicionar");
        btnAdd.addActionListener(e -> adicionarAoCarrinho("COMBO", cb.getId(), cb.getNome(),
                cb.getPreco(), cb.getQuantidade(), cb.getRestauranteId(), cb.getRestauranteNome()));
        card.add(btnAdd);

        return card;
    }

    private JPanel criarCardBase() {
        JPanel card = UIHelper.cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(220, 350));
        return card;
    }

    private JButton criarBotaoCard(String texto) {
        JButton btn = UIHelper.botaoModerno(texto, UIHelper.VERDE);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(196, 32));
        return btn;
    }

    // ============================================================== CARRINHO
    private void adicionarAoCarrinho(String tipo, long itemId, String nome, BigDecimal preco,
                                      int maxQtd, long restauranteId, String restauranteNome) {
        // Diálogo customizado de quantidade
        JDialog dialog = new JDialog(this, "Adicionar ao carrinho", true);
        dialog.setUndecorated(true);
        dialog.setSize(340, 260);
        dialog.setLocationRelativeTo(this);

        JPanel painel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(new Color(200, 200, 200));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        painel.setOpaque(false);

        JLabel lblTitulo = new JLabel("Adicionar ao carrinho");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitulo.setForeground(UIHelper.VERDE_ESCURO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblTitulo);
        painel.add(Box.createVerticalStrut(6));

        String nomeExibir = nome.length() > 30 ? nome.substring(0, 30) + "..." : nome;
        JLabel lblNome = new JLabel(nomeExibir);
        lblNome.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblNome.setForeground(UIHelper.TEXTO_SEC);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblNome);

        JLabel lblPrecoItem = new JLabel("R$ " + preco);
        lblPrecoItem.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblPrecoItem.setForeground(UIHelper.VERDE);
        lblPrecoItem.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblPrecoItem);
        painel.add(Box.createVerticalStrut(15));

        // Controle de quantidade com - e +
        final int[] qtdVal = {1};
        JPanel controle = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        controle.setOpaque(false);
        controle.setMaximumSize(new Dimension(200, 44));

        JButton btnMenos = UIHelper.botaoModerno("-", UIHelper.TEXTO_SEC);
        btnMenos.setPreferredSize(new Dimension(44, 40));
        btnMenos.setFont(new Font("SansSerif", Font.BOLD, 20));

        JLabel lblQtd = new JLabel("1", SwingConstants.CENTER);
        lblQtd.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblQtd.setForeground(UIHelper.TEXTO);
        lblQtd.setPreferredSize(new Dimension(60, 40));

        JButton btnMais = UIHelper.botaoModerno("+", UIHelper.VERDE);
        btnMais.setPreferredSize(new Dimension(44, 40));
        btnMais.setFont(new Font("SansSerif", Font.BOLD, 20));

        btnMenos.addActionListener(e -> {
            if (qtdVal[0] > 1) { qtdVal[0]--; lblQtd.setText(String.valueOf(qtdVal[0])); }
        });
        btnMais.addActionListener(e -> {
            if (qtdVal[0] < maxQtd) { qtdVal[0]++; lblQtd.setText(String.valueOf(qtdVal[0])); }
        });

        controle.add(btnMenos);
        controle.add(lblQtd);
        controle.add(btnMais);
        painel.add(controle);

        JLabel lblDisp = new JLabel(maxQtd + " disponivel(is)");
        lblDisp.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblDisp.setForeground(new Color(160, 160, 160));
        lblDisp.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblDisp);
        painel.add(Box.createVerticalStrut(15));

        // Botões Confirmar / Cancelar
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        botoes.setOpaque(false);
        botoes.setMaximumSize(new Dimension(300, 40));

        JButton btnCancelar = UIHelper.botaoModerno("Cancelar", UIHelper.TEXTO_SEC);
        btnCancelar.setPreferredSize(new Dimension(120, 36));
        btnCancelar.addActionListener(e -> { qtdVal[0] = 0; dialog.dispose(); });

        JButton btnConfirmar = UIHelper.botaoModerno("Confirmar", UIHelper.VERDE);
        btnConfirmar.setPreferredSize(new Dimension(120, 36));
        btnConfirmar.addActionListener(e -> dialog.dispose());

        botoes.add(btnCancelar);
        botoes.add(btnConfirmar);
        painel.add(botoes);

        dialog.setContentPane(painel);
        dialog.setBackground(new Color(0, 0, 0, 0));
        dialog.setVisible(true);

        int qtd = qtdVal[0];
        if (qtd <= 0) return;

        for (ItemCarrinho ic : carrinho) {
            if (ic.tipo.equals(tipo) && ic.itemId == itemId) {
                ic.quantidade += qtd;
                atualizarBadgeCarrinho();
                return;
            }
        }
        ItemCarrinho ic = new ItemCarrinho();
        ic.tipo = tipo; ic.itemId = itemId;
        ic.nome = nome; ic.preco = preco;
        ic.quantidade = qtd; ic.restauranteId = restauranteId;
        ic.restauranteNome = restauranteNome;
        carrinho.add(ic);
        atualizarBadgeCarrinho();
    }

    private JPanel cartCardsPanel;
    private JLabel lblTotalCarrinho;

    private JPanel criarPainelCarrinho() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JLabel lbl = new JLabel("Meu Carrinho");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 22));
        lbl.setForeground(UIHelper.VERDE_ESCURO);
        topo.add(lbl, BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        JButton btnLimpar = UIHelper.botaoModerno("Limpar tudo", UIHelper.VERMELHO);
        btnLimpar.addActionListener(e -> { carrinho.clear(); atualizarBadgeCarrinho(); refreshCarrinho(); });
        JButton btnCheckout = UIHelper.botaoModerno("Finalizar pedido", UIHelper.VERDE);
        btnCheckout.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnCheckout.addActionListener(e -> abrirCheckout());
        acoes.add(btnLimpar); acoes.add(btnCheckout);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);

        cartCardsPanel = new JPanel();
        cartCardsPanel.setLayout(new BoxLayout(cartCardsPanel, BoxLayout.Y_AXIS));
        cartCardsPanel.setOpaque(false);
        JScrollPane scroll = new JScrollPane(cartCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        center.add(scroll, BorderLayout.CENTER);

        lblTotalCarrinho = new JLabel("Total: R$ 0.00");
        lblTotalCarrinho.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTotalCarrinho.setForeground(UIHelper.VERDE);
        lblTotalCarrinho.setHorizontalAlignment(SwingConstants.RIGHT);
        lblTotalCarrinho.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 15));
        center.add(lblTotalCarrinho, BorderLayout.SOUTH);

        p.add(center, BorderLayout.CENTER);
        return p;
    }

    private void refreshCarrinho() {
        cartCardsPanel.removeAll();
        BigDecimal total = BigDecimal.ZERO;

        if (carrinho.isEmpty()) {
            JLabel vazio = new JLabel("Seu carrinho esta vazio.");
            vazio.setFont(new Font("SansSerif", Font.ITALIC, 14));
            vazio.setForeground(Color.GRAY);
            vazio.setAlignmentX(Component.CENTER_ALIGNMENT);
            cartCardsPanel.add(Box.createVerticalStrut(40));
            cartCardsPanel.add(vazio);
        }

        for (int i = 0; i < carrinho.size(); i++) {
            ItemCarrinho ic = carrinho.get(i);
            BigDecimal sub = ic.preco.multiply(BigDecimal.valueOf(ic.quantidade));
            total = total.add(sub);
            final int idx = i;

            JPanel card = new JPanel(new BorderLayout(12, 0));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(230, 230, 230)),
                    BorderFactory.createEmptyBorder(10, 15, 10, 15)));
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 85));

            // Info esquerda
            JPanel info = new JPanel();
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.setOpaque(false);
            JLabel lblNome = new JLabel(ic.nome);
            lblNome.setFont(new Font("SansSerif", Font.BOLD, 14));
            lblNome.setForeground(UIHelper.TEXTO);
            info.add(lblNome);
            JLabel lblRest = new JLabel(ic.restauranteNome);
            lblRest.setFont(UIHelper.CORPO_PEQUENO);
            lblRest.setForeground(Color.GRAY);
            info.add(lblRest);
            card.add(info, BorderLayout.WEST);

            // Centro: quantidade
            JLabel lblQtd = new JLabel("x" + ic.quantidade);
            lblQtd.setFont(new Font("SansSerif", Font.BOLD, 16));
            lblQtd.setForeground(UIHelper.VERDE_ESCURO);
            lblQtd.setHorizontalAlignment(SwingConstants.CENTER);
            card.add(lblQtd, BorderLayout.CENTER);

            // Direita: preco + remover
            JPanel direita = new JPanel();
            direita.setLayout(new BoxLayout(direita, BoxLayout.Y_AXIS));
            direita.setOpaque(false);
            JLabel lblPreco = new JLabel("R$ " + sub);
            lblPreco.setFont(new Font("SansSerif", Font.BOLD, 15));
            lblPreco.setForeground(UIHelper.VERDE);
            lblPreco.setAlignmentX(Component.RIGHT_ALIGNMENT);
            direita.add(lblPreco);
            JLabel lblUn = new JLabel("R$ " + ic.preco + " /un");
            lblUn.setFont(UIHelper.CORPO_PEQUENO);
            lblUn.setForeground(Color.GRAY);
            lblUn.setAlignmentX(Component.RIGHT_ALIGNMENT);
            direita.add(lblUn);
            JButton btnRem = UIHelper.botaoModerno("Remover", UIHelper.VERMELHO);
            btnRem.setPreferredSize(new Dimension(85, 24));
            btnRem.setFont(new Font("SansSerif", Font.BOLD, 10));
            btnRem.addActionListener(e -> { carrinho.remove(idx); atualizarBadgeCarrinho(); refreshCarrinho(); });
            btnRem.setAlignmentX(Component.RIGHT_ALIGNMENT);
            direita.add(Box.createVerticalStrut(2));
            direita.add(btnRem);
            card.add(direita, BorderLayout.EAST);

            cartCardsPanel.add(card);
        }

        lblTotalCarrinho.setText("Total: R$ " + total);
        cartCardsPanel.revalidate();
        cartCardsPanel.repaint();
    }

    private void abrirCheckout() {
        if (carrinho.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Carrinho vazio!");
            return;
        }
        new CheckoutDialog(this, cliente, carrinho).setVisible(true);
        atualizarBadgeCarrinho();
        refreshCarrinho();
    }

    // ============================================================== PEDIDOS
    private JPanel pedCardsPanel;
    private List<Pedido> pedidosAtuais = new ArrayList<>();

    private JPanel criarPainelPedidos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        JLabel lbl = new JLabel("Meus Pedidos");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 22));
        lbl.setForeground(UIHelper.VERDE_ESCURO);
        topo.add(lbl, BorderLayout.WEST);
        JButton btnRefresh = UIHelper.botaoModerno("Atualizar", UIHelper.AZUL);
        btnRefresh.addActionListener(e -> refreshPedidos());
        topo.add(btnRefresh, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        pedCardsPanel = new JPanel();
        pedCardsPanel.setLayout(new BoxLayout(pedCardsPanel, BoxLayout.Y_AXIS));
        pedCardsPanel.setOpaque(false);
        JScrollPane scroll = new JScrollPane(pedCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        p.add(scroll, BorderLayout.CENTER);

        return p;
    }

    private Color corFundoStatus(String status) {
        if (status == null) return Color.WHITE;
        switch (status) {
            case "ENTREGUE":   return new Color(220, 245, 220);
            case "CONFIRMADO": return new Color(220, 235, 255);
            case "PENDENTE":   return new Color(255, 243, 220);
            case "CANCELADO":  return new Color(255, 220, 220);
            default: return Color.WHITE;
        }
    }
    private Color corTextoStatus(String status) {
        if (status == null) return Color.BLACK;
        switch (status) {
            case "ENTREGUE":   return new Color(30, 120, 30);
            case "CONFIRMADO": return new Color(30, 80, 170);
            case "PENDENTE":   return new Color(180, 100, 0);
            case "CANCELADO":  return new Color(170, 30, 30);
            default: return Color.BLACK;
        }
    }

    private void refreshPedidos() {
        pedidosAtuais = new PedidoDAO().listarPorCliente(cliente.getId());
        pedCardsPanel.removeAll();

        if (pedidosAtuais.isEmpty()) {
            JLabel vazio = new JLabel("Voce ainda nao fez nenhum pedido.");
            vazio.setFont(new Font("SansSerif", Font.ITALIC, 14));
            vazio.setForeground(Color.GRAY);
            vazio.setAlignmentX(Component.CENTER_ALIGNMENT);
            pedCardsPanel.add(Box.createVerticalStrut(40));
            pedCardsPanel.add(vazio);
        }

        for (Pedido ped : pedidosAtuais) {
            JPanel card = new JPanel(new BorderLayout(12, 0));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 225, 225)),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)));
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
            card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            card.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent e) { verDetalhesPedido(ped); }
                public void mouseEntered(java.awt.event.MouseEvent e) { card.setBackground(new Color(248, 250, 252)); }
                public void mouseExited(java.awt.event.MouseEvent e) { card.setBackground(Color.WHITE); }
            });

            // Esquerda: info do pedido
            JPanel info = new JPanel();
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.setOpaque(false);

            JPanel linha1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
            linha1.setOpaque(false);
            JLabel lblId = new JLabel("Pedido #" + ped.getId());
            lblId.setFont(new Font("SansSerif", Font.BOLD, 14));
            lblId.setForeground(UIHelper.VERDE_ESCURO);
            linha1.add(lblId);

            // Badge status
            JLabel badge = new JLabel(" " + ped.getStatus() + " ");
            badge.setFont(new Font("SansSerif", Font.BOLD, 10));
            badge.setForeground(corTextoStatus(ped.getStatus()));
            badge.setOpaque(true);
            badge.setBackground(corFundoStatus(ped.getStatus()));
            badge.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(corTextoStatus(ped.getStatus()), 1),
                    BorderFactory.createEmptyBorder(2, 6, 2, 6)));
            linha1.add(badge);
            info.add(linha1);

            JLabel lblRest = new JLabel(ped.getRestauranteNome());
            lblRest.setFont(new Font("SansSerif", Font.PLAIN, 13));
            lblRest.setForeground(Color.GRAY);
            info.add(lblRest);

            JPanel linha3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
            linha3.setOpaque(false);
            JLabel lblData = new JLabel(ped.getDataPedido() != null ? ped.getDataPedido().format(FMT) : "");
            lblData.setFont(UIHelper.CORPO_PEQUENO);
            lblData.setForeground(new Color(150, 150, 150));
            linha3.add(lblData);
            JLabel lblPag = new JLabel(traduzirPagamento(ped.getFormaPagamento()));
            lblPag.setFont(UIHelper.CORPO_PEQUENO);
            lblPag.setForeground(new Color(150, 150, 150));
            linha3.add(lblPag);
            info.add(linha3);
            card.add(info, BorderLayout.CENTER);

            // Direita: valor
            JPanel direita = new JPanel();
            direita.setLayout(new BoxLayout(direita, BoxLayout.Y_AXIS));
            direita.setOpaque(false);
            JLabel lblTotal = new JLabel("R$ " + ped.getValorTotal());
            lblTotal.setFont(new Font("SansSerif", Font.BOLD, 18));
            lblTotal.setForeground(UIHelper.VERDE);
            lblTotal.setAlignmentX(Component.RIGHT_ALIGNMENT);
            direita.add(Box.createVerticalStrut(8));
            direita.add(lblTotal);
            JLabel lblVer = new JLabel("Ver detalhes >");
            lblVer.setFont(new Font("SansSerif", Font.PLAIN, 11));
            lblVer.setForeground(UIHelper.AZUL);
            lblVer.setAlignmentX(Component.RIGHT_ALIGNMENT);
            direita.add(Box.createVerticalStrut(4));
            direita.add(lblVer);
            card.add(direita, BorderLayout.EAST);

            pedCardsPanel.add(card);
        }

        pedCardsPanel.revalidate();
        pedCardsPanel.repaint();
    }

    private void verDetalhesPedido(Pedido ped) {
        List<PedidoItem> itens = new PedidoDAO().listarItens(ped.getId());
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido #").append(ped.getId()).append("\n");
        sb.append("Restaurante: ").append(ped.getRestauranteNome()).append("\n");
        sb.append("Status: ").append(ped.getStatus()).append("\n");
        sb.append("Entrega: ").append(traduzirEntrega(ped.getTipoEntrega())).append("\n");
        if (ped.getEnderecoEntrega() != null) sb.append("Endereco: ").append(ped.getEnderecoEntrega()).append("\n");
        sb.append("Pagamento: ").append(traduzirPagamento(ped.getFormaPagamento())).append("\n");
        if (ped.getTroco() != null && ped.getTroco().compareTo(BigDecimal.ZERO) > 0) {
            sb.append("Troco: R$ ").append(ped.getTroco()).append(" (pagando com R$ ").append(ped.getValorDinheiro()).append(")\n");
        }
        sb.append("\nItens:\n");
        for (PedidoItem it : itens) {
            sb.append("  - ").append(it.getDescricao()).append(" x").append(it.getQuantidade())
                    .append(" = R$ ").append(it.getPrecoUnitario().multiply(BigDecimal.valueOf(it.getQuantidade()))).append("\n");
        }
        sb.append("\nTotal: R$ ").append(ped.getValorTotal());
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(new Font("SansSerif", Font.PLAIN, 13));
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(this, sp, "Detalhes do pedido", JOptionPane.PLAIN_MESSAGE);
    }

    // ============================================================== PERFIL
    private JPanel criarPainelPerfil() {
        JPanel wrapper = new JPanel(new BorderLayout(20, 0));
        wrapper.setBackground(UIHelper.FUNDO);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        // ====== Coluna esquerda: foto ======
        JPanel esquerda = new JPanel();
        esquerda.setLayout(new BoxLayout(esquerda, BoxLayout.Y_AXIS));
        esquerda.setOpaque(false);
        esquerda.setPreferredSize(new Dimension(280, 0));

        JPanel fotoCard = UIHelper.cardPanel();
        fotoCard.setLayout(new BoxLayout(fotoCard, BoxLayout.Y_AXIS));
        fotoCard.setMaximumSize(new Dimension(280, 280));

        JLabel lblFotoTitulo = new JLabel("Foto de perfil");
        lblFotoTitulo.setFont(UIHelper.SUBTITULO);
        lblFotoTitulo.setForeground(UIHelper.VERDE_ESCURO);
        lblFotoTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        fotoCard.add(lblFotoTitulo);
        fotoCard.add(Box.createVerticalStrut(10));

        JLabel lblFoto = UIHelper.labelImagem(cliente.getImagemUrl(), 160, 160);
        lblFoto.setAlignmentX(Component.CENTER_ALIGNMENT);
        fotoCard.add(lblFoto);
        fotoCard.add(Box.createVerticalStrut(10));

        JPanel fotoBtns = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        fotoBtns.setOpaque(false);
        JButton btnFoto = UIHelper.botaoModerno("Alterar foto", UIHelper.AZUL);
        btnFoto.setPreferredSize(new Dimension(120, 30));
        btnFoto.addActionListener(e -> {
            java.io.File arquivo = UIHelper.escolherImagem(this);
            if (arquivo != null) {
                String caminho = UIHelper.salvarImagem(arquivo, "perfis");
                if (caminho != null) {
                    cliente.setImagemUrl(caminho);
                    new ClienteDAO().atualizar(cliente);
                    ImageIcon ic = UIHelper.carregarImagem(caminho, 160, 160);
                    if (ic != null) { lblFoto.setIcon(ic); lblFoto.setText(""); lblFoto.setOpaque(false); }
                }
            }
        });
        JButton btnRemFoto = UIHelper.botaoModerno("Remover", UIHelper.VERMELHO);
        btnRemFoto.setPreferredSize(new Dimension(100, 30));
        btnRemFoto.addActionListener(e -> {
            cliente.setImagemUrl(null);
            new ClienteDAO().atualizar(cliente);
            lblFoto.setIcon(null);
            lblFoto.setOpaque(true);
            lblFoto.setBackground(UIHelper.VERDE_CLARO);
            lblFoto.setText("\uD83C\uDF7D");
        });
        fotoBtns.add(btnFoto);
        fotoBtns.add(btnRemFoto);
        fotoCard.add(fotoBtns);

        esquerda.add(fotoCard);
        wrapper.add(esquerda, BorderLayout.WEST);

        // ====== Coluna direita: dados + senha ======
        JPanel p = UIHelper.cardPanel();
        p.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        JLabel lbl = new JLabel("Meus dados");
        lbl.setFont(UIHelper.TITULO);
        lbl.setForeground(UIHelper.VERDE_ESCURO);
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        p.add(lbl, gbc);
        gbc.gridwidth = 1;

        JTextField txtNome = new JTextField(cliente.getNome(), 22);
        JTextField txtTel = new JTextField(cliente.getTelefone(), 15);
        JTextField txtEnd = new JTextField(cliente.getEndereco(), 22);
        JTextField txtNum = new JTextField(cliente.getNumero(), 8);
        JTextField txtBairro = new JTextField(cliente.getBairro(), 15);
        JTextField txtCidade = new JTextField(cliente.getCidade(), 15);
        JTextField txtEstado = new JTextField(cliente.getEstado(), 5);
        JTextField txtCep = new JTextField(cliente.getCep(), 10);

        addField(p, gbc, row++, "Nome:", txtNome);
        addField(p, gbc, row++, "Telefone:", txtTel);
        addField(p, gbc, row++, "CEP:", txtCep);
        addField(p, gbc, row++, "Endereco:", txtEnd);
        addField(p, gbc, row++, "Numero:", txtNum);
        addField(p, gbc, row++, "Bairro:", txtBairro);
        addField(p, gbc, row++, "Cidade:", txtCidade);
        addField(p, gbc, row++, "Estado:", txtEstado);

        JButton btnSalvar = UIHelper.botaoModerno("Salvar dados", UIHelper.VERDE);
        btnSalvar.addActionListener(e -> {
            cliente.setNome(txtNome.getText().trim());
            cliente.setTelefone(txtTel.getText().trim());
            cliente.setEndereco(txtEnd.getText().trim());
            cliente.setNumero(txtNum.getText().trim());
            cliente.setBairro(txtBairro.getText().trim());
            cliente.setCidade(txtCidade.getText().trim());
            cliente.setEstado(txtEstado.getText().trim());
            cliente.setCep(txtCep.getText().trim());
            if (new ClienteDAO().atualizar(cliente)) {
                setTitle("SaveByte - Ola, " + cliente.getNome());
                JOptionPane.showMessageDialog(this, "Dados atualizados!");
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        p.add(btnSalvar, gbc);

        gbc.gridy = row++;
        p.add(Box.createVerticalStrut(8), gbc);
        p.add(new JSeparator(), gbc);
        JLabel lblSenha = new JLabel("Alterar senha");
        lblSenha.setFont(UIHelper.SUBTITULO);
        lblSenha.setForeground(UIHelper.VERDE_ESCURO);
        gbc.gridy = row++;
        p.add(lblSenha, gbc);
        gbc.gridwidth = 1;

        JPasswordField txtSenhaAtual = new JPasswordField(15);
        JPasswordField txtNovaSenha = new JPasswordField(15);
        addField(p, gbc, row++, "Senha atual:", txtSenhaAtual);
        addField(p, gbc, row++, "Nova senha:", txtNovaSenha);

        JButton btnSenha = UIHelper.botaoModerno("Alterar senha", UIHelper.AZUL);
        btnSenha.addActionListener(e -> {
            String atual = new String(txtSenhaAtual.getPassword());
            String nova = new String(txtNovaSenha.getPassword());
            if (nova.length() < 6) { JOptionPane.showMessageDialog(this, "Nova senha deve ter pelo menos 6 caracteres."); return; }
            if (new ClienteDAO().alterarSenha(cliente.getId(), atual, nova)) {
                JOptionPane.showMessageDialog(this, "Senha alterada!");
                txtSenhaAtual.setText(""); txtNovaSenha.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Senha atual incorreta.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        p.add(btnSenha, gbc);

        JScrollPane scroll = new JScrollPane(p);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        wrapper.add(scroll, BorderLayout.CENTER);

        return wrapper;
    }

    // ============================================================== UTILS
    private JPanel criarTopo(String titulo, String placeholder) {
        JPanel topo = new JPanel(new BorderLayout(0, 6));
        topo.setBackground(Color.WHITE);

        JLabel lbl = new JLabel(titulo);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 22));
        lbl.setForeground(UIHelper.VERDE);
        topo.add(lbl, BorderLayout.NORTH);
        topo.add(Box.createVerticalStrut(4), BorderLayout.CENTER);

        JPanel barra = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        barra.setBackground(Color.WHITE);
        barra.add(new JLabel("Buscar:"));
        JTextField txtBusca = new JTextField(20);
        txtBusca.setToolTipText(placeholder);
        barra.add(txtBusca);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBackground(UIHelper.VERDE); btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFocusPainted(false);
        barra.add(btnBuscar);
        topo.add(barra, BorderLayout.SOUTH);

        return topo;
    }

    private void addField(JPanel p, GridBagConstraints gbc, int row, String label, JComponent campo) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        p.add(new JLabel(label), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        p.add(campo, gbc);
    }

    static String traduzirPagamento(String fp) {
        if (fp == null) return "";
        switch (fp) {
            case "NA_ENTREGA": return "Na retirada/entrega";
            case "PIX": return "Pix";
            case "CARTAO": return "Cartao";
            default: return fp;
        }
    }

    static String traduzirEntrega(String te) {
        if (te == null) return "";
        switch (te) {
            case "RETIRADA": return "Retirada";
            case "ENTREGA": return "Entrega";
            default: return te;
        }
    }

    static class ItemCarrinho {
        String tipo;
        long itemId;
        String nome;
        BigDecimal preco;
        int quantidade;
        long restauranteId;
        String restauranteNome;
    }
}
