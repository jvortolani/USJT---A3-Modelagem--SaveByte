package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.ProjetoDAO;
import br.com.usjt.savebyte.model.Projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class ProjetoPanel extends JPanel {

    private static final Color VERDE = new Color(26, 107, 42);
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static final String[] LISTA_ODS = {
            "ODS 1 - Erradicação da pobreza",
            "ODS 2 - Fome zero e agricultura sustentável",
            "ODS 3 - Saúde e bem-estar",
            "ODS 4 - Educação de qualidade",
            "ODS 5 - Igualdade de gênero",
            "ODS 6 - Água potável e saneamento",
            "ODS 7 - Energia limpa e acessível",
            "ODS 8 - Trabalho decente e crescimento econômico",
            "ODS 9 - Indústria, inovação e infraestrutura",
            "ODS 10 - Redução das desigualdades",
            "ODS 11 - Cidades e comunidades sustentáveis",
            "ODS 12 - Consumo e produção responsáveis",
            "ODS 13 - Ação contra a mudança global do clima",
            "ODS 14 - Vida na água",
            "ODS 15 - Vida terrestre",
            "ODS 16 - Paz, justiça e instituições eficazes",
            "ODS 17 - Parcerias e meios de implementação"
    };

    private static final String[] LISTA_STATUS = {
            "Em andamento", "Concluído", "Pausado", "Cancelado"
    };

    private final ProjetoDAO dao = new ProjetoDAO();
    private final DefaultTableModel tableModel;
    private final JTable tabela;
    private final JTextField txtBusca = new JTextField(20);
    private List<Projeto> listaAtual;

    public ProjetoPanel() {
        setLayout(new BorderLayout(0, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Título
        JLabel lblTitulo = new JLabel("Gerenciamento de Projetos");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitulo.setForeground(VERDE);

        // Barra de ações
        JPanel barraAcoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        barraAcoes.setBackground(Color.WHITE);

        JButton btnNovo = botao("Novo", VERDE);
        btnNovo.addActionListener(e -> abrirFormulario(null));
        JButton btnEditar = botao("Editar", new Color(30, 136, 229));
        btnEditar.addActionListener(e -> editarSelecionado());
        JButton btnExcluir = botao("Excluir", new Color(211, 47, 47));
        btnExcluir.addActionListener(e -> excluirSelecionado());

        barraAcoes.add(btnNovo);
        barraAcoes.add(btnEditar);
        barraAcoes.add(btnExcluir);
        barraAcoes.add(Box.createHorizontalStrut(20));
        barraAcoes.add(new JLabel("Buscar:"));
        barraAcoes.add(txtBusca);
        JButton btnBuscar = botao("Buscar", Color.DARK_GRAY);
        btnBuscar.addActionListener(e -> carregar());
        barraAcoes.add(btnBuscar);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(Color.WHITE);
        topo.add(lblTitulo, BorderLayout.NORTH);
        topo.add(Box.createVerticalStrut(10), BorderLayout.CENTER);
        topo.add(barraAcoes, BorderLayout.SOUTH);
        add(topo, BorderLayout.NORTH);

        // Tabela
        String[] colunas = {"ID", "Código", "Descrição", "ODS", "Responsável", "Telefone", "Data Criação", "Status"};
        tableModel = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(tableModel);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setRowHeight(26);
        tabela.getColumnModel().getColumn(0).setMaxWidth(50);
        tabela.getColumnModel().getColumn(1).setPreferredWidth(80);
        tabela.getColumnModel().getColumn(2).setPreferredWidth(200);
        tabela.getColumnModel().getColumn(3).setPreferredWidth(200);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        carregar();
    }

    private void carregar() {
        String termo = txtBusca.getText().trim();
        listaAtual = termo.isEmpty() ? dao.listar() : dao.buscar(termo);
        tableModel.setRowCount(0);
        for (Projeto p : listaAtual) {
            tableModel.addRow(new Object[]{
                    p.getId(), p.getCodigo(), p.getDescricao(), p.getOds(),
                    p.getNomeResponsavel(), p.getTelefone(),
                    p.getDataCriacao() != null ? p.getDataCriacao().format(FMT) : "",
                    p.getStatus()
            });
        }
    }

    private void editarSelecionado() {
        int row = tabela.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um projeto na tabela.");
            return;
        }
        abrirFormulario(listaAtual.get(row));
    }

    private void excluirSelecionado() {
        int row = tabela.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um projeto na tabela.");
            return;
        }
        Projeto p = listaAtual.get(row);
        int resp = JOptionPane.showConfirmDialog(this,
                "Excluir o projeto \"" + p.getCodigo() + " - " + p.getDescricao() + "\"?",
                "Confirmação", JOptionPane.YES_NO_OPTION);
        if (resp == JOptionPane.YES_OPTION) {
            if (dao.excluir(p.getId())) {
                JOptionPane.showMessageDialog(this, "Projeto excluído.");
                carregar();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void abrirFormulario(Projeto existente) {
        JTextField txtCodigo = new JTextField(existente != null ? existente.getCodigo() : "");
        JTextArea txtDescricao = new JTextArea(existente != null ? existente.getDescricao() : "", 3, 20);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);

        JComboBox<String> cmbOds = new JComboBox<>(LISTA_ODS);
        if (existente != null) cmbOds.setSelectedItem(existente.getOds());
        else cmbOds.setSelectedItem(LISTA_ODS[1]); // ODS 2 - Fome zero (tema SaveByte)

        JTextField txtResponsavel = new JTextField(existente != null ? existente.getNomeResponsavel() : "");
        JTextField txtTelefone = new JTextField(existente != null ? existente.getTelefone() : "");
        JTextField txtData = new JTextField(existente != null && existente.getDataCriacao() != null
                ? existente.getDataCriacao().format(FMT) : LocalDate.now().format(FMT));

        JComboBox<String> cmbStatus = new JComboBox<>(LISTA_STATUS);
        if (existente != null) cmbStatus.setSelectedItem(existente.getStatus());

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        addField(form, gbc, row++, "Código:", txtCodigo);
        // Descrição com scroll
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        form.add(new JLabel("Descrição:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        form.add(new JScrollPane(txtDescricao), gbc);
        row++;
        addField(form, gbc, row++, "ODS:", cmbOds);
        addField(form, gbc, row++, "Responsável:", txtResponsavel);
        addField(form, gbc, row++, "Telefone:", txtTelefone);
        addField(form, gbc, row++, "Data criação (dd/MM/yyyy):", txtData);
        addField(form, gbc, row++, "Status:", cmbStatus);

        String titulo = existente != null ? "Editar Projeto" : "Novo Projeto";
        int resp = JOptionPane.showConfirmDialog(this, form, titulo,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resp != JOptionPane.OK_OPTION) return;

        String codigo = txtCodigo.getText().trim();
        String descricao = txtDescricao.getText().trim();
        String responsavel = txtResponsavel.getText().trim();

        if (codigo.isEmpty() || descricao.isEmpty() || responsavel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha código, descrição e responsável.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate data;
        try {
            data = LocalDate.parse(txtData.getText().trim(), FMT);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use o formato dd/MM/yyyy.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Projeto p = existente != null ? existente : new Projeto();
        p.setCodigo(codigo);
        p.setDescricao(descricao);
        p.setOds((String) cmbOds.getSelectedItem());
        p.setNomeResponsavel(responsavel);
        p.setTelefone(txtTelefone.getText().trim());
        p.setDataCriacao(data);
        p.setStatus((String) cmbStatus.getSelectedItem());

        boolean ok = existente != null ? dao.atualizar(p) : dao.inserir(p);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Projeto salvo com sucesso!");
            carregar();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar. Verifique se o código já existe.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addField(JPanel form, GridBagConstraints gbc, int row, String label, JComponent campo) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        form.add(new JLabel(label), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        form.add(campo, gbc);
    }

    private JButton botao(String texto, Color cor) {
        JButton btn = new JButton(texto);
        btn.setBackground(cor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
