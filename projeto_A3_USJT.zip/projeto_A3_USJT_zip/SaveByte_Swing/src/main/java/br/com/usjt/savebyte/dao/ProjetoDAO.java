package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Projeto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjetoDAO {

    public List<Projeto> listar() {
        List<Projeto> lista = new ArrayList<>();
        String sql = "SELECT * FROM projetos ORDER BY data_criacao DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Projeto> buscar(String termo) {
        List<Projeto> lista = new ArrayList<>();
        String sql = "SELECT * FROM projetos WHERE codigo LIKE ? OR descricao LIKE ? OR nome_responsavel LIKE ? OR ods LIKE ? ORDER BY data_criacao DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + termo + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            ps.setString(4, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean inserir(Projeto p) {
        String sql = "INSERT INTO projetos (codigo, descricao, ods, nome_responsavel, telefone, data_criacao, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo());
            ps.setString(2, p.getDescricao());
            ps.setString(3, p.getOds());
            ps.setString(4, p.getNomeResponsavel());
            ps.setString(5, p.getTelefone());
            ps.setDate(6, Date.valueOf(p.getDataCriacao()));
            ps.setString(7, p.getStatus());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizar(Projeto p) {
        String sql = "UPDATE projetos SET codigo = ?, descricao = ?, ods = ?, nome_responsavel = ?, telefone = ?, data_criacao = ?, status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo());
            ps.setString(2, p.getDescricao());
            ps.setString(3, p.getOds());
            ps.setString(4, p.getNomeResponsavel());
            ps.setString(5, p.getTelefone());
            ps.setDate(6, Date.valueOf(p.getDataCriacao()));
            ps.setString(7, p.getStatus());
            ps.setInt(8, p.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluir(int id) {
        String sql = "DELETE FROM projetos WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Projeto mapear(ResultSet rs) throws SQLException {
        Projeto p = new Projeto();
        p.setId(rs.getInt("id"));
        p.setCodigo(rs.getString("codigo"));
        p.setDescricao(rs.getString("descricao"));
        p.setOds(rs.getString("ods"));
        p.setNomeResponsavel(rs.getString("nome_responsavel"));
        p.setTelefone(rs.getString("telefone"));
        Date d = rs.getDate("data_criacao");
        if (d != null) p.setDataCriacao(d.toLocalDate());
        p.setStatus(rs.getString("status"));
        return p;
    }
}
