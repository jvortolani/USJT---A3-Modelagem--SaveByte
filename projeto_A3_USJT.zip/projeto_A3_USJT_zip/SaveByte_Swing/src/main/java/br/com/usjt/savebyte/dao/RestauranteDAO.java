package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Restaurante;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RestauranteDAO {

    public Restaurante autenticar(String email, String senha) {
        String sql = "SELECT * FROM restaurante WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                if (BCrypt.checkpw(senha, rs.getString("senha"))) return mapear(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean inserir(Restaurante r, String senhaPlana) {
        String sql = "INSERT INTO restaurante (nome, cnpj, email, senha, senha_visivel, telefone, endereco, numero, complemento, bairro, cidade, estado, cep, descricao, criado_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, r.getNome());
            ps.setString(2, r.getCnpj());
            ps.setString(3, r.getEmail());
            ps.setString(4, BCrypt.hashpw(senhaPlana, BCrypt.gensalt()));
            ps.setString(5, senhaPlana);
            ps.setString(6, r.getTelefone());
            ps.setString(7, r.getEndereco());
            ps.setString(8, r.getNumero());
            ps.setString(9, r.getComplemento());
            ps.setString(10, r.getBairro());
            ps.setString(11, r.getCidade());
            ps.setString(12, r.getEstado());
            ps.setString(13, r.getCep());
            ps.setString(14, r.getDescricao());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) r.setId(keys.getLong(1));
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean atualizar(Restaurante r) {
        String sql;
        boolean atualizaSenha = r.getSenhaVisivel() != null && !r.getSenhaVisivel().isBlank();
        if (atualizaSenha) {
            sql = "UPDATE restaurante SET nome=?, cnpj=?, telefone=?, endereco=?, numero=?, complemento=?, bairro=?, cidade=?, estado=?, cep=?, descricao=?, imagem_url=?, senha=?, senha_visivel=? WHERE id=?";
        } else {
            sql = "UPDATE restaurante SET nome=?, cnpj=?, telefone=?, endereco=?, numero=?, complemento=?, bairro=?, cidade=?, estado=?, cep=?, descricao=?, imagem_url=? WHERE id=?";
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getNome());
            ps.setString(2, r.getCnpj());
            ps.setString(3, r.getTelefone());
            ps.setString(4, r.getEndereco());
            ps.setString(5, r.getNumero());
            ps.setString(6, r.getComplemento());
            ps.setString(7, r.getBairro());
            ps.setString(8, r.getCidade());
            ps.setString(9, r.getEstado());
            ps.setString(10, r.getCep());
            ps.setString(11, r.getDescricao());
            ps.setString(12, r.getImagemUrl());
            if (atualizaSenha) {
                ps.setString(13, BCrypt.hashpw(r.getSenhaVisivel(), BCrypt.gensalt()));
                ps.setString(14, r.getSenhaVisivel());
                ps.setLong(15, r.getId());
            } else {
                ps.setLong(13, r.getId());
            }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<Restaurante> listar() {
        List<Restaurante> lista = new ArrayList<>();
        String sql = "SELECT * FROM restaurante ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public List<Restaurante> buscar(String termo) {
        List<Restaurante> lista = new ArrayList<>();
        String sql = "SELECT * FROM restaurante WHERE nome LIKE ? OR email LIKE ? OR cidade LIKE ? ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + termo + "%";
            ps.setString(1, like); ps.setString(2, like); ps.setString(3, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public boolean excluir(long id) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.prepareStatement("DELETE FROM pedido_item WHERE pedido_id IN (SELECT id FROM pedido WHERE restaurante_id = " + id + ")").executeUpdate();
            conn.prepareStatement("DELETE FROM pedido WHERE restaurante_id = " + id).executeUpdate();
            conn.prepareStatement("DELETE FROM combo WHERE restaurante_id = " + id).executeUpdate();
            conn.prepareStatement("DELETE FROM produto WHERE restaurante_id = " + id).executeUpdate();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM restaurante WHERE id = ?");
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public Restaurante buscarPorId(long id) {
        String sql = "SELECT * FROM restaurante WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    private Restaurante mapear(ResultSet rs) throws SQLException {
        Restaurante r = new Restaurante();
        r.setId(rs.getLong("id"));
        r.setNome(rs.getString("nome"));
        r.setCnpj(rs.getString("cnpj"));
        r.setEmail(rs.getString("email"));
        r.setSenha(rs.getString("senha"));
        try { r.setSenhaVisivel(rs.getString("senha_visivel")); } catch (SQLException ignored) {}
        r.setTelefone(rs.getString("telefone"));
        r.setEndereco(rs.getString("endereco"));
        r.setNumero(rs.getString("numero"));
        r.setComplemento(rs.getString("complemento"));
        r.setBairro(rs.getString("bairro"));
        r.setCidade(rs.getString("cidade"));
        r.setEstado(rs.getString("estado"));
        r.setCep(rs.getString("cep"));
        r.setDescricao(rs.getString("descricao"));
        r.setImagemUrl(rs.getString("imagem_url"));
        return r;
    }
}
