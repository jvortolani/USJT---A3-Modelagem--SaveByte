package br.com.usjt.savebyte.view;

import br.com.usjt.savebyte.dao.*;
import br.com.usjt.savebyte.model.*;

import javax.swing.*;

import java.awt.*;
import java.io.File;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;

public class RestauranteFrame extends JFrame {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private Restaurante restaurante;
    private final JPanel conteudo = new JPanel(new CardLayout());

    private JPanel prodCardsPanel, comboCardsPanel;
    private List<Produto> produtosAtuais = new ArrayList<>();
    private List<Combo> combosAtuais = new ArrayList<>();
    private List<Pedido> pedidosAtuais = new ArrayList<>();

    // Permissoes do usuario logado (null = dono do restaurante = acesso total)
    private final GrupoAcesso permissoes;
    private final Usuario usuarioLogado;

    /** Construtor para o dono do restaurante (acesso total) */
    public RestauranteFrame(Restaurante restaurante) {
        this(restaurante, null, null);
    }

    /** Construtor para usuario do restaurante (acesso baseado no grupo) */
    public RestauranteFrame(Restaurante restaurante, Usuario usuario, GrupoAcesso grupo) {
        this.restaurante = restaurante;
        this.usuarioLogado = usuario;
        this.permissoes = grupo;
        String titulo = "SaveByte - " + restaurante.getNome();
        if (usuario != null) titulo += " [" + usuario.getNome() + (grupo != null ? " - " + grupo.getNome() : "") + "]";
        setTitle(titulo);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        java.net.URL iconUrl = getClass().getResource("/img/logo.png");
        if (iconUrl != null) setIconImage(new ImageIcon(iconUrl).getImage());

        JPanel principal = new JPanel(new BorderLayout());
        principal.add(criarSidebar(), BorderLayout.WEST);

        conteudo.add(criarPainelDashboard(), "DASHBOARD");
        if (temPermissao("produtos")) conteudo.add(criarPainelProdutos(), "PRODUTOS");
        if (temPermissao("produtos")) conteudo.add(criarPainelCombos(), "COMBOS");
        if (temPermissao("pedidos")) conteudo.add(criarPainelPedidos(), "PEDIDOS");
        if (isDono()) conteudo.add(criarPainelPerfil(), "PERFIL");
        if (temPermissao("usuarios")) {
            Integer loggedId = usuarioLogado != null ? usuarioLogado.getId() : null;
            conteudo.add(new UsuarioPanel(restaurante.getId(), loggedId), "USUARIOS");
        }
        if (isDono()) conteudo.add(criarPainelGrupos(), "GRUPOS");
        principal.add(conteudo, BorderLayout.CENTER);

        add(principal);
    }

    /** Dono do restaurante = sem usuario logado (login direto via e-mail do restaurante) */
    private boolean isDono() {
        return usuarioLogado == null;
    }

    /** Verifica se o usuario logado tem permissao para a funcionalidade */
    private boolean temPermissao(String funcionalidade) {
        // Dono do restaurante tem acesso total
        if (isDono()) return true;
        // Sem grupo = sem permissao (exceto dashboard)
        if (permissoes == null) return false;
        switch (funcionalidade) {
            case "vendas": return permissoes.isPodeVerVendas();
            case "faturamento": return permissoes.isPodeVerFaturamento();
            case "produtos": return permissoes.isPodeGerenciarProdutos();
            case "pedidos": return permissoes.isPodeGerenciarPedidos();
            case "usuarios": return permissoes.isPodeGerenciarUsuarios();
            case "precos": return permissoes.isPodeAlterarPrecos();
            default: return false;
        }
    }

    private void mostrar(String card) {
        if ("PRODUTOS".equals(card)) refreshProdutos();
        if ("COMBOS".equals(card)) refreshCombos();
        if ("PEDIDOS".equals(card)) refreshPedidos();
        ((CardLayout) conteudo.getLayout()).show(conteudo, card);
    }

    // ============================================================== SIDEBAR
    private JPanel criarSidebar() {
        JPanel sidebar = UIHelper.criarSidebarBase();

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(img));
            lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(lblLogo);
            sidebar.add(Box.createVerticalStrut(15));
        }

        sidebar.add(criarBtnSidebar("Dashboard", "DASHBOARD"));
        sidebar.add(Box.createVerticalStrut(4));
        if (temPermissao("produtos")) {
            sidebar.add(criarBtnSidebar("Produtos", "PRODUTOS"));
            sidebar.add(Box.createVerticalStrut(4));
            sidebar.add(criarBtnSidebar("Combos", "COMBOS"));
            sidebar.add(Box.createVerticalStrut(4));
        }
        if (temPermissao("pedidos")) {
            sidebar.add(criarBtnSidebar("Pedidos", "PEDIDOS"));
            sidebar.add(Box.createVerticalStrut(4));
        }
        if (isDono()) {
            sidebar.add(criarBtnSidebar("Perfil", "PERFIL"));
            sidebar.add(Box.createVerticalStrut(4));
        }

        // Secao admin - so para quem tem permissao
        if (isDono() || temPermissao("usuarios")) {
            sidebar.add(Box.createVerticalStrut(8));
            JSeparator sep = new JSeparator();
            sep.setMaximumSize(new Dimension(196, 1));
            sep.setForeground(new Color(255, 255, 255, 40));
            sidebar.add(sep);
            sidebar.add(Box.createVerticalStrut(8));

            JLabel lblAdmin = new JLabel("Administracao");
            lblAdmin.setFont(new Font("SansSerif", Font.PLAIN, 10));
            lblAdmin.setForeground(new Color(200, 230, 201));
            lblAdmin.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(lblAdmin);
            sidebar.add(Box.createVerticalStrut(4));

            if (temPermissao("usuarios")) {
                sidebar.add(criarBtnSidebar("Usuarios", "USUARIOS"));
                sidebar.add(Box.createVerticalStrut(4));
            }
            // Somente o dono pode ver/criar grupos de acesso
            if (isDono()) {
                sidebar.add(criarBtnSidebar("Grupos de Acesso", "GRUPOS"));
                sidebar.add(Box.createVerticalStrut(4));
            }
        }

        sidebar.add(Box.createVerticalGlue());

        JLabel lblUser = new JLabel("<html><center>" + restaurante.getNome() + "</center></html>");
        lblUser.setForeground(new Color(200, 230, 201));
        lblUser.setFont(UIHelper.CORPO_PEQUENO);
        lblUser.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(lblUser);
        sidebar.add(Box.createVerticalStrut(8));

        JButton btnSair = UIHelper.btnSidebar("Sair");
        btnSair.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });
        sidebar.add(btnSair);
        return sidebar;
    }

    private JButton criarBtnSidebar(String txt, String card) {
        JButton btn = UIHelper.btnSidebar(txt);
        btn.addActionListener(e -> mostrar(card));
        return btn;
    }

    // ============================================================== DASHBOARD
    private JPanel criarPainelDashboard() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UIHelper.FUNDO);

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setOpaque(false);
        centro.setBorder(BorderFactory.createEmptyBorder(40, 30, 20, 30));

        URL logoUrl = getClass().getResource("/img/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
            JLabel lbl = new JLabel(new ImageIcon(img));
            lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            centro.add(lbl);
            centro.add(Box.createVerticalStrut(8));
        }
        JLabel l1 = new JLabel("Painel do Restaurante");
        l1.setFont(new Font("SansSerif", Font.BOLD, 26));
        l1.setForeground(UIHelper.VERDE_ESCURO);
        l1.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(l1);
        JLabel l2 = new JLabel("Gerencie seus produtos, combos e pedidos.");
        l2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        l2.setForeground(UIHelper.TEXTO_SEC);
        l2.setAlignmentX(Component.CENTER_ALIGNMENT);
        centro.add(l2);
        centro.add(Box.createVerticalStrut(14));

        // Cards de estatisticas
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        stats.setOpaque(false);
        stats.add(criarStatCard("Produtos", String.valueOf(new ProdutoDAO().listarPorRestaurante(restaurante.getId()).size()), UIHelper.VERDE));
        stats.add(criarStatCard("Combos", String.valueOf(new ComboDAO().listarPorRestaurante(restaurante.getId()).size()), UIHelper.AZUL));
        stats.add(criarStatCard("Pedidos", String.valueOf(new PedidoDAO().listarPorRestaurante(restaurante.getId()).size()), UIHelper.LARANJA));
        centro.add(stats);
        centro.add(Box.createVerticalStrut(10));

        // Quem Somos
        centro.add(UIHelper.criarPainelQuemSomos());

        JScrollPane scroll = new JScrollPane(centro);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private JPanel criarStatCard(String titulo, String valor, Color cor) {
        JPanel card = UIHelper.cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(160, 100));

        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("SansSerif", Font.BOLD, 36));
        lblValor.setForeground(cor);
        lblValor.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(Box.createVerticalStrut(10));
        card.add(lblValor);

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(UIHelper.CORPO);
        lblTitulo.setForeground(UIHelper.TEXTO_SEC);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblTitulo);

        return card;
    }

    // ============================================================== PRODUTOS
    private JPanel criarPainelProdutos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Meus Produtos", "Gerencie os produtos do seu restaurante"), BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        JButton btnNovo = UIHelper.botaoModerno("Novo produto", UIHelper.VERDE);
        btnNovo.addActionListener(e -> formProduto(null));
        acoes.add(btnNovo);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        prodCardsPanel = new UIHelper.WrapPanel(new UIHelper.WrapLayout(FlowLayout.LEFT, 15, 15));
        prodCardsPanel.setBackground(UIHelper.FUNDO);
        JScrollPane scroll = new JScrollPane(prodCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UIHelper.FUNDO);
        p.add(scroll, BorderLayout.CENTER);

        refreshProdutos();
        return p;
    }

    private void refreshProdutos() {
        produtosAtuais = new ProdutoDAO().listarPorRestaurante(restaurante.getId());
        prodCardsPanel.removeAll();
        for (Produto pr : produtosAtuais) prodCardsPanel.add(criarCardProduto(pr));
        if (produtosAtuais.isEmpty()) {
            JLabel lbl = new JLabel("Nenhum produto cadastrado. Clique em 'Novo produto' para comecar!");
            lbl.setForeground(UIHelper.TEXTO_SEC);
            lbl.setFont(new Font("SansSerif", Font.ITALIC, 14));
            prodCardsPanel.add(lbl);
        }
        prodCardsPanel.revalidate();
        prodCardsPanel.repaint();
    }

    private JPanel criarCardProduto(Produto pr) {
        JPanel card = UIHelper.cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(220, 370));

        // Imagem
        JLabel lblImg = UIHelper.labelImagem(pr.getImagemUrl(), 196, 130);
        lblImg.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblImg);
        card.add(Box.createVerticalStrut(8));

        // Status badge
        JLabel lblStatus = new JLabel(pr.isAtivo() ? "Ativo" : "Inativo");
        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblStatus.setForeground(Color.WHITE);
        lblStatus.setOpaque(true);
        lblStatus.setBackground(pr.isAtivo() ? UIHelper.VERDE : UIHelper.TEXTO_SEC);
        lblStatus.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
        lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblStatus);
        card.add(Box.createVerticalStrut(6));

        // Nome
        JLabel lblNome = new JLabel("<html><center>" + pr.getNome() + "</center></html>");
        lblNome.setFont(UIHelper.SUBTITULO);
        lblNome.setForeground(UIHelper.TEXTO);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblNome);

        // Categoria
        if (pr.getCategoria() != null && !pr.getCategoria().isBlank()) {
            JLabel lblCat = new JLabel(pr.getCategoria());
            lblCat.setFont(UIHelper.CORPO_PEQUENO);
            lblCat.setForeground(UIHelper.TEXTO_SEC);
            lblCat.setAlignmentX(Component.CENTER_ALIGNMENT);
            card.add(lblCat);
        }
        card.add(Box.createVerticalStrut(4));

        // Preços
        JPanel precos = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        precos.setOpaque(false);
        precos.setMaximumSize(new Dimension(200, 24));
        JLabel lblOrig = new JLabel("<html><s>R$ " + pr.getPrecoOriginal() + "</s></html>");
        lblOrig.setFont(UIHelper.CORPO_PEQUENO);
        lblOrig.setForeground(UIHelper.TEXTO_SEC);
        precos.add(lblOrig);
        JLabel lblPreco = new JLabel("R$ " + pr.getPrecoDesconto());
        lblPreco.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblPreco.setForeground(UIHelper.VERDE);
        precos.add(lblPreco);
        card.add(precos);

        JLabel lblQtd = new JLabel("Estoque: " + pr.getQuantidade());
        lblQtd.setFont(UIHelper.CORPO_PEQUENO);
        lblQtd.setForeground(UIHelper.TEXTO_SEC);
        lblQtd.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblQtd);
        card.add(Box.createVerticalGlue());

        // Botões
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        btns.setOpaque(false);
        btns.setMaximumSize(new Dimension(200, 36));
        JButton btnEdit = UIHelper.botaoModerno("Editar", UIHelper.AZUL);
        btnEdit.setPreferredSize(new Dimension(90, 30));
        btnEdit.addActionListener(e -> formProduto(pr));
        JButton btnToggle = UIHelper.botaoModerno(pr.isAtivo() ? "Desativar" : "Ativar",
                pr.isAtivo() ? UIHelper.LARANJA : UIHelper.VERDE);
        btnToggle.setPreferredSize(new Dimension(90, 30));
        btnToggle.addActionListener(e -> { new ProdutoDAO().alternarAtivo(pr.getId()); refreshProdutos(); });
        btns.add(btnEdit);
        btns.add(btnToggle);
        card.add(btns);

        return card;
    }

    private void formProduto(Produto existente) {
        // Funcionario sem permissao de precos precisa senha de gerente para alterar precos
        boolean podeAlterarPrecos = temPermissao("precos");

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtNome = new JTextField(existente != null ? existente.getNome() : "", 22);
        JTextField txtCategoria = new JTextField(existente != null ? existente.getCategoria() : "", 15);
        JTextArea txtDesc = new JTextArea(existente != null ? existente.getDescricao() : "", 3, 22);
        txtDesc.setLineWrap(true);
        JTextField txtPrecoOrig = new JTextField(existente != null ? existente.getPrecoOriginal().toString() : "", 10);
        JTextField txtPrecoDesc = new JTextField(existente != null ? existente.getPrecoDesconto().toString() : "", 10);
        JTextField txtQtd = new JTextField(existente != null ? String.valueOf(existente.getQuantidade()) : "0", 5);

        // Bloquear campos de preco se usuario nao tem permissao
        if (!podeAlterarPrecos) {
            txtPrecoOrig.setEditable(false);
            txtPrecoOrig.setBackground(new Color(240, 240, 240));
            txtPrecoOrig.setToolTipText("Necessario senha de gerente para alterar precos");
            txtPrecoDesc.setEditable(false);
            txtPrecoDesc.setBackground(new Color(240, 240, 240));
            txtPrecoDesc.setToolTipText("Necessario senha de gerente para alterar precos");
        }

        // Preview de imagem
        final String[] imagemPath = {existente != null ? existente.getImagemUrl() : null};
        JLabel lblPreview = UIHelper.labelImagem(imagemPath[0], 200, 120);
        JButton btnFoto = UIHelper.botaoModerno("Escolher foto", UIHelper.AZUL);
        btnFoto.setPreferredSize(new Dimension(160, 30));
        btnFoto.addActionListener(e -> {
            File arquivo = UIHelper.escolherImagem(this);
            if (arquivo != null) {
                String caminho = UIHelper.salvarImagem(arquivo, "produtos");
                if (caminho != null) {
                    imagemPath[0] = caminho;
                    ImageIcon icon = UIHelper.carregarImagem(caminho, 200, 120);
                    if (icon != null) {
                        lblPreview.setIcon(icon);
                        lblPreview.setText("");
                        lblPreview.setOpaque(false);
                    }
                }
            }
        });

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        form.add(lblPreview, gbc);
        row++;
        gbc.gridy = row; gbc.gridwidth = 2;
        form.add(btnFoto, gbc);
        row++;
        gbc.gridwidth = 1;
        addFormField(form, gbc, row++, "Nome:", txtNome);
        addFormField(form, gbc, row++, "Categoria:", txtCategoria);
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        form.add(new JLabel("Descricao:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        form.add(new JScrollPane(txtDesc), gbc);
        row++;
        addFormField(form, gbc, row++, "Preco original (R$):", txtPrecoOrig);
        addFormField(form, gbc, row++, "Preco especial (R$):", txtPrecoDesc);

        // Botao para desbloquear precos com senha de gerente
        if (!podeAlterarPrecos) {
            JButton btnDesbloquear = new JButton("Desbloquear precos (senha gerente)");
            btnDesbloquear.setFont(new Font("SansSerif", Font.BOLD, 11));
            btnDesbloquear.setForeground(UIHelper.LARANJA);
            btnDesbloquear.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btnDesbloquear.addActionListener(e -> {
                String senhaGerente = JOptionPane.showInputDialog(this, "Digite a senha de um gerente ou admin do restaurante:");
                if (senhaGerente != null && validarSenhaGerente(senhaGerente)) {
                    txtPrecoOrig.setEditable(true);
                    txtPrecoOrig.setBackground(Color.WHITE);
                    txtPrecoDesc.setEditable(true);
                    txtPrecoDesc.setBackground(Color.WHITE);
                    btnDesbloquear.setEnabled(false);
                    btnDesbloquear.setText("Precos desbloqueados");
                    JOptionPane.showMessageDialog(this, "Precos desbloqueados com sucesso!");
                } else if (senhaGerente != null) {
                    JOptionPane.showMessageDialog(this, "Senha de gerente incorreta.", "Acesso negado", JOptionPane.ERROR_MESSAGE);
                }
            });
            gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
            form.add(btnDesbloquear, gbc);
            gbc.gridwidth = 1;
        }

        addFormField(form, gbc, row++, "Quantidade:", txtQtd);

        String titulo = existente != null ? "Editar Produto" : "Novo Produto";
        int resp = JOptionPane.showConfirmDialog(this, form, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resp != JOptionPane.OK_OPTION) return;

        try {
            Produto p = existente != null ? existente : new Produto();
            p.setRestauranteId(restaurante.getId());
            p.setNome(txtNome.getText().trim());
            p.setCategoria(txtCategoria.getText().trim());
            p.setDescricao(txtDesc.getText().trim());
            p.setPrecoOriginal(new BigDecimal(txtPrecoOrig.getText().replace(",", ".").trim()));
            p.setPrecoDesconto(new BigDecimal(txtPrecoDesc.getText().replace(",", ".").trim()));
            p.setQuantidade(Integer.parseInt(txtQtd.getText().trim()));
            p.setAtivo(true);
            if (imagemPath[0] != null) p.setImagemUrl(imagemPath[0]);

            ProdutoDAO dao = new ProdutoDAO();
            boolean ok = existente != null ? dao.atualizar(p) : dao.inserir(p);
            if (ok) { JOptionPane.showMessageDialog(this, "Produto salvo!"); refreshProdutos(); }
            else JOptionPane.showMessageDialog(this, "Erro ao salvar.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Valores numericos invalidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ============================================================== COMBOS
    private JPanel criarPainelCombos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(UIHelper.tituloSecao("Meus Combos", "Monte combos especiais para seus clientes"), BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        JButton btnNovo = UIHelper.botaoModerno("Novo combo", UIHelper.VERDE);
        btnNovo.addActionListener(e -> formCombo(null));
        acoes.add(btnNovo);
        topo.add(acoes, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        comboCardsPanel = new UIHelper.WrapPanel(new UIHelper.WrapLayout(FlowLayout.LEFT, 15, 15));
        comboCardsPanel.setBackground(UIHelper.FUNDO);
        JScrollPane scroll = new JScrollPane(comboCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UIHelper.FUNDO);
        p.add(scroll, BorderLayout.CENTER);

        refreshCombos();
        return p;
    }

    private void refreshCombos() {
        combosAtuais = new ComboDAO().listarPorRestaurante(restaurante.getId());
        comboCardsPanel.removeAll();
        for (Combo c : combosAtuais) comboCardsPanel.add(criarCardCombo(c));
        if (combosAtuais.isEmpty()) {
            JLabel lbl = new JLabel("Nenhum combo cadastrado. Clique em 'Novo combo' para comecar!");
            lbl.setForeground(UIHelper.TEXTO_SEC);
            lbl.setFont(new Font("SansSerif", Font.ITALIC, 14));
            comboCardsPanel.add(lbl);
        }
        comboCardsPanel.revalidate();
        comboCardsPanel.repaint();
    }

    private JPanel criarCardCombo(Combo cb) {
        JPanel card = UIHelper.cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(220, 330));

        JLabel lblImg = UIHelper.labelImagem(cb.getImagemUrl(), 196, 130);
        lblImg.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblImg);
        card.add(Box.createVerticalStrut(8));

        // Badge
        JLabel lblBadge = new JLabel("COMBO");
        lblBadge.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblBadge.setForeground(Color.WHITE);
        lblBadge.setOpaque(true);
        lblBadge.setBackground(UIHelper.AZUL);
        lblBadge.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
        lblBadge.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblBadge);
        card.add(Box.createVerticalStrut(6));

        JLabel lblNome = new JLabel("<html><center>" + cb.getNome() + "</center></html>");
        lblNome.setFont(UIHelper.SUBTITULO);
        lblNome.setForeground(UIHelper.TEXTO);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblNome);
        card.add(Box.createVerticalStrut(4));

        JLabel lblPreco = new JLabel("R$ " + cb.getPreco());
        lblPreco.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblPreco.setForeground(UIHelper.VERDE);
        lblPreco.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblPreco);

        JLabel lblQtd = new JLabel("Estoque: " + cb.getQuantidade());
        lblQtd.setFont(UIHelper.CORPO_PEQUENO);
        lblQtd.setForeground(UIHelper.TEXTO_SEC);
        lblQtd.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblQtd);
        card.add(Box.createVerticalGlue());

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        btns.setOpaque(false);
        JButton btnEdit = UIHelper.botaoModerno("Editar", UIHelper.AZUL);
        btnEdit.setPreferredSize(new Dimension(90, 30));
        btnEdit.addActionListener(e -> formCombo(cb));
        btns.add(btnEdit);
        card.add(btns);

        return card;
    }

    private void formCombo(Combo existente) {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtNome = new JTextField(existente != null ? existente.getNome() : "", 22);
        JTextArea txtDesc = new JTextArea(existente != null ? existente.getDescricao() : "", 3, 22);
        txtDesc.setLineWrap(true);
        JTextField txtPreco = new JTextField(existente != null ? existente.getPreco().toString() : "", 10);
        JTextField txtQtd = new JTextField(existente != null ? String.valueOf(existente.getQuantidade()) : "0", 5);

        final String[] imagemPath = {existente != null ? existente.getImagemUrl() : null};
        JLabel lblPreview = UIHelper.labelImagem(imagemPath[0], 200, 120);
        JButton btnFoto = UIHelper.botaoModerno("Escolher foto", UIHelper.AZUL);
        btnFoto.setPreferredSize(new Dimension(160, 30));
        btnFoto.addActionListener(e -> {
            File arquivo = UIHelper.escolherImagem(this);
            if (arquivo != null) {
                String caminho = UIHelper.salvarImagem(arquivo, "combos");
                if (caminho != null) {
                    imagemPath[0] = caminho;
                    ImageIcon icon = UIHelper.carregarImagem(caminho, 200, 120);
                    if (icon != null) { lblPreview.setIcon(icon); lblPreview.setText(""); lblPreview.setOpaque(false); }
                }
            }
        });

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        form.add(lblPreview, gbc);
        row++;
        gbc.gridy = row; gbc.gridwidth = 2;
        form.add(btnFoto, gbc);
        row++;
        gbc.gridwidth = 1;
        addFormField(form, gbc, row++, "Nome:", txtNome);
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        form.add(new JLabel("Descricao:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        form.add(new JScrollPane(txtDesc), gbc);
        row++;
        addFormField(form, gbc, row++, "Preco (R$):", txtPreco);
        addFormField(form, gbc, row++, "Quantidade:", txtQtd);

        String titulo = existente != null ? "Editar Combo" : "Novo Combo";
        int resp = JOptionPane.showConfirmDialog(this, form, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resp != JOptionPane.OK_OPTION) return;

        try {
            Combo c = existente != null ? existente : new Combo();
            c.setRestauranteId(restaurante.getId());
            c.setNome(txtNome.getText().trim());
            c.setDescricao(txtDesc.getText().trim());
            c.setPreco(new BigDecimal(txtPreco.getText().replace(",", ".").trim()));
            c.setQuantidade(Integer.parseInt(txtQtd.getText().trim()));
            c.setAtivo(true);
            if (imagemPath[0] != null) c.setImagemUrl(imagemPath[0]);

            ComboDAO dao = new ComboDAO();
            boolean ok = existente != null ? dao.atualizar(c) : dao.inserir(c);
            if (ok) { JOptionPane.showMessageDialog(this, "Combo salvo!"); refreshCombos(); }
            else JOptionPane.showMessageDialog(this, "Erro ao salvar.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Valores numericos invalidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ============================================================== PEDIDOS
    private JPanel pedCardsPanel;

    private JPanel criarPainelPedidos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        topo.add(UIHelper.tituloSecao("Pedidos recebidos", "Gerencie os pedidos dos seus clientes"), BorderLayout.WEST);

        JButton btnRefresh = UIHelper.botaoModerno("Atualizar", UIHelper.AZUL);
        btnRefresh.addActionListener(e -> refreshPedidos());
        topo.add(btnRefresh, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        pedCardsPanel = new JPanel();
        pedCardsPanel.setLayout(new BoxLayout(pedCardsPanel, BoxLayout.Y_AXIS));
        pedCardsPanel.setOpaque(false);
        JScrollPane scroll = new JScrollPane(pedCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UIHelper.FUNDO);
        p.add(scroll, BorderLayout.CENTER);

        refreshPedidos();
        return p;
    }

    private Color corFundoStatus(String status) {
        if (status == null) return Color.WHITE;
        switch (status) {
            case "ENTREGUE":   return new Color(220, 245, 220);
            case "CONFIRMADO": return new Color(220, 235, 255);
            case "PENDENTE":   return new Color(255, 243, 220);
            case "CANCELADO":  return new Color(255, 220, 220);
            default: return Color.WHITE;
        }
    }
    private Color corTextoStatus(String status) {
        if (status == null) return Color.BLACK;
        switch (status) {
            case "ENTREGUE":   return new Color(30, 120, 30);
            case "CONFIRMADO": return new Color(30, 80, 170);
            case "PENDENTE":   return new Color(180, 100, 0);
            case "CANCELADO":  return new Color(170, 30, 30);
            default: return Color.BLACK;
        }
    }

    private void refreshPedidos() {
        pedidosAtuais = new PedidoDAO().listarPorRestaurante(restaurante.getId());
        pedCardsPanel.removeAll();

        if (pedidosAtuais.isEmpty()) {
            JLabel vazio = new JLabel("Nenhum pedido recebido ainda.");
            vazio.setFont(new Font("SansSerif", Font.ITALIC, 14));
            vazio.setForeground(Color.GRAY);
            vazio.setAlignmentX(Component.CENTER_ALIGNMENT);
            pedCardsPanel.add(Box.createVerticalStrut(40));
            pedCardsPanel.add(vazio);
        }

        for (Pedido ped : pedidosAtuais) {
            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 4, 0, 0, corTextoStatus(ped.getStatus())),
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 225, 225)),
                            BorderFactory.createEmptyBorder(10, 12, 10, 12))));
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

            // Linha 1: ID + badge + valor
            JPanel linha1 = new JPanel(new BorderLayout());
            linha1.setOpaque(false);
            JPanel idBadge = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
            idBadge.setOpaque(false);
            JLabel lblId = new JLabel("Pedido #" + ped.getId());
            lblId.setFont(new Font("SansSerif", Font.BOLD, 14));
            lblId.setForeground(UIHelper.VERDE_ESCURO);
            idBadge.add(lblId);
            JLabel badge = new JLabel(" " + ped.getStatus() + " ");
            badge.setFont(new Font("SansSerif", Font.BOLD, 10));
            badge.setForeground(corTextoStatus(ped.getStatus()));
            badge.setOpaque(true);
            badge.setBackground(corFundoStatus(ped.getStatus()));
            badge.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(corTextoStatus(ped.getStatus()), 1),
                    BorderFactory.createEmptyBorder(1, 6, 1, 6)));
            idBadge.add(badge);
            linha1.add(idBadge, BorderLayout.WEST);
            JLabel lblTotal = new JLabel("R$ " + ped.getValorTotal() + "  ");
            lblTotal.setFont(new Font("SansSerif", Font.BOLD, 16));
            lblTotal.setForeground(UIHelper.VERDE);
            linha1.add(lblTotal, BorderLayout.EAST);
            card.add(linha1);

            // Linha 2: cliente + data + pagamento
            JPanel linha2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            linha2.setOpaque(false);
            JLabel lblCliente = new JLabel(ped.getClienteNome());
            lblCliente.setFont(new Font("SansSerif", Font.BOLD, 12));
            lblCliente.setForeground(UIHelper.TEXTO);
            linha2.add(lblCliente);
            JLabel lblSep = new JLabel("|");
            lblSep.setForeground(new Color(200, 200, 200));
            linha2.add(lblSep);
            JLabel lblData = new JLabel(ped.getDataPedido() != null ? ped.getDataPedido().format(FMT) : "");
            lblData.setFont(UIHelper.CORPO_PEQUENO);
            lblData.setForeground(new Color(140, 140, 140));
            linha2.add(lblData);
            JLabel lblSep2 = new JLabel("|");
            lblSep2.setForeground(new Color(200, 200, 200));
            linha2.add(lblSep2);
            JLabel lblPag = new JLabel(ClienteFrame.traduzirPagamento(ped.getFormaPagamento()));
            lblPag.setFont(UIHelper.CORPO_PEQUENO);
            lblPag.setForeground(new Color(140, 140, 140));
            linha2.add(lblPag);
            card.add(linha2);

            // Linha 3: botoes de acao
            JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
            btns.setOpaque(false);
            String st = ped.getStatus();
            if ("PENDENTE".equals(st) || "CONFIRMADO".equals(st)) {
                if ("PENDENTE".equals(st)) {
                    JButton btnConf = UIHelper.botaoModerno("Confirmar", UIHelper.VERDE);
                    btnConf.setFont(new Font("SansSerif", Font.BOLD, 11));
                    btnConf.setPreferredSize(new Dimension(90, 26));
                    btnConf.addActionListener(e -> alterarStatus(ped, "CONFIRMADO"));
                    btns.add(btnConf);
                }
                JButton btnEnt = UIHelper.botaoModerno("Entregar", UIHelper.AZUL);
                btnEnt.setFont(new Font("SansSerif", Font.BOLD, 11));
                btnEnt.setPreferredSize(new Dimension(80, 26));
                btnEnt.addActionListener(e -> alterarStatus(ped, "ENTREGUE"));
                btns.add(btnEnt);
                JButton btnCanc = UIHelper.botaoModerno("Cancelar", UIHelper.VERMELHO);
                btnCanc.setFont(new Font("SansSerif", Font.BOLD, 11));
                btnCanc.setPreferredSize(new Dimension(80, 26));
                btnCanc.addActionListener(e -> alterarStatus(ped, "CANCELADO"));
                btns.add(btnCanc);
            }
            JButton btnDet = UIHelper.botaoModerno("Detalhes", UIHelper.LARANJA);
            btnDet.setFont(new Font("SansSerif", Font.BOLD, 11));
            btnDet.setPreferredSize(new Dimension(80, 26));
            btnDet.addActionListener(e -> verDetalhes(ped));
            btns.add(btnDet);
            card.add(btns);

            pedCardsPanel.add(card);
        }

        pedCardsPanel.revalidate();
        pedCardsPanel.repaint();
    }

    private void alterarStatus(Pedido ped, String novoStatus) {
        if (new PedidoDAO().alterarStatus(ped.getId(), novoStatus)) {
            JOptionPane.showMessageDialog(this, "Status atualizado para " + novoStatus);
            refreshPedidos();
        }
    }

    private void verDetalhes(Pedido ped) {
        List<PedidoItem> itens = new PedidoDAO().listarItens(ped.getId());
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido #").append(ped.getId()).append("\n");
        sb.append("Cliente: ").append(ped.getClienteNome()).append("\n");
        sb.append("Status: ").append(ped.getStatus()).append("\n");
        sb.append("Entrega: ").append(ClienteFrame.traduzirEntrega(ped.getTipoEntrega())).append("\n");
        if (ped.getEnderecoEntrega() != null) sb.append("Endereco: ").append(ped.getEnderecoEntrega()).append("\n");
        sb.append("Pagamento: ").append(ClienteFrame.traduzirPagamento(ped.getFormaPagamento())).append("\n");
        if (ped.getTroco() != null && ped.getTroco().compareTo(BigDecimal.ZERO) > 0) {
            sb.append("Troco: R$ ").append(ped.getTroco()).append("\n");
        }
        sb.append("\nItens:\n");
        for (PedidoItem it : itens) {
            sb.append("  - ").append(it.getDescricao()).append(" x").append(it.getQuantidade())
                    .append(" = R$ ").append(it.getPrecoUnitario().multiply(BigDecimal.valueOf(it.getQuantidade()))).append("\n");
        }
        sb.append("\nTotal: R$ ").append(ped.getValorTotal());
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(UIHelper.CORPO);
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(420, 320));
        JOptionPane.showMessageDialog(this, sp, "Detalhes do pedido", JOptionPane.PLAIN_MESSAGE);
    }

    // ============================================================== PERFIL
    private JPanel criarPainelPerfil() {
        JPanel wrapper = new JPanel(new BorderLayout(20, 0));
        wrapper.setBackground(UIHelper.FUNDO);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        // ====== Coluna esquerda: foto + gráficos ======
        JPanel esquerda = new JPanel();
        esquerda.setLayout(new BoxLayout(esquerda, BoxLayout.Y_AXIS));
        esquerda.setOpaque(false);
        esquerda.setPreferredSize(new Dimension(320, 0));

        // Foto de perfil
        JPanel fotoCard = UIHelper.cardPanel();
        fotoCard.setLayout(new BoxLayout(fotoCard, BoxLayout.Y_AXIS));
        fotoCard.setMaximumSize(new Dimension(320, 260));

        JLabel lblFotoTitulo = new JLabel("Foto do restaurante");
        lblFotoTitulo.setFont(UIHelper.SUBTITULO);
        lblFotoTitulo.setForeground(UIHelper.VERDE_ESCURO);
        lblFotoTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        fotoCard.add(lblFotoTitulo);
        fotoCard.add(Box.createVerticalStrut(10));

        JLabel lblFoto = UIHelper.labelImagem(restaurante.getImagemUrl(), 180, 140);
        lblFoto.setAlignmentX(Component.CENTER_ALIGNMENT);
        fotoCard.add(lblFoto);
        fotoCard.add(Box.createVerticalStrut(10));

        JPanel fotoBtns = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        fotoBtns.setOpaque(false);
        JButton btnFoto = UIHelper.botaoModerno("Alterar foto", UIHelper.AZUL);
        btnFoto.setPreferredSize(new Dimension(130, 30));
        btnFoto.addActionListener(e -> {
            java.io.File arquivo = UIHelper.escolherImagem(this);
            if (arquivo != null) {
                String caminho = UIHelper.salvarImagem(arquivo, "perfis");
                if (caminho != null) {
                    restaurante.setImagemUrl(caminho);
                    new RestauranteDAO().atualizar(restaurante);
                    ImageIcon ic = UIHelper.carregarImagem(caminho, 180, 140);
                    if (ic != null) { lblFoto.setIcon(ic); lblFoto.setText(""); lblFoto.setOpaque(false); }
                }
            }
        });
        JButton btnRemFoto = UIHelper.botaoModerno("Remover", UIHelper.VERMELHO);
        btnRemFoto.setPreferredSize(new Dimension(100, 30));
        btnRemFoto.addActionListener(e -> {
            restaurante.setImagemUrl(null);
            new RestauranteDAO().atualizar(restaurante);
            lblFoto.setIcon(null);
            lblFoto.setOpaque(true);
            lblFoto.setBackground(UIHelper.VERDE_CLARO);
            lblFoto.setText("\uD83C\uDF7D");
        });
        fotoBtns.add(btnFoto);
        fotoBtns.add(btnRemFoto);
        fotoCard.add(fotoBtns);

        esquerda.add(fotoCard);
        esquerda.add(Box.createVerticalStrut(15));

        // Gráfico de vendas
        JPanel graficoCard = UIHelper.cardPanel();
        graficoCard.setLayout(new BoxLayout(graficoCard, BoxLayout.Y_AXIS));

        JLabel lblGrafico = new JLabel("Resumo de vendas");
        lblGrafico.setFont(UIHelper.TITULO);
        lblGrafico.setForeground(UIHelper.VERDE_ESCURO);
        lblGrafico.setAlignmentX(Component.CENTER_ALIGNMENT);
        graficoCard.add(lblGrafico);
        graficoCard.add(Box.createVerticalStrut(6));

        List<Pedido> pedidos = new PedidoDAO().listarPorRestaurante(restaurante.getId());
        int totalPedidos = pedidos.size();
        int entregues = 0, pendentes = 0, cancelados = 0;
        BigDecimal faturamento = BigDecimal.ZERO;
        for (Pedido p : pedidos) {
            if ("ENTREGUE".equals(p.getStatus())) { entregues++; faturamento = faturamento.add(p.getValorTotal()); }
            else if ("CANCELADO".equals(p.getStatus())) cancelados++;
            else pendentes++;
        }
        int numProdutos = new ProdutoDAO().listarPorRestaurante(restaurante.getId()).size();

        // Faturamento destaque
        JLabel lblFat = new JLabel("R$ " + faturamento);
        lblFat.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblFat.setForeground(UIHelper.VERDE);
        lblFat.setAlignmentX(Component.CENTER_ALIGNMENT);
        graficoCard.add(lblFat);
        JLabel lblFatSub = new JLabel("faturamento total");
        lblFatSub.setFont(UIHelper.CORPO_PEQUENO);
        lblFatSub.setForeground(Color.GRAY);
        lblFatSub.setAlignmentX(Component.CENTER_ALIGNMENT);
        graficoCard.add(lblFatSub);
        graficoCard.add(Box.createVerticalStrut(16));

        // Barras horizontais com rótulo e porcentagem
        int finalEntregues = entregues;
        int finalPendentes = pendentes;
        int finalCancelados = cancelados;
        graficoCard.add(criarBarraStatus("Entregues", finalEntregues, totalPedidos, UIHelper.VERDE));
        graficoCard.add(Box.createVerticalStrut(8));
        graficoCard.add(criarBarraStatus("Pendentes", finalPendentes, totalPedidos, UIHelper.LARANJA));
        graficoCard.add(Box.createVerticalStrut(8));
        graficoCard.add(criarBarraStatus("Cancelados", finalCancelados, totalPedidos, UIHelper.VERMELHO));
        graficoCard.add(Box.createVerticalStrut(16));

        // Resumo em cards menores
        JPanel resumo = new JPanel(new GridLayout(1, 3, 8, 0));
        resumo.setOpaque(false);
        resumo.setMaximumSize(new Dimension(320, 60));
        resumo.setAlignmentX(Component.CENTER_ALIGNMENT);
        resumo.add(criarMiniStat("Pedidos", String.valueOf(totalPedidos), UIHelper.VERDE_ESCURO));
        resumo.add(criarMiniStat("Produtos", String.valueOf(numProdutos), UIHelper.AZUL));
        resumo.add(criarMiniStat("Taxa entrega", totalPedidos > 0 ? ((finalEntregues * 100 / totalPedidos) + "%") : "0%", UIHelper.VERDE));
        graficoCard.add(resumo);

        esquerda.add(graficoCard);
        wrapper.add(esquerda, BorderLayout.WEST);

        // ====== Coluna direita: formulário de dados ======
        JPanel card = UIHelper.cardPanel();
        card.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        JLabel lbl = new JLabel("Dados do restaurante");
        lbl.setFont(UIHelper.TITULO);
        lbl.setForeground(UIHelper.VERDE_ESCURO);
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        card.add(lbl, gbc);
        gbc.gridwidth = 1;

        JTextField txtNome = new JTextField(restaurante.getNome(), 22);
        JTextField txtCnpj = new JTextField(restaurante.getCnpj(), 18);
        JTextField txtTel = new JTextField(restaurante.getTelefone(), 15);
        JTextArea txtDesc = new JTextArea(restaurante.getDescricao(), 2, 22);
        txtDesc.setLineWrap(true);
        JTextField txtEnd = new JTextField(restaurante.getEndereco(), 22);
        JTextField txtNum = new JTextField(restaurante.getNumero(), 8);
        JTextField txtBairro = new JTextField(restaurante.getBairro(), 15);
        JTextField txtCidade = new JTextField(restaurante.getCidade(), 15);
        JTextField txtEstado = new JTextField(restaurante.getEstado(), 5);
        JTextField txtCep = new JTextField(restaurante.getCep(), 10);

        addFormField(card, gbc, row++, "Nome:", txtNome);
        addFormField(card, gbc, row++, "CNPJ:", txtCnpj);
        addFormField(card, gbc, row++, "Telefone:", txtTel);
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        card.add(new JLabel("Descricao:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        card.add(new JScrollPane(txtDesc), gbc);
        row++;
        addFormField(card, gbc, row++, "CEP:", txtCep);
        addFormField(card, gbc, row++, "Endereco:", txtEnd);
        addFormField(card, gbc, row++, "Numero:", txtNum);
        addFormField(card, gbc, row++, "Bairro:", txtBairro);
        addFormField(card, gbc, row++, "Cidade:", txtCidade);
        addFormField(card, gbc, row++, "Estado:", txtEstado);

        JButton btnSalvar = UIHelper.botaoModerno("Salvar dados", UIHelper.VERDE);
        btnSalvar.addActionListener(e -> {
            restaurante.setNome(txtNome.getText().trim());
            restaurante.setCnpj(txtCnpj.getText().trim());
            restaurante.setTelefone(txtTel.getText().trim());
            restaurante.setDescricao(txtDesc.getText().trim());
            restaurante.setEndereco(txtEnd.getText().trim());
            restaurante.setNumero(txtNum.getText().trim());
            restaurante.setBairro(txtBairro.getText().trim());
            restaurante.setCidade(txtCidade.getText().trim());
            restaurante.setEstado(txtEstado.getText().trim());
            restaurante.setCep(txtCep.getText().trim());
            if (new RestauranteDAO().atualizar(restaurante)) {
                setTitle("SaveByte - " + restaurante.getNome());
                JOptionPane.showMessageDialog(this, "Dados atualizados!");
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        card.add(btnSalvar, gbc);
        row++;

        // Separador
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 8, 5, 8);
        JLabel lblSenha = new JLabel("Alterar senha");
        lblSenha.setFont(UIHelper.SUBTITULO);
        lblSenha.setForeground(UIHelper.VERDE_ESCURO);
        card.add(lblSenha, gbc);
        gbc.insets = new Insets(5, 8, 5, 8);

        JPasswordField txtSenhaAtual = new JPasswordField(20);
        JPasswordField txtNovaSenha = new JPasswordField(20);
        JPasswordField txtConfirmarSenha = new JPasswordField(20);
        gbc.gridwidth = 1;
        addFormField(card, gbc, row++, "Senha atual:", txtSenhaAtual);
        addFormField(card, gbc, row++, "Nova senha:", txtNovaSenha);
        addFormField(card, gbc, row++, "Confirmar:", txtConfirmarSenha);

        JButton btnSenha = UIHelper.botaoModerno("Alterar senha", UIHelper.LARANJA);
        btnSenha.addActionListener(e -> {
            String atual = new String(txtSenhaAtual.getPassword()).trim();
            String nova = new String(txtNovaSenha.getPassword()).trim();
            String confirmar = new String(txtConfirmarSenha.getPassword()).trim();
            if (atual.isEmpty() || nova.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos de senha."); return;
            }
            if (!nova.equals(confirmar)) {
                JOptionPane.showMessageDialog(this, "As senhas nao conferem."); return;
            }
            if (!org.mindrot.jbcrypt.BCrypt.checkpw(atual, restaurante.getSenha())) {
                JOptionPane.showMessageDialog(this, "Senha atual incorreta."); return;
            }
            restaurante.setSenha(org.mindrot.jbcrypt.BCrypt.hashpw(nova, org.mindrot.jbcrypt.BCrypt.gensalt()));
            restaurante.setSenhaVisivel(nova);
            if (new RestauranteDAO().atualizar(restaurante)) {
                JOptionPane.showMessageDialog(this, "Senha alterada com sucesso!");
                txtSenhaAtual.setText(""); txtNovaSenha.setText(""); txtConfirmarSenha.setText("");
            }
        });
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        card.add(btnSenha, gbc);

        JScrollPane scroll = new JScrollPane(card);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        wrapper.add(scroll, BorderLayout.CENTER);

        return wrapper;
    }

    private JPanel criarBarraStatus(String label, int valor, int total, Color cor) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setMaximumSize(new Dimension(320, 40));
        p.setAlignmentX(Component.CENTER_ALIGNMENT);

        int pct = total > 0 ? (valor * 100 / total) : 0;
        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        topRow.setMaximumSize(new Dimension(300, 16));
        JLabel lblName = new JLabel(label);
        lblName.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblName.setForeground(UIHelper.TEXTO);
        topRow.add(lblName, BorderLayout.WEST);
        JLabel lblVal = new JLabel(valor + " (" + pct + "%)");
        lblVal.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblVal.setForeground(cor);
        topRow.add(lblVal, BorderLayout.EAST);
        p.add(topRow);
        p.add(Box.createVerticalStrut(3));

        JPanel barraPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = 12;
                g2.setColor(new Color(230, 230, 230));
                g2.fillRoundRect(0, 0, w, h, 8, 8);
                if (total > 0 && valor > 0) {
                    int filled = Math.max(8, (int)(w * ((double)valor / total)));
                    g2.setColor(cor);
                    g2.fillRoundRect(0, 0, filled, h, 8, 8);
                }
                g2.dispose();
            }
        };
        barraPanel.setOpaque(false);
        barraPanel.setPreferredSize(new Dimension(300, 12));
        barraPanel.setMaximumSize(new Dimension(300, 12));
        p.add(barraPanel);
        return p;
    }

    private JPanel criarMiniStat(String label, String valor, Color cor) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(new Color(245, 247, 250));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));

        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblValor.setForeground(cor);
        lblValor.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(lblValor);

        JLabel lblLabel = new JLabel(label);
        lblLabel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblLabel.setForeground(Color.GRAY);
        lblLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(lblLabel);
        return p;
    }

    // ============================================================== UTILS
    /** Valida a senha contra usuarios com permissao de preco/admin deste restaurante, ou contra a senha do dono */
    private boolean validarSenhaGerente(String senha) {
        // Verifica contra a senha do dono do restaurante
        if (org.mindrot.jbcrypt.BCrypt.checkpw(senha, restaurante.getSenha())) return true;
        // Verifica contra usuarios do restaurante que tenham permissao de precos ou gerenciar usuarios
        List<Usuario> usuarios = new UsuarioDAO().listarPorRestaurante(restaurante.getId());
        for (Usuario u : usuarios) {
            if (senha.equals(u.getSenha()) && u.getGrupoAcessoId() != null) {
                GrupoAcesso g = new GrupoAcessoDAO().buscarPorId(u.getGrupoAcessoId());
                if (g != null && (g.isPodeAlterarPrecos() || g.isPodeGerenciarUsuarios())) return true;
            }
        }
        return false;
    }

    private void addFormField(JPanel p, GridBagConstraints gbc, int row, String label, JComponent campo) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        JLabel lbl = new JLabel(label);
        lbl.setFont(UIHelper.CORPO);
        p.add(lbl, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        p.add(campo, gbc);
    }

    // ============================================================== GRUPOS DE ACESSO
    private JPanel criarPainelGrupos() {
        JPanel p = UIHelper.painelConteudo();

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        JPanel titles = new JPanel();
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.setOpaque(false);
        JLabel lblTitulo = new JLabel("Grupos de Acesso");
        lblTitulo.setFont(UIHelper.TITULO);
        lblTitulo.setForeground(UIHelper.VERDE_ESCURO);
        titles.add(lblTitulo);
        JLabel lblSub = new JLabel("Defina permissoes para cada funcao no restaurante");
        lblSub.setFont(UIHelper.CORPO_PEQUENO);
        lblSub.setForeground(new Color(130, 130, 130));
        titles.add(lblSub);
        topo.add(titles, BorderLayout.WEST);

        JButton btnNovo = UIHelper.botaoModerno("Novo grupo", UIHelper.VERDE);
        btnNovo.addActionListener(e -> abrirFormularioGrupo(null));
        topo.add(btnNovo, BorderLayout.EAST);
        p.add(topo, BorderLayout.NORTH);

        grupoCardsPanel = new JPanel();
        grupoCardsPanel.setLayout(new BoxLayout(grupoCardsPanel, BoxLayout.Y_AXIS));
        grupoCardsPanel.setOpaque(false);

        JScrollPane scroll = new JScrollPane(grupoCardsPanel);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UIHelper.FUNDO);
        p.add(scroll, BorderLayout.CENTER);

        refreshGrupos();
        return p;
    }

    private JPanel grupoCardsPanel;

    private void refreshGrupos() {
        grupoCardsPanel.removeAll();
        java.util.List<br.com.usjt.savebyte.model.GrupoAcesso> grupos =
                new br.com.usjt.savebyte.dao.GrupoAcessoDAO().listarPorRestaurante(restaurante.getId());

        if (grupos.isEmpty()) {
            JLabel lbl = new JLabel("Nenhum grupo de acesso criado. Crie o primeiro!");
            lbl.setForeground(Color.GRAY);
            lbl.setFont(new Font("SansSerif", Font.ITALIC, 14));
            lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            grupoCardsPanel.add(Box.createVerticalStrut(30));
            grupoCardsPanel.add(lbl);
        }

        for (br.com.usjt.savebyte.model.GrupoAcesso g : grupos) {
            JPanel card = new JPanel(new BorderLayout(10, 0));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 225, 225)),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)));
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));

            // Info
            JPanel info = new JPanel();
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.setOpaque(false);
            JLabel lblNome = new JLabel(g.getNome());
            lblNome.setFont(new Font("SansSerif", Font.BOLD, 15));
            lblNome.setForeground(UIHelper.VERDE_ESCURO);
            info.add(lblNome);

            StringBuilder perms = new StringBuilder();
            if (g.isPodeVerVendas()) perms.append("Vendas  ");
            if (g.isPodeVerFaturamento()) perms.append("Faturamento  ");
            if (g.isPodeGerenciarProdutos()) perms.append("Produtos  ");
            if (g.isPodeGerenciarPedidos()) perms.append("Pedidos  ");
            if (g.isPodeGerenciarUsuarios()) perms.append("Usuarios  ");
            if (g.isPodeAlterarPrecos()) perms.append("Precos  ");
            if (perms.length() == 0) perms.append("Nenhuma permissao");
            JLabel lblPerms = new JLabel(perms.toString().trim());
            lblPerms.setFont(UIHelper.CORPO_PEQUENO);
            lblPerms.setForeground(new Color(120, 120, 120));
            info.add(lblPerms);
            card.add(info, BorderLayout.CENTER);

            // Botoes
            JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
            btns.setOpaque(false);
            JButton btnEditar = UIHelper.botaoModerno("Editar", UIHelper.AZUL);
            btnEditar.setFont(new Font("SansSerif", Font.BOLD, 11));
            btnEditar.setPreferredSize(new Dimension(70, 28));
            btnEditar.addActionListener(e -> abrirFormularioGrupo(g));
            btns.add(btnEditar);
            JButton btnExcluir = UIHelper.botaoModerno("Excluir", UIHelper.VERMELHO);
            btnExcluir.setFont(new Font("SansSerif", Font.BOLD, 11));
            btnExcluir.setPreferredSize(new Dimension(70, 28));
            btnExcluir.addActionListener(e -> {
                int resp = JOptionPane.showConfirmDialog(this, "Excluir o grupo \"" + g.getNome() + "\"?", "Confirmacao", JOptionPane.YES_NO_OPTION);
                if (resp == JOptionPane.YES_OPTION) {
                    new br.com.usjt.savebyte.dao.GrupoAcessoDAO().excluir(g.getId());
                    refreshGrupos();
                }
            });
            btns.add(btnExcluir);
            card.add(btns, BorderLayout.EAST);

            grupoCardsPanel.add(card);
        }

        grupoCardsPanel.revalidate();
        grupoCardsPanel.repaint();
    }

    private void abrirFormularioGrupo(br.com.usjt.savebyte.model.GrupoAcesso existente) {
        JTextField txtNome = new JTextField(existente != null ? existente.getNome() : "", 20);
        JCheckBox chkVendas = new JCheckBox("Ver vendas", existente != null && existente.isPodeVerVendas());
        JCheckBox chkFaturamento = new JCheckBox("Ver faturamento", existente != null && existente.isPodeVerFaturamento());
        JCheckBox chkProdutos = new JCheckBox("Gerenciar produtos", existente != null && existente.isPodeGerenciarProdutos());
        JCheckBox chkPedidos = new JCheckBox("Gerenciar pedidos", existente != null && existente.isPodeGerenciarPedidos());
        JCheckBox chkUsuarios = new JCheckBox("Gerenciar usuarios", existente != null && existente.isPodeGerenciarUsuarios());
        JCheckBox chkPrecos = new JCheckBox("Alterar precos", existente != null && existente.isPodeAlterarPrecos());

        JPanel form = new JPanel(new GridLayout(7, 1, 4, 4));
        JPanel nomeRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        nomeRow.add(new JLabel("Nome do grupo:"));
        nomeRow.add(txtNome);
        form.add(nomeRow);
        form.add(chkVendas);
        form.add(chkFaturamento);
        form.add(chkProdutos);
        form.add(chkPedidos);
        form.add(chkUsuarios);
        form.add(chkPrecos);

        String titulo = existente != null ? "Editar Grupo" : "Novo Grupo de Acesso";
        int resp = JOptionPane.showConfirmDialog(this, form, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resp != JOptionPane.OK_OPTION) return;

        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o nome do grupo.");
            return;
        }

        br.com.usjt.savebyte.model.GrupoAcesso g = existente != null ? existente : new br.com.usjt.savebyte.model.GrupoAcesso();
        g.setRestauranteId(restaurante.getId());
        g.setNome(txtNome.getText().trim());
        g.setPodeVerVendas(chkVendas.isSelected());
        g.setPodeVerFaturamento(chkFaturamento.isSelected());
        g.setPodeGerenciarProdutos(chkProdutos.isSelected());
        g.setPodeGerenciarPedidos(chkPedidos.isSelected());
        g.setPodeGerenciarUsuarios(chkUsuarios.isSelected());
        g.setPodeAlterarPrecos(chkPrecos.isSelected());

        br.com.usjt.savebyte.dao.GrupoAcessoDAO gDao = new br.com.usjt.savebyte.dao.GrupoAcessoDAO();
        boolean ok = existente != null ? gDao.atualizar(g) : gDao.inserir(g);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Grupo salvo com sucesso!");
            refreshGrupos();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
