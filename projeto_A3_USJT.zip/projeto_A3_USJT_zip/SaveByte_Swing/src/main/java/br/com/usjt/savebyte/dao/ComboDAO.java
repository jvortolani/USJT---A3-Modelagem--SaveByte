package br.com.usjt.savebyte.dao;

import br.com.usjt.savebyte.model.Combo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComboDAO {

    public List<Combo> listarAtivos() {
        List<Combo> lista = new ArrayList<>();
        String sql = "SELECT c.*, r.nome AS rest_nome FROM combo c JOIN restaurante r ON c.restaurante_id = r.id WHERE c.ativo = 1 AND c.quantidade > 0 ORDER BY c.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public List<Combo> listarPorRestaurante(long restauranteId) {
        List<Combo> lista = new ArrayList<>();
        String sql = "SELECT c.*, r.nome AS rest_nome FROM combo c JOIN restaurante r ON c.restaurante_id = r.id WHERE c.restaurante_id = ? ORDER BY c.nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, restauranteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public boolean inserir(Combo c) {
        String sql = "INSERT INTO combo (restaurante_id, nome, descricao, preco, quantidade, ativo, imagem_url, criado_em) VALUES (?,?,?,?,?,?,?,NOW())";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, c.getRestauranteId());
            ps.setString(2, c.getNome());
            ps.setString(3, c.getDescricao());
            ps.setBigDecimal(4, c.getPreco());
            ps.setInt(5, c.getQuantidade());
            ps.setBoolean(6, c.isAtivo());
            ps.setString(7, c.getImagemUrl());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) c.setId(keys.getLong(1));
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean atualizar(Combo c) {
        String sql = "UPDATE combo SET nome=?, descricao=?, preco=?, quantidade=?, ativo=?, imagem_url=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getNome());
            ps.setString(2, c.getDescricao());
            ps.setBigDecimal(3, c.getPreco());
            ps.setInt(4, c.getQuantidade());
            ps.setBoolean(5, c.isAtivo());
            ps.setString(6, c.getImagemUrl());
            ps.setLong(7, c.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    private Combo mapear(ResultSet rs) throws SQLException {
        Combo c = new Combo();
        c.setId(rs.getLong("id"));
        c.setRestauranteId(rs.getLong("restaurante_id"));
        try { c.setRestauranteNome(rs.getString("rest_nome")); } catch (SQLException ignored) {}
        c.setNome(rs.getString("nome"));
        c.setDescricao(rs.getString("descricao"));
        c.setPreco(rs.getBigDecimal("preco"));
        c.setQuantidade(rs.getInt("quantidade"));
        c.setAtivo(rs.getBoolean("ativo"));
        c.setImagemUrl(rs.getString("imagem_url"));
        return c;
    }
}
