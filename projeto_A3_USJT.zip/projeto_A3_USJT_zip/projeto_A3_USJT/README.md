# SaveByte — Projeto A3 (USJT)

Plataforma de consumo consciente de alimentos (inspirado no "Food to Save" /
"Too Good To Go"). Restaurantes disponibilizam pratos frescos e "combos surpresa"
com precos especiais; clientes buscam, adicionam ao carrinho, escolhem entrega
ou retirada e aproveitam refeicoes de qualidade pagando menos.

## Tecnologias

- Java 17 + Spring Boot 3.4 (Web, Thymeleaf, Spring Data JPA)
- MySQL 8
- HTML + Bootstrap 5 (via CDN)
- Senhas criptografadas com BCrypt
- Login por sessao, com perfis separados: **CLIENTE** e **RESTAURANTE**

## Pre-requisitos

| Ferramenta | Versao | Onde baixar |
|---|---|---|
| JDK | 17 ou superior | https://adoptium.net |
| MySQL Server | 8.x | https://dev.mysql.com/downloads/installer/ |
| MySQL Workbench | qualquer | (vem junto no instalador acima) |
| Maven | 3.8+ | https://maven.apache.org — **opcional** se usar IntelliJ IDEA (que ja inclui Maven) |

## Passo a passo para rodar

### 1. Criar o banco de dados

Abra o **MySQL Workbench**, conecte no servidor local e execute o arquivo
`database/schema.sql` inteiro (icone de raio). Ele cria o banco `savebyte`
e todas as tabelas.

> O arquivo e comentado e facil de editar: cada tabela e coluna tem
> comentarios explicando a finalidade. Pode ser executado mais de uma vez.

### 2. Conferir usuario/senha do MySQL

Edite `src/main/resources/application.properties` e ajuste, se necessario:

```properties
spring.datasource.username=root
spring.datasource.password=root
```

### 3. Subir a aplicacao

**Opcao A — IntelliJ IDEA (recomendado para apresentar):**
abra a pasta do projeto, aguarde o Maven baixar as dependencias e execute
a classe `SaveByteApplication` (botao play).

**Opcao B — terminal:**

```bash
mvn spring-boot:run
```

### 4. Acessar

http://localhost:8080

Na primeira execucao, dados de demonstracao sao criados automaticamente:

| Perfil | E-mail | Senha |
|---|---|---|
| Cliente | `cliente@teste.com` | `123456` |
| Restaurante | `restaurante@teste.com` | `123456` |
| Restaurante 2 | `sabor@teste.com` | `123456` |

## Migrando para outro computador

1. Copie a pasta inteira `projeto_A3_USJT`.
2. No novo PC: instale JDK 17+, MySQL 8 e execute `database/schema.sql`.
3. Ajuste usuario/senha em `application.properties`.
4. Rode o projeto (`mvn spring-boot:run` ou pela IDE).

## Como usar

**Restaurante** (`/restaurante/...`)
- Painel com resumo (produtos, combos, pedidos pendentes)
- Cadastro/edicao de produtos: nome, categoria, preco normal, preco com
  desconto, estoque
- Cadastro de combos: escolha produtos do proprio cardapio e a quantidade
  de cada um
- Gestao de pedidos recebidos: confirmar, marcar como entregue ou cancelar

**Cliente** (`/cliente/...`)
- Busca por restaurante, prato ou combo
- Pagina do restaurante com endereco e cardapio completo
- Reserva de produtos/combos com quantidade
- Acompanhamento dos pedidos e cancelamento (enquanto pendente)

## Estrutura

```
projeto_A3_USJT/
├── database/schema.sql        <- script do banco (edite aqui)
├── pom.xml                    <- dependencias Maven
└── src/main/
    ├── java/br/com/usjt/foodsaver/
    │   ├── SaveByteApplication.java
    │   ├── config/            <- interceptor de login, seed de dados
    │   ├── controller/        <- Auth, Cliente, Restaurante, Home
    │   ├── model/             <- entidades JPA (espelham as tabelas)
    │   ├── repository/        <- interfaces Spring Data JPA
    │   └── service/           <- regra de pedido/estoque
    └── resources/
        ├── application.properties
        ├── static/css/style.css
        └── templates/         <- paginas HTML (Thymeleaf + Bootstrap)
```

## Modelo do banco (resumo)

- `cliente` — cadastro do cliente (nome, e-mail, senha, endereco)
- `restaurante` — cadastro do restaurante (nome, CNPJ, endereco completo)
- `produto` — item avulso com `preco_original` e `preco_desconto`
- `combo` — "caixa surpresa" com preco unico
- `combo_item` — produtos que compoem cada combo (N:N)
- `pedido` — reserva do cliente (status: PENDENTE → CONFIRMADO → ENTREGUE, ou CANCELADO)
- `pedido_item` — itens do pedido (aponta para produto **ou** combo)

Ao reservar, o estoque e baixado; ao cancelar, o estoque e devolvido.
