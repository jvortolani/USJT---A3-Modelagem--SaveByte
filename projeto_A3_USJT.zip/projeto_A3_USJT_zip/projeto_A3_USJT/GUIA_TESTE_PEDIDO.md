# Guia de Teste End-to-End - SaveByte

## Pré-requisitos

1. **Banco de dados configurado**
   - Execute o script `database/schema.sql` no MySQL Workbench
   - Isso criará o banco `savebyte` com todas as tabelas

2. **Aplicação rodando**
   - Execute a classe `SaveByteApplication` no IntelliJ
   - Acesse http://localhost:8080

## Dados de Teste (criados automaticamente)

### Cliente
- **E-mail**: cliente@teste.com
- **Senha**: 123456

### Restaurantes
- **E-mail**: restaurante@teste.com
- **Senha**: 123456
- **Nome**: Padaria Pao Dourado

- **E-mail**: sabor@teste.com
- **Senha**: 123456
- **Nome**: Sabor & Cia Marmitaria

## Fluxo Completo de Teste

### Passo 1: Login como Cliente
1. Acesse http://localhost:8080/login
2. Selecione "CLIENTE"
3. E-mail: cliente@teste.com
4. Senha: 123456
5. Clique em "Entrar"

### Passo 2: Buscar Restaurantes/Produtos
1. Você será redirecionado para `/cliente/home`
2. Verá a lista de restaurantes com produtos e combos disponíveis
3. Pode usar a busca para filtrar por nome, cidade ou bairro

### Passo 3: Visualizar Restaurante Específico
1. Clique em qualquer restaurante da lista
2. Verá todos os produtos e combos daquele restaurante
3. Cada item mostra:
   - Nome e descrição
   - Preço original e preço com desconto
   - Quantidade disponível
   - Botão "Reservar"

### Passo 4: Fazer um Pedido (Reservar Produto)
1. Na página do restaurante, escolha um produto
2. Defina a quantidade (padrão: 1)
3. Clique em "Reservar"
4. **Você será levado à tela de checkout**

### Passo 4.1: Tela de Checkout — Entrega
1. **Retirar no local**: o pedido será retirado no restaurante (selecionado por padrão)
2. **Receber em casa / outro endereço**:
   - Selecione "Meu endereço" (usa o endereço cadastrado)
   - Ou "Outro endereço" e preencha rua, número, cidade etc.
   - A busca de CEP via ViaCEP preenche os campos automaticamente

### Passo 4.2: Tela de Checkout — Pagamento
1. **Pix** (padrão): exibe código Pix copia-e-cola simulado; pagamento considerado aprovado
2. **Cartão de crédito**: preencha número, nome, validade (MM/AA) e CVV; pagamento simulado
3. **Pagar na retirada/entrega**: pagamento fica pendente até o restaurante marcar como entregue

### Passo 4.3: Confirmar Pedido
1. Revise o resumo (item, quantidade, total, restaurante)
2. Opcionalmente adicione uma observação
3. Clique em "Confirmar pedido"
4. **Resultado**: Você será redirecionado para "Meus pedidos" com mensagem de sucesso

### Passo 5: Verificar Pedidos do Cliente
1. Acesse `/cliente/pedidos` (ou clique em "Meus pedidos" no menu)
2. Verá o pedido recém-criado com:
   - Número do pedido
   - Status (PENDENTE)
   - Nome do restaurante
   - Tipo de entrega (retirada ou entrega + endereço)
   - Forma de pagamento e status de pagamento
   - Data e hora
   - Itens reservados
   - Valor total
   - Botão "Cancelar" (se ainda estiver PENDENTE)

### Passo 6: Login como Restaurante
1. Faça logout: clique em "Sair" no menu
2. Acesse http://localhost:8080/login
3. Selecione "RESTAURANTE"
4. E-mail: restaurante@teste.com
5. Senha: 123456
6. Clique em "Entrar"

### Passo 7: Ver Dashboard do Restaurante
1. Você será redirecionado para `/restaurante/dashboard`
2. Verá:
   - Total de produtos cadastrados
   - Total de combos cadastrados
   - Total de pedidos recebidos
   - Pedidos pendentes
   - Últimos 5 pedidos

### Passo 8: Gerenciar Pedidos Recebidos
1. Clique em "Pedidos" no menu
2. Verá todos os pedidos recebidos
3. Para cada pedido, pode:
   - **Confirmar**: Muda status para CONFIRMADO
   - **Marcar como Entregue**: Muda status para ENTREGUE
   - **Cancelar**: Muda status para CANCELADO (devolve estoque)

### Passo 9: Confirmar o Pedido
1. No pedido que você acabou de criar
2. Clique em "Confirmar"
3. **Resultado**: Status muda para CONFIRMADO

### Passo 10: Marcar como Entregue
1. No mesmo pedido (agora CONFIRMADO)
2. Clique em "Entregue"
3. **Resultado**: Status muda para ENTREGUE

### Passo 11: Verificar Como Cliente
1. Faça logout e login novamente como cliente
2. Acesse "Meus pedidos"
3. Verá o pedido com status ENTREGUE
4. Não terá mais o botão "Cancelar"

## Teste de Cancelamento e Estorno

### Cancelar pedido pago (Pix ou Cartão)
1. Faça login como cliente
2. Crie um pedido com pagamento Pix ou Cartão
3. Em "Meus pedidos", clique em "Cancelar"
4. **Resultado**: Status muda para CANCELADO, estoque devolvido e pagamento marcado como ESTORNADO

### Cancelar pedido com pagamento na entrega
1. Crie um pedido com "Pagar na retirada/entrega"
2. Cancele pelo cliente ou restaurante
3. **Resultado**: Status muda para CANCELADO, estoque devolvido, pagamento continua PENDENTE

### Cancelar pelo Restaurante
1. Faça login como restaurante
2. Em "Pedidos", encontre um pedido PENDENTE ou CONFIRMADO
3. Clique em "Cancelar"
4. **Resultado**: Status muda para CANCELADO, estoque devolvido, estorno se já estava pago

### Entrega com pagamento pendente
1. Crie um pedido com "Pagar na entrega"
2. Como restaurante, confirme e marque como "Entregue"
3. **Resultado**: Status do pagamento muda automaticamente para PAGO

## Regras de Negócio Implementadas

1. **Estoque**
   - Ao reservar: estoque é baixado automaticamente
   - Ao cancelar: estoque é devolvido automaticamente
   - Não é possível reservar mais do que o estoque disponível

2. **Status do Pedido**
   - PENDENTE → pode ser cancelado ou confirmado
   - CONFIRMADO → pode ser marcado como entregue ou cancelado
   - ENTREGUE → não pode mais ser alterado
   - CANCELADO → não pode mais ser alterado

3. **Segurança**
   - Cliente só vê seus próprios pedidos
   - Restaurante só vê pedidos do seu estabelecimento
   - Cliente só pode cancelar seus próprios pedidos
   - Restaurante só pode alterar pedidos do seu estabelecimento

4. **Validações**
   - Quantidade deve ser maior que 0
   - Não é possível reservar produtos esgotados
   - Não é possível reservar combos esgotados
   - Usuário deve estar logado para fazer pedidos

5. **Entrega**
   - RETIRADA: cliente busca no restaurante
   - ENTREGA: usa endereço cadastrado ou outro endereço informado no checkout
   - Busca de CEP (ViaCEP) disponível para preencher endereço automaticamente

6. **Pagamento**
   - PIX: pagamento simulado, aprovado no momento do pedido
   - CARTAO: pagamento simulado, apenas os 4 últimos dígitos são salvos
   - NA_ENTREGA: status fica PENDENTE; muda para PAGO quando o restaurante marca o pedido como ENTREGUE
   - Ao cancelar pedido PAGO, status do pagamento muda para ESTORNADO

## Troubleshooting

### Erro: "Quantidade indisponível"
- O produto/combo não tem estoque suficiente
- Solução: Reserve uma quantidade menor ou aguarde reposição

### Erro: "Cliente não encontrado"
- Sessão expirou ou usuário não está logado
- Solução: Faça login novamente

### Erro: "Pedido não encontrado"
- O pedido foi deletado ou ID inválido
- Solução: Verifique se está acessando o pedido correto

### Produtos não aparecem
- Verifique se o restaurante tem produtos ativos
- Verifique se há estoque disponível (> 0)
- Verifique se o campo `ativo` está como `true`

## Estrutura de Dados

### Produtos Disponíveis (Padaria Pao Dourado)
- Saco de paes do dia (15 unidades) - R$ 4,99
- Fatia de bolo de cenoura (20 unidades) - R$ 3.50
- Misto quente (10 unidades) - R$ 5.00

### Combos Disponíveis (Padaria Pao Dourado)
- Caixa Surpresa da Padaria (8 unidades) - R$ 9.99
  - 1x Saco de paes do dia
  - 2x Fatia de bolo de cenoura
  - 1x Misto quente

### Produtos Disponíveis (Sabor & Cia Marmitaria)
- Marmita do dia (12 unidades) - R$ 12.00
- Salada completa (8 unidades) - R$ 9.00

### Combos Disponíveis (Sabor & Cia Marmitaria)
- Combo Jantar Surpresa (5 unidades) - R$ 15.99
  - 1x Marmita do dia
  - 1x Salada completa

## Melhorias Implementadas

1. ✅ Busca automática de CEP (ViaCEP)
2. ✅ Envio de e-mail de confirmação (Gmail)
3. ✅ Nome do aplicativo alterado para "SaveByte"
4. ✅ Fetch EAGER para evitar erros de lazy loading
5. ✅ Tratamento de erros em todas as operações
6. ✅ Validação de login antes de fazer pedidos
7. ✅ Tela de checkout com opções de entrega (retirada / entrega em casa / outro endereço)
8. ✅ Opções de pagamento (Pix, Cartão, Pagar na entrega)
9. ✅ Estorno automático ao cancelar pedido já pago
10. ✅ Pagamento automático ao entregar pedido com "pagar na entrega"
11. ✅ Exibição de entrega e pagamento nos pedidos do cliente e restaurante
