package br.com.usjt.foodsaver.model;

public enum StatusPedido {
    PENDENTE,
    CONFIRMADO,
    ENTREGUE,
    CANCELADO;

    public String getBadgeClass() {
        return switch (this) {
            case PENDENTE -> "text-bg-warning";
            case CONFIRMADO -> "text-bg-primary";
            case ENTREGUE -> "text-bg-success";
            case CANCELADO -> "text-bg-secondary";
        };
    }
}
