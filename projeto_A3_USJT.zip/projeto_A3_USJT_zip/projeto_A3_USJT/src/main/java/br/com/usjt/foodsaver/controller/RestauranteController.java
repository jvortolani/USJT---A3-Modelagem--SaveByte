package br.com.usjt.foodsaver.controller;

import br.com.usjt.foodsaver.model.*;
import br.com.usjt.foodsaver.repository.*;
import br.com.usjt.foodsaver.service.PedidoService;
import br.com.usjt.foodsaver.service.UploadService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/restaurante")
public class RestauranteController {

    private final RestauranteRepository restauranteRepository;
    private final ProdutoRepository produtoRepository;
    private final ComboRepository comboRepository;
    private final PedidoRepository pedidoRepository;
    private final PedidoService pedidoService;
    private final UploadService uploadService;
    private final BCryptPasswordEncoder encoder;

    public RestauranteController(RestauranteRepository restauranteRepository,
                                 ProdutoRepository produtoRepository,
                                 ComboRepository comboRepository,
                                 PedidoRepository pedidoRepository,
                                 PedidoService pedidoService,
                                 UploadService uploadService,
                                 BCryptPasswordEncoder encoder) {
        this.restauranteRepository = restauranteRepository;
        this.produtoRepository = produtoRepository;
        this.comboRepository = comboRepository;
        this.pedidoRepository = pedidoRepository;
        this.pedidoService = pedidoService;
        this.uploadService = uploadService;
        this.encoder = encoder;
    }

    private Long restauranteId(HttpSession session) {
        return (Long) session.getAttribute("restauranteId");
    }

    private Restaurante restaurante(HttpSession session) {
        return restauranteRepository.findById(restauranteId(session)).orElseThrow();
    }

    // ---------------- Dashboard ----------------

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Long id = restauranteId(session);
        model.addAttribute("restaurante", restauranteRepository.findById(id).orElseThrow());
        model.addAttribute("totalProdutos", produtoRepository.countByRestauranteId(id));
        model.addAttribute("totalCombos", comboRepository.countByRestauranteId(id));
        model.addAttribute("totalPedidos", pedidoRepository.countByRestauranteId(id));
        model.addAttribute("pedidosPendentes",
                pedidoRepository.countByRestauranteIdAndStatus(id, StatusPedido.PENDENTE));
        List<Pedido> pedidos = pedidoRepository.findByRestauranteIdOrderByDataPedidoDesc(id);
        model.addAttribute("ultimosPedidos", pedidos.stream().limit(5).toList());
        return "restaurante/dashboard";
    }

    // ---------------- Produtos ----------------

    @GetMapping("/produtos")
    public String produtos(HttpSession session, Model model) {
        model.addAttribute("produtos", produtoRepository.findByRestauranteId(restauranteId(session)));
        return "restaurante/produtos";
    }

    @GetMapping("/produtos/novo")
    public String novoProduto(Model model) {
        model.addAttribute("produto", new Produto());
        return "restaurante/produto-form";
    }

    @GetMapping("/produtos/{id}/editar")
    public String editarProduto(@PathVariable Long id, HttpSession session,
                                Model model, RedirectAttributes ra) {
        Produto produto = produtoRepository.findById(id).orElse(null);
        if (produto == null || !produto.getRestaurante().getId().equals(restauranteId(session))) {
            ra.addFlashAttribute("erro", "Produto não encontrado.");
            return "redirect:/restaurante/produtos";
        }
        model.addAttribute("produto", produto);
        return "restaurante/produto-form";
    }

    @PostMapping("/produtos/salvar")
    public String salvarProduto(@ModelAttribute Produto form,
                                @RequestParam(value = "imagem", required = false) MultipartFile imagem,
                                @RequestParam(value = "removerImagem", required = false) boolean removerImagem,
                                HttpSession session,
                                RedirectAttributes ra) {
        Restaurante r = restaurante(session);
        Produto produto;
        if (form.getId() != null) {
            produto = produtoRepository.findById(form.getId()).orElse(null);
            if (produto == null || !produto.getRestaurante().getId().equals(r.getId())) {
                ra.addFlashAttribute("erro", "Produto não encontrado.");
                return "redirect:/restaurante/produtos";
            }
            produto.setNome(form.getNome());
            produto.setDescricao(form.getDescricao());
            produto.setCategoria(form.getCategoria());
            produto.setPrecoOriginal(form.getPrecoOriginal());
            produto.setPrecoDesconto(form.getPrecoDesconto());
            produto.setQuantidade(form.getQuantidade());
        } else {
            produto = form;
            produto.setRestaurante(r);
            produto.setAtivo(true);
        }

        try {
            if (removerImagem) {
                uploadService.remover(produto.getImagemUrl());
                produto.setImagemUrl(null);
            }
            if (imagem != null && !imagem.isEmpty()) {
                uploadService.remover(produto.getImagemUrl());
                produto.setImagemUrl(uploadService.salvar(imagem, "produtos"));
            }
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("erro", e.getMessage());
            return produto.getId() != null
                    ? "redirect:/restaurante/produtos/" + produto.getId() + "/editar"
                    : "redirect:/restaurante/produtos/novo";
        } catch (IOException e) {
            ra.addFlashAttribute("erro", "Erro ao salvar imagem. Tente novamente.");
            return produto.getId() != null
                    ? "redirect:/restaurante/produtos/" + produto.getId() + "/editar"
                    : "redirect:/restaurante/produtos/novo";
        }

        produtoRepository.save(produto);
        ra.addFlashAttribute("sucesso", "Produto salvo com sucesso.");
        return "redirect:/restaurante/produtos";
    }

    @PostMapping("/produtos/{id}/alternar")
    public String alternarProduto(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        produtoRepository.findById(id).ifPresent(produto -> {
            if (produto.getRestaurante().getId().equals(restauranteId(session))) {
                produto.setAtivo(!produto.getAtivo());
                produtoRepository.save(produto);
                ra.addFlashAttribute("sucesso",
                        produto.getAtivo() ? "Produto ativado." : "Produto desativado.");
            }
        });
        return "redirect:/restaurante/produtos";
    }

    // ---------------- Combos ----------------

    @GetMapping("/combos")
    public String combos(HttpSession session, Model model) {
        model.addAttribute("combos", comboRepository.findByRestauranteId(restauranteId(session)));
        return "restaurante/combos";
    }

    @GetMapping("/combos/novo")
    public String novoCombo(HttpSession session, Model model) {
        model.addAttribute("combo", new Combo());
        model.addAttribute("produtos",
                produtoRepository.findByRestauranteId(restauranteId(session)));
        model.addAttribute("selecionados", new HashMap<Long, Integer>());
        return "restaurante/combo-form";
    }

    @GetMapping("/combos/{id}/editar")
    public String editarCombo(@PathVariable Long id, HttpSession session,
                              Model model, RedirectAttributes ra) {
        Long restauranteId = restauranteId(session);
        Combo combo = comboRepository.findById(id).orElse(null);
        if (combo == null || !combo.getRestaurante().getId().equals(restauranteId)) {
            ra.addFlashAttribute("erro", "Combo não encontrado.");
            return "redirect:/restaurante/combos";
        }
        Map<Long, Integer> selecionados = new HashMap<>();
        for (ComboItem item : combo.getItens()) {
            selecionados.put(item.getProduto().getId(), item.getQuantidade());
        }
        model.addAttribute("combo", combo);
        model.addAttribute("produtos", produtoRepository.findByRestauranteId(restauranteId));
        model.addAttribute("selecionados", selecionados);
        return "restaurante/combo-form";
    }

    @PostMapping("/combos/salvar")
    public String salvarCombo(@ModelAttribute Combo form,
                              @RequestParam Map<String, String> params,
                              HttpSession session,
                              RedirectAttributes ra) {
        Restaurante r = restaurante(session);
        Combo combo;
        if (form.getId() != null) {
            combo = comboRepository.findById(form.getId()).orElse(null);
            if (combo == null || !combo.getRestaurante().getId().equals(r.getId())) {
                ra.addFlashAttribute("erro", "Combo não encontrado.");
                return "redirect:/restaurante/combos";
            }
            combo.setNome(form.getNome());
            combo.setDescricao(form.getDescricao());
            combo.setPreco(form.getPreco());
            combo.setQuantidade(form.getQuantidade());
            combo.setImagemUrl(form.getImagemUrl());
            combo.getItens().clear();
        } else {
            combo = form;
            combo.setRestaurante(r);
            combo.setAtivo(true);
        }

        for (String key : params.keySet()) {
            if (key.startsWith("prod_")) {
                Long produtoId = Long.valueOf(key.substring(5));
                Produto produto = produtoRepository.findById(produtoId).orElse(null);
                if (produto == null || !produto.getRestaurante().getId().equals(r.getId())) {
                    continue;
                }
                int qtd = 1;
                String qtdParam = params.get("qtd_" + produtoId);
                if (qtdParam != null && !qtdParam.isBlank()) {
                    qtd = Integer.parseInt(qtdParam);
                }
                ComboItem item = new ComboItem();
                item.setCombo(combo);
                item.setProduto(produto);
                item.setQuantidade(Math.max(qtd, 1));
                combo.getItens().add(item);
            }
        }

        if (combo.getItens().isEmpty()) {
            ra.addFlashAttribute("erro", "Selecione ao menos um produto para o combo.");
            return form.getId() != null
                    ? "redirect:/restaurante/combos/" + form.getId() + "/editar"
                    : "redirect:/restaurante/combos/novo";
        }

        comboRepository.save(combo);
        ra.addFlashAttribute("sucesso", "Combo salvo com sucesso.");
        return "redirect:/restaurante/combos";
    }

    @PostMapping("/combos/{id}/alternar")
    public String alternarCombo(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        comboRepository.findById(id).ifPresent(combo -> {
            if (combo.getRestaurante().getId().equals(restauranteId(session))) {
                combo.setAtivo(!combo.getAtivo());
                comboRepository.save(combo);
                ra.addFlashAttribute("sucesso",
                        combo.getAtivo() ? "Combo ativado." : "Combo desativado.");
            }
        });
        return "redirect:/restaurante/combos";
    }

    // ---------------- Pedidos recebidos ----------------

    @GetMapping("/pedidos")
    public String pedidos(HttpSession session, Model model) {
        model.addAttribute("pedidos",
                pedidoRepository.findByRestauranteIdOrderByDataPedidoDesc(restauranteId(session)));
        return "restaurante/pedidos";
    }

    @PostMapping("/pedidos/{id}/status")
    public String alterarStatus(@PathVariable Long id,
                                @RequestParam StatusPedido status,
                                HttpSession session,
                                RedirectAttributes ra) {
        Pedido pedido = pedidoRepository.findById(id).orElse(null);
        if (pedido == null || !pedido.getRestaurante().getId().equals(restauranteId(session))) {
            ra.addFlashAttribute("erro", "Pedido não encontrado.");
            return "redirect:/restaurante/pedidos";
        }
        try {
            pedidoService.alterarStatus(id, status);
            ra.addFlashAttribute("sucesso", "Pedido #" + id + " atualizado para " + status + ".");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/restaurante/pedidos";
    }

    // ---------------- Perfil ----------------

    @GetMapping("/perfil")
    public String perfil(HttpSession session, Model model) {
        model.addAttribute("restaurante", restaurante(session));
        return "restaurante/perfil";
    }

    @PostMapping("/perfil/dados")
    public String salvarDados(@RequestParam String nome,
                              @RequestParam(required = false) String cnpj,
                              @RequestParam(required = false) String telefone,
                              @RequestParam(required = false) String descricao,
                              @RequestParam(required = false) String cep,
                              @RequestParam(required = false) String endereco,
                              @RequestParam(required = false) String numero,
                              @RequestParam(required = false) String complemento,
                              @RequestParam(required = false) String bairro,
                              @RequestParam(required = false) String cidade,
                              @RequestParam(required = false) String estado,
                              HttpSession session, RedirectAttributes ra) {
        Restaurante r = restaurante(session);
        r.setNome(nome.trim());
        r.setCnpj(vazio(cnpj) ? null : cnpj.trim());
        r.setTelefone(vazio(telefone) ? null : telefone.trim());
        r.setDescricao(vazio(descricao) ? null : descricao.trim());
        r.setCep(vazio(cep) ? null : cep.trim());
        r.setEndereco(vazio(endereco) ? null : endereco.trim());
        r.setNumero(vazio(numero) ? null : numero.trim());
        r.setComplemento(vazio(complemento) ? null : complemento.trim());
        r.setBairro(vazio(bairro) ? null : bairro.trim());
        r.setCidade(vazio(cidade) ? null : cidade.trim());
        r.setEstado(vazio(estado) ? null : estado.trim());
        restauranteRepository.save(r);
        session.setAttribute("usuarioNome", r.getNome());
        ra.addFlashAttribute("sucesso", "Dados atualizados com sucesso!");
        return "redirect:/restaurante/perfil";
    }

    @PostMapping("/perfil/foto")
    public String salvarFoto(@RequestParam(required = false) MultipartFile foto,
                             @RequestParam(required = false) String removerFoto,
                             HttpSession session, RedirectAttributes ra) {
        Restaurante r = restaurante(session);
        try {
            if ("true".equals(removerFoto)) {
                uploadService.remover(r.getImagemUrl());
                r.setImagemUrl(null);
            } else if (foto != null && !foto.isEmpty()) {
                uploadService.remover(r.getImagemUrl());
                r.setImagemUrl(uploadService.salvar(foto, "perfis"));
            }
            restauranteRepository.save(r);
            session.setAttribute("usuarioFoto", r.getImagemUrl());
            ra.addFlashAttribute("sucesso", "Foto atualizada!");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Erro ao salvar foto: " + e.getMessage());
        }
        return "redirect:/restaurante/perfil";
    }

    @PostMapping("/perfil/senha")
    public String alterarSenha(@RequestParam String senhaAtual,
                               @RequestParam String novaSenha,
                               @RequestParam String confirmarSenha,
                               HttpSession session, RedirectAttributes ra) {
        Restaurante r = restaurante(session);
        if (!encoder.matches(senhaAtual, r.getSenha())) {
            ra.addFlashAttribute("erro", "Senha atual incorreta.");
            return "redirect:/restaurante/perfil";
        }
        if (novaSenha.length() < 6) {
            ra.addFlashAttribute("erro", "A nova senha deve ter pelo menos 6 caracteres.");
            return "redirect:/restaurante/perfil";
        }
        if (!novaSenha.equals(confirmarSenha)) {
            ra.addFlashAttribute("erro", "A nova senha e a confirmação não conferem.");
            return "redirect:/restaurante/perfil";
        }
        r.setSenha(encoder.encode(novaSenha));
        restauranteRepository.save(r);
        ra.addFlashAttribute("sucesso", "Senha alterada com sucesso!");
        return "redirect:/restaurante/perfil";
    }

    private static boolean vazio(String s) {
        return s == null || s.isBlank();
    }
}
