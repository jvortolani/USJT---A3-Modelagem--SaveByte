package br.com.usjt.foodsaver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveByteApplication {

    public static void main(String[] args) {
        SpringApplication.run(SaveByteApplication.class, args);
    }
}
