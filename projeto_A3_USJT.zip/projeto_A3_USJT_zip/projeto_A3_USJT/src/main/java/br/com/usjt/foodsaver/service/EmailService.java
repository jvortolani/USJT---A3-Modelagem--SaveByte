package br.com.usjt.foodsaver.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void enviarEmailConfirmacao(String destinatario, String nome) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(destinatario);
        message.setSubject("Bem-vindo ao SaveByte!");
        message.setText("Olá " + nome + ",\n\n" +
                "Seu cadastro no SaveByte foi realizado com sucesso!\n\n" +
                "Agora você pode aproveitar pratos frescos com preços especiais pertinho de você.\n\n" +
                "Acesse: http://localhost:8080/login\n\n" +
                "Equipe SaveByte");
        message.setFrom("SaveByte <noreply@savebyte.com>");

        mailSender.send(message);
    }
}
