package br.com.usjt.foodsaver.repository;

import br.com.usjt.foodsaver.model.Combo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComboRepository extends JpaRepository<Combo, Long> {

    List<Combo> findByRestauranteId(Long restauranteId);

    List<Combo> findByRestauranteIdAndAtivoTrue(Long restauranteId);

    List<Combo> findByAtivoTrueAndQuantidadeGreaterThan(int quantidade);

    List<Combo> findByAtivoTrueAndNomeContainingIgnoreCase(String nome);

    long countByRestauranteId(Long restauranteId);
}
