package br.com.usjt.foodsaver.controller;

import br.com.usjt.foodsaver.model.Cliente;
import br.com.usjt.foodsaver.model.Restaurante;
import br.com.usjt.foodsaver.repository.ClienteRepository;
import br.com.usjt.foodsaver.repository.RestauranteRepository;
import br.com.usjt.foodsaver.service.CepService;
import br.com.usjt.foodsaver.service.EmailService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final ClienteRepository clienteRepository;
    private final RestauranteRepository restauranteRepository;
    private final BCryptPasswordEncoder encoder;
    private final CepService cepService;
    private final EmailService emailService;

    public AuthController(ClienteRepository clienteRepository,
                          RestauranteRepository restauranteRepository,
                          BCryptPasswordEncoder encoder,
                          CepService cepService,
                          EmailService emailService) {
        this.clienteRepository = clienteRepository;
        this.restauranteRepository = restauranteRepository;
        this.encoder = encoder;
        this.cepService = cepService;
        this.emailService = emailService;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String autenticar(@RequestParam String email,
                             @RequestParam String senha,
                             @RequestParam String tipo,
                             HttpSession session,
                             RedirectAttributes ra) {
        if ("CLIENTE".equals(tipo)) {
            return clienteRepository.findByEmail(email)
                    .filter(c -> encoder.matches(senha, c.getSenha()))
                    .map(c -> {
                        session.setAttribute("clienteId", c.getId());
                        session.setAttribute("tipo", "CLIENTE");
                        session.setAttribute("usuarioNome", c.getNome());
                        session.setAttribute("usuarioFoto", c.getImagemUrl());
                        return "redirect:/cliente/home";
                    })
                    .orElseGet(() -> falhaLogin(ra));
        }

        return restauranteRepository.findByEmail(email)
                .filter(r -> encoder.matches(senha, r.getSenha()))
                .map(r -> {
                    session.setAttribute("restauranteId", r.getId());
                    session.setAttribute("tipo", "RESTAURANTE");
                    session.setAttribute("usuarioNome", r.getNome());
                    session.setAttribute("usuarioFoto", r.getImagemUrl());
                    return "redirect:/restaurante/dashboard";
                })
                .orElseGet(() -> falhaLogin(ra));
    }

    private String falhaLogin(RedirectAttributes ra) {
        ra.addFlashAttribute("erro", "E-mail ou senha inválidos.");
        return "redirect:/login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    // ---------------- Cadastro de cliente ----------------

    @GetMapping("/cadastro/cliente")
    public String formCliente(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "cadastro-cliente";
    }

    @PostMapping("/cadastro/cliente")
    public String cadastrarCliente(@ModelAttribute Cliente cliente, RedirectAttributes ra) {
        if (emailEmUso(cliente.getEmail())) {
            ra.addFlashAttribute("erro", "Este e-mail ja esta cadastrado.");
            return "redirect:/cadastro/cliente";
        }
        cliente.setId(null);
        cliente.setSenha(encoder.encode(cliente.getSenha()));
        clienteRepository.save(cliente);

        try {
            emailService.enviarEmailConfirmacao(cliente.getEmail(), cliente.getNome());
            ra.addFlashAttribute("sucesso", "Cadastro realizado! Enviamos um e-mail de confirmação para " + cliente.getEmail());
        } catch (Exception e) {
            ra.addFlashAttribute("sucesso", "Cadastro realizado! (E-mail de confirmação não enviado - configure as credenciais no application.properties)");
        }

        return "redirect:/login";
    }

    @GetMapping("/api/cep/{cep}")
    @ResponseBody
    public CepService.EnderecoViaCep buscarCep(@PathVariable String cep) {
        return cepService.buscarEndereco(cep);
    }

    // ---------------- Cadastro de restaurante ----------------

    @GetMapping("/cadastro/restaurante")
    public String formRestaurante(Model model) {
        model.addAttribute("restaurante", new Restaurante());
        return "cadastro-restaurante";
    }

    @PostMapping("/cadastro/restaurante")
    public String cadastrarRestaurante(@ModelAttribute Restaurante restaurante, RedirectAttributes ra) {
        if (emailEmUso(restaurante.getEmail())) {
            ra.addFlashAttribute("erro", "Este e-mail ja esta cadastrado.");
            return "redirect:/cadastro/restaurante";
        }
        restaurante.setId(null);
        restaurante.setSenha(encoder.encode(restaurante.getSenha()));
        restauranteRepository.save(restaurante);
        ra.addFlashAttribute("sucesso", "Restaurante cadastrado! Faça login para continuar.");
        return "redirect:/login";
    }

    private boolean emailEmUso(String email) {
        return clienteRepository.existsByEmail(email) || restauranteRepository.existsByEmail(email);
    }
}
