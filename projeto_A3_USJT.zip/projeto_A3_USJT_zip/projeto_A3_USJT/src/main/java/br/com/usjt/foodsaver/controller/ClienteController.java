package br.com.usjt.foodsaver.controller;

import br.com.usjt.foodsaver.model.*;
import br.com.usjt.foodsaver.repository.*;
import br.com.usjt.foodsaver.service.DadosCheckout;
import br.com.usjt.foodsaver.service.PedidoService;
import br.com.usjt.foodsaver.service.UploadService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

    private final RestauranteRepository restauranteRepository;
    private final ProdutoRepository produtoRepository;
    private final ComboRepository comboRepository;
    private final PedidoRepository pedidoRepository;
    private final ClienteRepository clienteRepository;
    private final PedidoService pedidoService;
    private final UploadService uploadService;
    private final BCryptPasswordEncoder encoder;

    public ClienteController(RestauranteRepository restauranteRepository,
                             ProdutoRepository produtoRepository,
                             ComboRepository comboRepository,
                             PedidoRepository pedidoRepository,
                             ClienteRepository clienteRepository,
                             PedidoService pedidoService,
                             UploadService uploadService,
                             BCryptPasswordEncoder encoder) {
        this.restauranteRepository = restauranteRepository;
        this.produtoRepository = produtoRepository;
        this.comboRepository = comboRepository;
        this.pedidoRepository = pedidoRepository;
        this.clienteRepository = clienteRepository;
        this.pedidoService = pedidoService;
        this.uploadService = uploadService;
        this.encoder = encoder;
    }

    @GetMapping("/home")
    public String home(@RequestParam(required = false) String q, Model model) {
        boolean busca = q != null && !q.isBlank();
        if (busca) {
            model.addAttribute("restaurantes",
                    restauranteRepository.findByNomeContainingIgnoreCaseOrCidadeContainingIgnoreCaseOrBairroContainingIgnoreCase(q, q, q));
            model.addAttribute("produtos",
                    produtoRepository.findByAtivoTrueAndNomeContainingIgnoreCaseOrAtivoTrueAndDescricaoContainingIgnoreCase(q, q));
            model.addAttribute("combos",
                    comboRepository.findByAtivoTrueAndNomeContainingIgnoreCase(q));
            model.addAttribute("q", q);
        } else {
            model.addAttribute("restaurantes", restauranteRepository.findAll());
            model.addAttribute("produtos", produtoRepository.findByAtivoTrueAndQuantidadeGreaterThan(0));
            model.addAttribute("combos", comboRepository.findByAtivoTrueAndQuantidadeGreaterThan(0));
        }
        model.addAttribute("busca", busca);
        return "cliente/home";
    }

    @GetMapping("/restaurante/{id}")
    public String restaurante(@PathVariable Long id, Model model, RedirectAttributes ra) {
        Restaurante restaurante = restauranteRepository.findById(id).orElse(null);
        if (restaurante == null) {
            ra.addFlashAttribute("erro", "Restaurante não encontrado.");
            return "redirect:/cliente/home";
        }
        model.addAttribute("restaurante", restaurante);
        model.addAttribute("produtos", produtoRepository.findByRestauranteIdAndAtivoTrue(id));
        model.addAttribute("combos", comboRepository.findByRestauranteIdAndAtivoTrue(id));
        return "cliente/restaurante";
    }

    // ---------------- Checkout (entrega + pagamento) ----------------

    @GetMapping("/checkout")
    public String checkout(HttpSession session, Model model, RedirectAttributes ra) {
        Carrinho carrinho = (Carrinho) session.getAttribute("carrinho");
        if (carrinho == null || carrinho.isEmpty()) {
            ra.addFlashAttribute("erro", "Seu carrinho está vazio.");
            return "redirect:/cliente/home";
        }

        // Carregar restaurantes para exibir endereço na opção de retirada
        List<Restaurante> restaurantes = new ArrayList<>();
        for (Long rid : carrinho.getRestauranteIds()) {
            restauranteRepository.findById(rid).ifPresent(restaurantes::add);
        }
        if (restaurantes.isEmpty()) {
            ra.addFlashAttribute("erro", "Restaurante não encontrado.");
            return "redirect:/cliente/home";
        }

        Cliente cliente = clienteRepository.findById((Long) session.getAttribute("clienteId")).orElseThrow();
        model.addAttribute("carrinho", carrinho);
        model.addAttribute("total", carrinho.getTotal());
        model.addAttribute("restaurante", restaurantes.get(0));       // para compatibilidade no template
        model.addAttribute("restaurantes", restaurantes);
        model.addAttribute("cliente", cliente);
        return "cliente/checkout";
    }

    @PostMapping("/pedido")
    public String reservar(@RequestParam(required = false) String observacao,
                           @RequestParam(required = false) TipoEntrega tipoEntrega,
                           @RequestParam(defaultValue = "CASA") String destino,
                           @RequestParam(required = false) String entregaCep,
                           @RequestParam(required = false) String entregaEndereco,
                           @RequestParam(required = false) String entregaNumero,
                           @RequestParam(required = false) String entregaComplemento,
                           @RequestParam(required = false) String entregaBairro,
                           @RequestParam(required = false) String entregaCidade,
                           @RequestParam(required = false) String entregaEstado,
                           @RequestParam(required = false) FormaPagamento formaPagamento,
                           @RequestParam(required = false) String cartaoNumero,
                           @RequestParam(required = false) String cartaoValidade,
                           @RequestParam(required = false) String cartaoCvv,
                           @RequestParam(required = false) BigDecimal valorDinheiro,
                           HttpSession session,
                           RedirectAttributes ra) {
        Long clienteId = (Long) session.getAttribute("clienteId");
        Carrinho carrinho = (Carrinho) session.getAttribute("carrinho");
        if (carrinho == null || carrinho.isEmpty()) {
            ra.addFlashAttribute("erro", "Seu carrinho está vazio.");
            return "redirect:/cliente/home";
        }

        try {
            String enderecoEntrega = null;
            if (tipoEntrega == TipoEntrega.ENTREGA) {
                if ("OUTRO".equals(destino)) {
                    if (vazio(entregaEndereco) || vazio(entregaNumero) || vazio(entregaCidade)) {
                        throw new IllegalArgumentException("Preencha rua, número e cidade do endereço de entrega.");
                    }
                    enderecoEntrega = montarEndereco(entregaEndereco, entregaNumero, entregaComplemento,
                            entregaBairro, entregaCidade, entregaEstado, entregaCep);
                } else {
                    Cliente cliente = clienteRepository.findById(clienteId).orElseThrow();
                    if (!cliente.isPossuiEndereco()) {
                        throw new IllegalArgumentException(
                                "Seu cadastro não possui endereço completo. Escolha \"Outro endereço\".");
                    }
                    enderecoEntrega = cliente.getEnderecoCompleto();
                }
            }

            DadosCheckout checkout = new DadosCheckout(tipoEntrega, enderecoEntrega, formaPagamento,
                    cartaoNumero, cartaoValidade, cartaoCvv, valorDinheiro);

            // Criar um pedido por restaurante
            Map<Long, List<ItemCarrinho>> porRestaurante = carrinho.getItensPorRestaurante();
            List<Pedido> pedidos = new ArrayList<>();
            for (List<ItemCarrinho> itensRest : porRestaurante.values()) {
                Pedido pedido = pedidoService.criarDoCarrinhoItens(clienteId, itensRest, observacao, checkout);
                pedidos.add(pedido);
            }

            // Limpar o carrinho após criar os pedidos
            carrinho.limpar();

            StringBuilder msg = new StringBuilder();
            if (pedidos.size() == 1) {
                Pedido p = pedidos.get(0);
                msg.append("Pedido #").append(p.getId()).append(" realizado! ");
                msg.append(p.getStatusPagamento() == StatusPagamento.PAGO
                        ? "Pagamento via " + p.getFormaPagamento().getDescricao() + " aprovado. "
                        : "Pagamento será feito na " + (p.isEntrega() ? "entrega. " : "retirada. "));
                msg.append(p.isEntrega()
                        ? "Entrega em: " + p.getEnderecoEntrega()
                        : "Retire no restaurante.");
            } else {
                msg.append(pedidos.size()).append(" pedidos realizados! (");
                for (int i = 0; i < pedidos.size(); i++) {
                    if (i > 0) msg.append(", ");
                    msg.append("#").append(pedidos.get(i).getId());
                }
                msg.append(")");
            }
            ra.addFlashAttribute("sucesso", msg.toString());
            return "redirect:/cliente/pedidos";
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("erro", e.getMessage());
            return "redirect:/cliente/checkout";
        }
    }

    private static boolean vazio(String s) {
        return s == null || s.isBlank();
    }

    private static String montarEndereco(String rua, String numero, String complemento, String bairro,
                                         String cidade, String estado, String cep) {
        StringBuilder sb = new StringBuilder(rua.trim()).append(", ").append(numero.trim());
        if (!vazio(complemento)) sb.append(" (").append(complemento.trim()).append(")");
        if (!vazio(bairro)) sb.append(" - ").append(bairro.trim());
        sb.append(", ").append(cidade.trim());
        if (!vazio(estado)) sb.append("/").append(estado.trim());
        if (!vazio(cep)) sb.append(" - CEP ").append(cep.trim());
        return sb.toString();
    }

    @PostMapping("/pedido/{id}/cancelar")
    public String cancelar(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        Long clienteId = (Long) session.getAttribute("clienteId");
        pedidoRepository.findById(id).ifPresentOrElse(pedido -> {
            if (!pedido.getCliente().getId().equals(clienteId)) {
                ra.addFlashAttribute("erro", "Pedido inválido.");
            } else if (pedido.getStatus() != StatusPedido.PENDENTE) {
                ra.addFlashAttribute("erro", "Só é possível cancelar pedidos pendentes.");
            } else {
                boolean estavaPago = pedido.getStatusPagamento() == StatusPagamento.PAGO;
                pedidoService.alterarStatus(id, StatusPedido.CANCELADO);
                ra.addFlashAttribute("sucesso", estavaPago
                        ? "Pedido cancelado. O valor pago será estornado."
                        : "Pedido cancelado.");
            }
        }, () -> ra.addFlashAttribute("erro", "Pedido não encontrado."));
        return "redirect:/cliente/pedidos";
    }

    @GetMapping("/pedidos")
    public String pedidos(HttpSession session, Model model) {
        Long clienteId = (Long) session.getAttribute("clienteId");
        model.addAttribute("pedidos", pedidoRepository.findByClienteIdOrderByDataPedidoDesc(clienteId));
        return "cliente/pedidos";
    }

    // ---------------- Perfil ----------------

    @GetMapping("/perfil")
    public String perfil(HttpSession session, Model model) {
        Cliente cliente = clienteRepository.findById((Long) session.getAttribute("clienteId")).orElseThrow();
        model.addAttribute("cliente", cliente);
        return "cliente/perfil";
    }

    @PostMapping("/perfil/dados")
    public String salvarDados(@RequestParam String nome,
                              @RequestParam(required = false) String telefone,
                              @RequestParam(required = false) String cep,
                              @RequestParam(required = false) String endereco,
                              @RequestParam(required = false) String bairro,
                              @RequestParam(required = false) String cidade,
                              @RequestParam(required = false) String estado,
                              HttpSession session, RedirectAttributes ra) {
        Cliente cliente = clienteRepository.findById((Long) session.getAttribute("clienteId")).orElseThrow();
        cliente.setNome(nome.trim());
        cliente.setTelefone(vazio(telefone) ? null : telefone.trim());
        cliente.setCep(vazio(cep) ? null : cep.trim());
        cliente.setEndereco(vazio(endereco) ? null : endereco.trim());
        cliente.setBairro(vazio(bairro) ? null : bairro.trim());
        cliente.setCidade(vazio(cidade) ? null : cidade.trim());
        cliente.setEstado(vazio(estado) ? null : estado.trim());
        clienteRepository.save(cliente);
        session.setAttribute("usuarioNome", cliente.getNome());
        ra.addFlashAttribute("sucesso", "Dados atualizados com sucesso!");
        return "redirect:/cliente/perfil";
    }

    @PostMapping("/perfil/foto")
    public String salvarFoto(@RequestParam(required = false) MultipartFile foto,
                             @RequestParam(required = false) String removerFoto,
                             HttpSession session, RedirectAttributes ra) {
        Cliente cliente = clienteRepository.findById((Long) session.getAttribute("clienteId")).orElseThrow();
        try {
            if ("true".equals(removerFoto)) {
                uploadService.remover(cliente.getImagemUrl());
                cliente.setImagemUrl(null);
            } else if (foto != null && !foto.isEmpty()) {
                uploadService.remover(cliente.getImagemUrl());
                String url = uploadService.salvar(foto, "perfis");
                cliente.setImagemUrl(url);
            }
            clienteRepository.save(cliente);
            session.setAttribute("usuarioFoto", cliente.getImagemUrl());
            ra.addFlashAttribute("sucesso", "Foto atualizada!");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Erro ao salvar foto: " + e.getMessage());
        }
        return "redirect:/cliente/perfil";
    }

    @PostMapping("/perfil/senha")
    public String alterarSenha(@RequestParam String senhaAtual,
                               @RequestParam String novaSenha,
                               @RequestParam String confirmarSenha,
                               HttpSession session, RedirectAttributes ra) {
        Cliente cliente = clienteRepository.findById((Long) session.getAttribute("clienteId")).orElseThrow();
        if (!encoder.matches(senhaAtual, cliente.getSenha())) {
            ra.addFlashAttribute("erro", "Senha atual incorreta.");
            return "redirect:/cliente/perfil";
        }
        if (novaSenha.length() < 6) {
            ra.addFlashAttribute("erro", "A nova senha deve ter pelo menos 6 caracteres.");
            return "redirect:/cliente/perfil";
        }
        if (!novaSenha.equals(confirmarSenha)) {
            ra.addFlashAttribute("erro", "A nova senha e a confirmação não conferem.");
            return "redirect:/cliente/perfil";
        }
        cliente.setSenha(encoder.encode(novaSenha));
        clienteRepository.save(cliente);
        ra.addFlashAttribute("sucesso", "Senha alterada com sucesso!");
        return "redirect:/cliente/perfil";
    }
}
