package br.com.usjt.foodsaver.config;

import br.com.usjt.foodsaver.model.*;
import br.com.usjt.foodsaver.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Insere dados de demonstracao na primeira execucao (banco vazio),
 * para facilitar os testes e a apresentacao do projeto.
 *
 *   Cliente:     cliente@teste.com     / 123456
 *   Restaurante: restaurante@teste.com / 123456
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final ClienteRepository clienteRepository;
    private final RestauranteRepository restauranteRepository;
    private final ProdutoRepository produtoRepository;
    private final ComboRepository comboRepository;
    private final BCryptPasswordEncoder encoder;

    public DataInitializer(ClienteRepository clienteRepository,
                           RestauranteRepository restauranteRepository,
                           ProdutoRepository produtoRepository,
                           ComboRepository comboRepository,
                           BCryptPasswordEncoder encoder) {
        this.clienteRepository = clienteRepository;
        this.restauranteRepository = restauranteRepository;
        this.produtoRepository = produtoRepository;
        this.comboRepository = comboRepository;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        if (clienteRepository.count() > 0) {
            return;
        }

        Cliente cliente = new Cliente();
        cliente.setNome("Cliente Teste");
        cliente.setEmail("cliente@teste.com");
        cliente.setSenha(encoder.encode("123456"));
        cliente.setTelefone("(11) 99999-0000");
        cliente.setEndereco("Rua das Flores, 100");
        cliente.setBairro("Centro");
        cliente.setCidade("Sao Paulo");
        cliente.setEstado("SP");
        cliente.setCep("01000-000");
        clienteRepository.save(cliente);

        Restaurante padaria = new Restaurante();
        padaria.setNome("Padaria Pao Dourado");
        padaria.setCnpj("12.345.678/0001-90");
        padaria.setEmail("restaurante@teste.com");
        padaria.setSenha(encoder.encode("123456"));
        padaria.setTelefone("(11) 3333-1111");
        padaria.setEndereco("Av. Paulista");
        padaria.setNumero("1000");
        padaria.setBairro("Bela Vista");
        padaria.setCidade("Sao Paulo");
        padaria.setEstado("SP");
        padaria.setCep("01310-100");
        padaria.setDescricao("Padaria artesanal que vende os produtos do dia com desconto no fim da tarde.");
        restauranteRepository.save(padaria);

        Restaurante marmitaria = new Restaurante();
        marmitaria.setNome("Sabor & Cia Marmitaria");
        marmitaria.setCnpj("98.765.432/0001-10");
        marmitaria.setEmail("sabor@teste.com");
        marmitaria.setSenha(encoder.encode("123456"));
        marmitaria.setTelefone("(11) 3333-2222");
        marmitaria.setEndereco("Rua Augusta");
        marmitaria.setNumero("2500");
        marmitaria.setBairro("Consolacao");
        marmitaria.setCidade("Sao Paulo");
        marmitaria.setEstado("SP");
        marmitaria.setCep("01412-000");
        marmitaria.setDescricao("Marmitas caseiras com precos especiais no periodo noturno. Refeicao de qualidade por menos!");
        restauranteRepository.save(marmitaria);

        Produto pao = produto(padaria, "Saco de paes do dia", "10 paes franceses assados hoje",
                "Padaria", "12.00", "4.99", 15);
        Produto bolo = produto(padaria, "Fatia de bolo de cenoura", "Bolo caseiro com cobertura de chocolate",
                "Sobremesa", "8.00", "3.50", 20);
        Produto misto = produto(padaria, "Misto quente", "Pao, queijo e presunto na chapa",
                "Lanche", "10.00", "5.00", 10);
        Produto marmita = produto(marmitaria, "Marmita do dia", "Arroz, feijao, salada e carne",
                "Marmita", "22.00", "12.00", 12);
        Produto salada = produto(marmitaria, "Salada completa", "Mix de folhas, legumes e frango grelhado",
                "Marmita", "18.00", "9.00", 8);
        produtoRepository.save(pao);
        produtoRepository.save(bolo);
        produtoRepository.save(misto);
        produtoRepository.save(marmita);
        produtoRepository.save(salada);

        Combo caixaPadaria = new Combo();
        caixaPadaria.setRestaurante(padaria);
        caixaPadaria.setNome("Caixa Surpresa da Padaria");
        caixaPadaria.setDescricao("Uma caixa com produtos do dia: paes, bolo e lanche. O conteudo pode variar!");
        caixaPadaria.setPreco(new BigDecimal("9.99"));
        caixaPadaria.setQuantidade(8);
        caixaPadaria.getItens().add(item(caixaPadaria, pao, 1));
        caixaPadaria.getItens().add(item(caixaPadaria, bolo, 2));
        caixaPadaria.getItens().add(item(caixaPadaria, misto, 1));
        comboRepository.save(caixaPadaria);

        Combo caixaMarmita = new Combo();
        caixaMarmita.setRestaurante(marmitaria);
        caixaMarmita.setNome("Combo Jantar Surpresa");
        caixaMarmita.setDescricao("Duas marmitas ou saladas do dia com preco especial. Aproveite!");
        caixaMarmita.setPreco(new BigDecimal("15.99"));
        caixaMarmita.setQuantidade(5);
        caixaMarmita.getItens().add(item(caixaMarmita, marmita, 1));
        caixaMarmita.getItens().add(item(caixaMarmita, salada, 1));
        comboRepository.save(caixaMarmita);
    }

    private Produto produto(Restaurante r, String nome, String descricao, String categoria,
                            String precoOriginal, String precoDesconto, int quantidade) {
        Produto p = new Produto();
        p.setRestaurante(r);
        p.setNome(nome);
        p.setDescricao(descricao);
        p.setCategoria(categoria);
        p.setPrecoOriginal(new BigDecimal(precoOriginal));
        p.setPrecoDesconto(new BigDecimal(precoDesconto));
        p.setQuantidade(quantidade);
        p.setAtivo(true);
        return p;
    }

    private ComboItem item(Combo combo, Produto produto, int quantidade) {
        ComboItem item = new ComboItem();
        item.setCombo(combo);
        item.setProduto(produto);
        item.setQuantidade(quantidade);
        return item;
    }
}
