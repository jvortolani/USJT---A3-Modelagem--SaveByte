package br.com.usjt.foodsaver.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Carrinho de compras armazenado na sessão HTTP.
 * Aceita itens de restaurantes diferentes.
 */
public class Carrinho implements Serializable {

    private final LinkedHashMap<String, ItemCarrinho> itens = new LinkedHashMap<>();

    public void adicionar(ItemCarrinho item) {
        String chave = item.getChave();
        if (itens.containsKey(chave)) {
            ItemCarrinho existente = itens.get(chave);
            int novaQtd = existente.getQuantidade() + item.getQuantidade();
            existente.setQuantidade(Math.min(novaQtd, existente.getDisponivelMax()));
        } else {
            itens.put(chave, item);
        }
    }

    public void remover(String chave) {
        itens.remove(chave);
    }

    public void atualizarQuantidade(String chave, int novaQuantidade) {
        ItemCarrinho item = itens.get(chave);
        if (item != null) {
            if (novaQuantidade <= 0) {
                itens.remove(chave);
            } else {
                item.setQuantidade(Math.min(novaQuantidade, item.getDisponivelMax()));
            }
        }
    }

    public void limpar() {
        itens.clear();
    }

    public List<ItemCarrinho> getItens() {
        return new ArrayList<>(itens.values());
    }

    public int getTotalItens() {
        return itens.values().stream().mapToInt(ItemCarrinho::getQuantidade).sum();
    }

    public BigDecimal getTotal() {
        return itens.values().stream()
                .map(ItemCarrinho::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public boolean isEmpty() {
        return itens.isEmpty();
    }

    public int size() {
        return itens.size();
    }

    /**
     * Retorna os IDs distintos dos restaurantes presentes no carrinho.
     */
    public Set<Long> getRestauranteIds() {
        return itens.values().stream()
                .map(ItemCarrinho::getRestauranteId)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    /**
     * Retorna os itens agrupados por restaurante (mantendo a ordem de inserção).
     */
    public Map<Long, List<ItemCarrinho>> getItensPorRestaurante() {
        return itens.values().stream()
                .collect(Collectors.groupingBy(ItemCarrinho::getRestauranteId,
                        LinkedHashMap::new, Collectors.toList()));
    }

    /**
     * Retorna o subtotal de um restaurante específico.
     */
    public BigDecimal getTotalRestaurante(Long restauranteId) {
        return itens.values().stream()
                .filter(i -> i.getRestauranteId().equals(restauranteId))
                .map(ItemCarrinho::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Retorna a quantidade de restaurantes distintos no carrinho.
     */
    public int getQuantidadeRestaurantes() {
        return getRestauranteIds().size();
    }
}
