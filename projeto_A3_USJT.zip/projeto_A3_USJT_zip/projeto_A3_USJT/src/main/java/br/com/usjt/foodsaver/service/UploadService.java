package br.com.usjt.foodsaver.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Set;
import java.util.UUID;

@Service
public class UploadService {

    private static final Set<String> TIPOS_PERMITIDOS = Set.of(
            "image/jpeg", "image/png", "image/gif", "image/webp");

    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    /**
     * Salva a imagem enviada e retorna o caminho relativo para uso em URLs
     * (ex: /uploads/produtos/abc123.jpg).
     * Retorna null se o arquivo estiver vazio.
     */
    public String salvar(MultipartFile arquivo, String subpasta) throws IOException {
        if (arquivo == null || arquivo.isEmpty()) {
            return null;
        }

        String contentType = arquivo.getContentType();
        if (contentType == null || !TIPOS_PERMITIDOS.contains(contentType)) {
            throw new IllegalArgumentException(
                    "Tipo de arquivo não permitido. Envie JPG, PNG, GIF ou WebP.");
        }

        String extensao = extrairExtensao(arquivo.getOriginalFilename());
        String nomeArquivo = UUID.randomUUID() + extensao;

        Path pasta = Paths.get(uploadDir, subpasta).toAbsolutePath().normalize();
        Files.createDirectories(pasta);

        Path destino = pasta.resolve(nomeArquivo);
        Files.copy(arquivo.getInputStream(), destino, StandardCopyOption.REPLACE_EXISTING);

        return "/uploads/" + subpasta + "/" + nomeArquivo;
    }

    /**
     * Remove o arquivo antigo, se existir.
     */
    public void remover(String urlAntiga) {
        if (urlAntiga == null || !urlAntiga.startsWith("/uploads/")) {
            return;
        }
        try {
            String caminhoRelativo = urlAntiga.substring("/uploads/".length());
            Path arquivo = Paths.get(uploadDir, caminhoRelativo).toAbsolutePath().normalize();
            Files.deleteIfExists(arquivo);
        } catch (IOException ignored) {
        }
    }

    private String extrairExtensao(String nomeOriginal) {
        if (nomeOriginal == null) return ".jpg";
        int ponto = nomeOriginal.lastIndexOf('.');
        return ponto >= 0 ? nomeOriginal.substring(ponto).toLowerCase() : ".jpg";
    }
}
