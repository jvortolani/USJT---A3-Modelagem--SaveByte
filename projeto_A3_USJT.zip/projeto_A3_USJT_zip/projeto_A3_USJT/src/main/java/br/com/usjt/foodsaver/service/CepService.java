package br.com.usjt.foodsaver.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CepService {

    private final RestTemplate restTemplate;

    public CepService() {
        this.restTemplate = new RestTemplate();
    }

    public EnderecoViaCep buscarEndereco(String cep) {
        String cepLimpo = cep.replaceAll("[^0-9]", "");
        String url = "https://viacep.com.br/ws/" + cepLimpo + "/json/";
        try {
            return restTemplate.getForObject(url, EnderecoViaCep.class);
        } catch (Exception e) {
            return null;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EnderecoViaCep {
        @JsonProperty("logradouro")
        private String logradouro;

        @JsonProperty("bairro")
        private String bairro;

        @JsonProperty("localidade")
        private String cidade;

        @JsonProperty("uf")
        private String estado;

        @JsonProperty("complemento")
        private String complemento;

        @JsonProperty("erro")
        private Boolean erro;

        public Boolean getErro() { return erro; }
        public void setErro(Boolean erro) { this.erro = erro; }

        public String getLogradouro() { return logradouro; }
        public void setLogradouro(String logradouro) { this.logradouro = logradouro; }

        public String getBairro() { return bairro; }
        public void setBairro(String bairro) { this.bairro = bairro; }

        public String getCidade() { return cidade; }
        public void setCidade(String cidade) { this.cidade = cidade; }

        public String getEstado() { return estado; }
        public void setEstado(String estado) { this.estado = estado; }

        public String getComplemento() { return complemento; }
        public void setComplemento(String complemento) { this.complemento = complemento; }
    }
}
