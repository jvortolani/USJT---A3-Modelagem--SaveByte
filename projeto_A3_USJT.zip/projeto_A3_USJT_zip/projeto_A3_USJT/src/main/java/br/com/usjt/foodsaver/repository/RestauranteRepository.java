package br.com.usjt.foodsaver.repository;

import br.com.usjt.foodsaver.model.Restaurante;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RestauranteRepository extends JpaRepository<Restaurante, Long> {

    Optional<Restaurante> findByEmail(String email);

    boolean existsByEmail(String email);

    List<Restaurante> findByNomeContainingIgnoreCaseOrCidadeContainingIgnoreCaseOrBairroContainingIgnoreCase(
            String nome, String cidade, String bairro);
}
