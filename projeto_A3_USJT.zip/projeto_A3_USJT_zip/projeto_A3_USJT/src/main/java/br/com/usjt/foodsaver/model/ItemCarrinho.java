package br.com.usjt.foodsaver.model;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Representa um item no carrinho de compras (armazenado na sessão).
 */
public class ItemCarrinho implements Serializable {

    private String tipo;          // "PRODUTO" ou "COMBO"
    private Long itemId;
    private String nome;
    private String restauranteNome;
    private Long restauranteId;
    private BigDecimal precoUnitario;
    private int quantidade;
    private int disponivelMax;
    private String imagemUrl;

    public ItemCarrinho() {}

    public ItemCarrinho(String tipo, Long itemId, String nome, String restauranteNome,
                        Long restauranteId, BigDecimal precoUnitario, int quantidade,
                        int disponivelMax, String imagemUrl) {
        this.tipo = tipo;
        this.itemId = itemId;
        this.nome = nome;
        this.restauranteNome = restauranteNome;
        this.restauranteId = restauranteId;
        this.precoUnitario = precoUnitario;
        this.quantidade = quantidade;
        this.disponivelMax = disponivelMax;
        this.imagemUrl = imagemUrl;
    }

    /** Chave única do item no carrinho. */
    public String getChave() {
        return tipo + "_" + itemId;
    }

    public BigDecimal getSubtotal() {
        return precoUnitario.multiply(BigDecimal.valueOf(quantidade));
    }

    // Getters e setters
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Long getItemId() { return itemId; }
    public void setItemId(Long itemId) { this.itemId = itemId; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getRestauranteNome() { return restauranteNome; }
    public void setRestauranteNome(String restauranteNome) { this.restauranteNome = restauranteNome; }

    public Long getRestauranteId() { return restauranteId; }
    public void setRestauranteId(Long restauranteId) { this.restauranteId = restauranteId; }

    public BigDecimal getPrecoUnitario() { return precoUnitario; }
    public void setPrecoUnitario(BigDecimal precoUnitario) { this.precoUnitario = precoUnitario; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    public int getDisponivelMax() { return disponivelMax; }
    public void setDisponivelMax(int disponivelMax) { this.disponivelMax = disponivelMax; }

    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
}
