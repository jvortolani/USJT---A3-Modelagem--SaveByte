package br.com.usjt.foodsaver.service;

import br.com.usjt.foodsaver.model.FormaPagamento;
import br.com.usjt.foodsaver.model.TipoEntrega;

import java.math.BigDecimal;

/**
 * Dados de entrega e pagamento informados na tela de checkout.
 * O número completo do cartão nunca é persistido: apenas os 4 últimos dígitos.
 */
public record DadosCheckout(TipoEntrega tipoEntrega,
                            String enderecoEntrega,
                            FormaPagamento formaPagamento,
                            String cartaoNumero,
                            String cartaoValidade,
                            String cartaoCvv,
                            BigDecimal valorDinheiro) {
}
