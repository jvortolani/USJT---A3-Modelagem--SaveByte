package br.com.usjt.foodsaver.controller;

import br.com.usjt.foodsaver.repository.ComboRepository;
import br.com.usjt.foodsaver.repository.ProdutoRepository;
import br.com.usjt.foodsaver.repository.RestauranteRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final RestauranteRepository restauranteRepository;
    private final ProdutoRepository produtoRepository;
    private final ComboRepository comboRepository;

    public HomeController(RestauranteRepository restauranteRepository,
                          ProdutoRepository produtoRepository,
                          ComboRepository comboRepository) {
        this.restauranteRepository = restauranteRepository;
        this.produtoRepository = produtoRepository;
        this.comboRepository = comboRepository;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("restaurantes", restauranteRepository.findAll());
        model.addAttribute("produtos", produtoRepository.findByAtivoTrueAndQuantidadeGreaterThan(0));
        model.addAttribute("combos", comboRepository.findByAtivoTrueAndQuantidadeGreaterThan(0));
        return "index";
    }
}
