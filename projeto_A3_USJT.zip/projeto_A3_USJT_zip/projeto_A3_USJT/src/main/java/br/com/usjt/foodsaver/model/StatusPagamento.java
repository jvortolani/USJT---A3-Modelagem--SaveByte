package br.com.usjt.foodsaver.model;

public enum StatusPagamento {
    PENDENTE("Pagamento pendente", "text-bg-warning"),
    PAGO("Pago", "text-bg-success"),
    ESTORNADO("Estornado", "text-bg-secondary");

    private final String descricao;
    private final String badgeClass;

    StatusPagamento(String descricao, String badgeClass) {
        this.descricao = descricao;
        this.badgeClass = badgeClass;
    }

    public String getDescricao() { return descricao; }
    public String getBadgeClass() { return badgeClass; }
}
