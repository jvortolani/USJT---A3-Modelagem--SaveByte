package br.com.usjt.foodsaver.repository;

import br.com.usjt.foodsaver.model.Pedido;
import br.com.usjt.foodsaver.model.StatusPedido;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findByClienteIdOrderByDataPedidoDesc(Long clienteId);

    List<Pedido> findByRestauranteIdOrderByDataPedidoDesc(Long restauranteId);

    long countByRestauranteId(Long restauranteId);

    long countByRestauranteIdAndStatus(Long restauranteId, StatusPedido status);
}
