package br.com.usjt.foodsaver.service;

import br.com.usjt.foodsaver.model.*;
import br.com.usjt.foodsaver.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final ClienteRepository clienteRepository;
    private final ProdutoRepository produtoRepository;
    private final ComboRepository comboRepository;

    public PedidoService(PedidoRepository pedidoRepository,
                         ClienteRepository clienteRepository,
                         ProdutoRepository produtoRepository,
                         ComboRepository comboRepository) {
        this.pedidoRepository = pedidoRepository;
        this.clienteRepository = clienteRepository;
        this.produtoRepository = produtoRepository;
        this.comboRepository = comboRepository;
    }

    /**
     * Cria um pedido de reserva para um produto ou combo.
     * Baixa o estoque no momento da reserva.
     */
    @Transactional
    public Pedido criar(Long clienteId, String tipo, Long itemId, int quantidade, String observacao,
                        DadosCheckout checkout) {
        if (quantidade <= 0) {
            throw new IllegalArgumentException("Quantidade inválida.");
        }

        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado."));

        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setDataPedido(LocalDateTime.now());
        pedido.setStatus(StatusPedido.PENDENTE);
        pedido.setObservacao(observacao == null || observacao.isBlank() ? null : observacao.trim());
        aplicarEntregaEPagamento(pedido, checkout);

        PedidoItem item = new PedidoItem();
        item.setPedido(pedido);
        item.setQuantidade(quantidade);

        if ("PRODUTO".equals(tipo)) {
            Produto produto = produtoRepository.findById(itemId)
                    .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado."));
            if (!produto.getAtivo() || produto.getQuantidade() < quantidade) {
                throw new IllegalArgumentException("Quantidade indisponível para este produto.");
            }
            produto.setQuantidade(produto.getQuantidade() - quantidade);
            produtoRepository.save(produto);

            item.setProduto(produto);
            item.setDescricao(produto.getNome());
            item.setPrecoUnitario(produto.getPrecoDesconto());
            pedido.setRestaurante(produto.getRestaurante());
        } else if ("COMBO".equals(tipo)) {
            Combo combo = comboRepository.findById(itemId)
                    .orElseThrow(() -> new IllegalArgumentException("Combo não encontrado."));
            if (!combo.getAtivo() || combo.getQuantidade() < quantidade) {
                throw new IllegalArgumentException("Quantidade indisponível para este combo.");
            }
            combo.setQuantidade(combo.getQuantidade() - quantidade);
            comboRepository.save(combo);

            item.setCombo(combo);
            item.setDescricao(combo.getNome());
            item.setPrecoUnitario(combo.getPreco());
            pedido.setRestaurante(combo.getRestaurante());
        } else {
            throw new IllegalArgumentException("Tipo de item inválido.");
        }

        pedido.setValorTotal(item.getPrecoUnitario().multiply(BigDecimal.valueOf(quantidade)));
        calcularTroco(pedido);
        pedido.getItens().add(item);
        return pedidoRepository.save(pedido);
    }

    /**
     * Cria um pedido a partir de uma lista de itens do carrinho (todos do mesmo restaurante).
     */
    @Transactional
    public Pedido criarDoCarrinhoItens(Long clienteId, List<ItemCarrinho> itensCarrinho,
                                       String observacao, DadosCheckout checkout) {
        if (itensCarrinho == null || itensCarrinho.isEmpty()) {
            throw new IllegalArgumentException("Carrinho vazio.");
        }

        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado."));

        Restaurante restaurante = null;
        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setDataPedido(LocalDateTime.now());
        pedido.setStatus(StatusPedido.PENDENTE);
        pedido.setObservacao(observacao == null || observacao.isBlank() ? null : observacao.trim());
        aplicarEntregaEPagamento(pedido, checkout);

        BigDecimal valorTotal = BigDecimal.ZERO;

        for (ItemCarrinho ic : itensCarrinho) {
            PedidoItem item = new PedidoItem();
            item.setPedido(pedido);
            item.setQuantidade(ic.getQuantidade());

            if ("PRODUTO".equals(ic.getTipo())) {
                Produto produto = produtoRepository.findById(ic.getItemId())
                        .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado: " + ic.getNome()));
                if (!produto.getAtivo() || produto.getQuantidade() < ic.getQuantidade()) {
                    throw new IllegalArgumentException("Quantidade indisponível para: " + produto.getNome());
                }
                produto.setQuantidade(produto.getQuantidade() - ic.getQuantidade());
                produtoRepository.save(produto);

                item.setProduto(produto);
                item.setDescricao(produto.getNome());
                item.setPrecoUnitario(produto.getPrecoDesconto());
                restaurante = produto.getRestaurante();
            } else if ("COMBO".equals(ic.getTipo())) {
                Combo combo = comboRepository.findById(ic.getItemId())
                        .orElseThrow(() -> new IllegalArgumentException("Combo não encontrado: " + ic.getNome()));
                if (!combo.getAtivo() || combo.getQuantidade() < ic.getQuantidade()) {
                    throw new IllegalArgumentException("Quantidade indisponível para: " + combo.getNome());
                }
                combo.setQuantidade(combo.getQuantidade() - ic.getQuantidade());
                comboRepository.save(combo);

                item.setCombo(combo);
                item.setDescricao(combo.getNome());
                item.setPrecoUnitario(combo.getPreco());
                restaurante = combo.getRestaurante();
            }

            valorTotal = valorTotal.add(item.getPrecoUnitario().multiply(BigDecimal.valueOf(ic.getQuantidade())));
            pedido.getItens().add(item);
        }

        pedido.setRestaurante(restaurante);
        pedido.setValorTotal(valorTotal);
        calcularTroco(pedido);
        return pedidoRepository.save(pedido);
    }

    /**
     * Valida e aplica os dados de entrega e pagamento.
     * Pix e cartao sao pagamentos simulados (aprovados na hora);
     * "na entrega" fica pendente ate o pedido ser entregue.
     */
    private void aplicarEntregaEPagamento(Pedido pedido, DadosCheckout checkout) {
        if (checkout == null || checkout.tipoEntrega() == null) {
            throw new IllegalArgumentException("Selecione a forma de entrega.");
        }
        if (checkout.formaPagamento() == null) {
            throw new IllegalArgumentException("Selecione a forma de pagamento.");
        }

        pedido.setTipoEntrega(checkout.tipoEntrega());
        if (checkout.tipoEntrega() == TipoEntrega.ENTREGA) {
            String endereco = checkout.enderecoEntrega();
            if (endereco == null || endereco.isBlank()) {
                throw new IllegalArgumentException("Informe o endereço de entrega.");
            }
            pedido.setEnderecoEntrega(endereco.trim());
        }

        pedido.setFormaPagamento(checkout.formaPagamento());
        switch (checkout.formaPagamento()) {
            case NA_ENTREGA -> {
                pedido.setStatusPagamento(StatusPagamento.PENDENTE);
                if (checkout.valorDinheiro() != null && checkout.valorDinheiro().compareTo(BigDecimal.ZERO) > 0) {
                    pedido.setValorDinheiro(checkout.valorDinheiro());
                }
            }
            case PIX -> pedido.setStatusPagamento(StatusPagamento.PAGO);
            case CARTAO -> {
                pedido.setCartaoFinal(validarCartao(checkout));
                pedido.setStatusPagamento(StatusPagamento.PAGO);
            }
        }
    }

    private void calcularTroco(Pedido pedido) {
        if (pedido.getValorDinheiro() != null && pedido.getValorDinheiro().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal troco = pedido.getValorDinheiro().subtract(pedido.getValorTotal());
            pedido.setTroco(troco.compareTo(BigDecimal.ZERO) >= 0 ? troco : BigDecimal.ZERO);
        }
    }

    private String validarCartao(DadosCheckout checkout) {
        String numero = checkout.cartaoNumero() == null ? "" : checkout.cartaoNumero().replaceAll("\\D", "");
        if (numero.length() < 13 || numero.length() > 19) {
            throw new IllegalArgumentException("Número do cartão inválido.");
        }
        String cvv = checkout.cartaoCvv() == null ? "" : checkout.cartaoCvv().trim();
        if (!cvv.matches("\\d{3,4}")) {
            throw new IllegalArgumentException("CVV inválido.");
        }
        String validade = checkout.cartaoValidade() == null ? "" : checkout.cartaoValidade().trim();
        if (!validade.matches("(0[1-9]|1[0-2])/\\d{2}")) {
            throw new IllegalArgumentException("Validade do cartão inválida. Use o formato MM/AA.");
        }
        YearMonth vencimento = YearMonth.of(2000 + Integer.parseInt(validade.substring(3)),
                Integer.parseInt(validade.substring(0, 2)));
        if (vencimento.isBefore(YearMonth.now())) {
            throw new IllegalArgumentException("Cartão vencido.");
        }
        return numero.substring(numero.length() - 4);
    }

    /**
     * Altera o status do pedido. Ao cancelar, devolve a quantidade ao estoque.
     */
    @Transactional
    public void alterarStatus(Long pedidoId, StatusPedido novoStatus) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("Pedido não encontrado."));

        if (pedido.getStatus() == StatusPedido.ENTREGUE || pedido.getStatus() == StatusPedido.CANCELADO) {
            throw new IllegalArgumentException("Este pedido já foi finalizado.");
        }
        if (novoStatus == StatusPedido.CANCELADO) {
            devolverEstoque(pedido);
            if (pedido.getStatusPagamento() == StatusPagamento.PAGO) {
                pedido.setStatusPagamento(StatusPagamento.ESTORNADO);
            }
        }
        if (novoStatus == StatusPedido.ENTREGUE && pedido.getStatusPagamento() == StatusPagamento.PENDENTE) {
            pedido.setStatusPagamento(StatusPagamento.PAGO);
        }
        pedido.setStatus(novoStatus);
        pedidoRepository.save(pedido);
    }

    private void devolverEstoque(Pedido pedido) {
        for (PedidoItem item : pedido.getItens()) {
            if (item.getProduto() != null) {
                Produto p = item.getProduto();
                p.setQuantidade(p.getQuantidade() + item.getQuantidade());
                produtoRepository.save(p);
            }
            if (item.getCombo() != null) {
                Combo c = item.getCombo();
                c.setQuantidade(c.getQuantidade() + item.getQuantidade());
                comboRepository.save(c);
            }
        }
    }
}
