package br.com.usjt.foodsaver.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Entity
@Table(name = "produto")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "restaurante_id")
    private Restaurante restaurante;

    @Column(nullable = false, length = 120)
    private String nome;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    private String categoria;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precoOriginal;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precoDesconto;

    @Column(nullable = false)
    private Integer quantidade = 0;

    @Column(nullable = false)
    private Boolean ativo = true;

    private String imagemUrl;

    @Column(nullable = false)
    private LocalDateTime criadoEm;

    @PrePersist
    public void prePersist() {
        this.criadoEm = LocalDateTime.now();
        if (this.ativo == null) this.ativo = true;
        if (this.quantidade == null) this.quantidade = 0;
    }

    public int getPercentualDesconto() {
        if (precoOriginal == null || precoDesconto == null || precoOriginal.signum() == 0) {
            return 0;
        }
        return precoOriginal.subtract(precoDesconto)
                .multiply(BigDecimal.valueOf(100))
                .divide(precoOriginal, 0, RoundingMode.DOWN)
                .intValue();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Restaurante getRestaurante() { return restaurante; }
    public void setRestaurante(Restaurante restaurante) { this.restaurante = restaurante; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public BigDecimal getPrecoOriginal() { return precoOriginal; }
    public void setPrecoOriginal(BigDecimal precoOriginal) { this.precoOriginal = precoOriginal; }

    public BigDecimal getPrecoDesconto() { return precoDesconto; }
    public void setPrecoDesconto(BigDecimal precoDesconto) { this.precoDesconto = precoDesconto; }

    public Integer getQuantidade() { return quantidade; }
    public void setQuantidade(Integer quantidade) { this.quantidade = quantidade; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }

    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }

    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
}
