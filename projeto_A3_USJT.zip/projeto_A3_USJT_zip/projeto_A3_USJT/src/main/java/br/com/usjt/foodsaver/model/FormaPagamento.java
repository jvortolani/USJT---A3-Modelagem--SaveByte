package br.com.usjt.foodsaver.model;

public enum FormaPagamento {
    NA_ENTREGA("Pagar na entrega/retirada"),
    PIX("Pix"),
    CARTAO("Cartão de crédito");

    private final String descricao;

    FormaPagamento(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() { return descricao; }
}
