package br.com.usjt.foodsaver.controller;

import br.com.usjt.foodsaver.model.*;
import br.com.usjt.foodsaver.repository.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/cliente/carrinho")
public class CarrinhoController {

    private final ProdutoRepository produtoRepository;
    private final ComboRepository comboRepository;

    public CarrinhoController(ProdutoRepository produtoRepository, ComboRepository comboRepository) {
        this.produtoRepository = produtoRepository;
        this.comboRepository = comboRepository;
    }

    /** Obtém ou cria o carrinho na sessão. */
    private Carrinho carrinho(HttpSession session) {
        Carrinho c = (Carrinho) session.getAttribute("carrinho");
        if (c == null) {
            c = new Carrinho();
            session.setAttribute("carrinho", c);
        }
        return c;
    }

    @GetMapping
    public String ver(HttpSession session, Model model) {
        model.addAttribute("carrinho", carrinho(session));
        return "cliente/carrinho";
    }

    @PostMapping("/adicionar")
    public String adicionar(@RequestParam String tipo,
                            @RequestParam Long itemId,
                            @RequestParam(defaultValue = "1") int quantidade,
                            HttpSession session,
                            RedirectAttributes ra) {
        Carrinho carrinho = carrinho(session);
        String redirectBack;

        if ("PRODUTO".equals(tipo)) {
            Produto p = produtoRepository.findById(itemId).filter(Produto::getAtivo).orElse(null);
            if (p == null) {
                ra.addFlashAttribute("erro", "Produto não encontrado.");
                return "redirect:/cliente/home";
            }

            if (quantidade <= 0 || quantidade > p.getQuantidade()) {
                ra.addFlashAttribute("erro", p.getQuantidade() <= 0
                        ? "Este produto está esgotado."
                        : "Quantidade indisponível. Máximo: " + p.getQuantidade() + ".");
                return "redirect:/cliente/restaurante/" + p.getRestaurante().getId();
            }

            carrinho.adicionar(new ItemCarrinho("PRODUTO", p.getId(), p.getNome(),
                    p.getRestaurante().getNome(), p.getRestaurante().getId(),
                    p.getPrecoDesconto(), quantidade, p.getQuantidade(), p.getImagemUrl()));
            redirectBack = "redirect:/cliente/restaurante/" + p.getRestaurante().getId();

        } else if ("COMBO".equals(tipo)) {
            Combo c = comboRepository.findById(itemId).filter(Combo::getAtivo).orElse(null);
            if (c == null) {
                ra.addFlashAttribute("erro", "Combo não encontrado.");
                return "redirect:/cliente/home";
            }

            if (quantidade <= 0 || quantidade > c.getQuantidade()) {
                ra.addFlashAttribute("erro", c.getQuantidade() <= 0
                        ? "Este combo está esgotado."
                        : "Quantidade indisponível. Máximo: " + c.getQuantidade() + ".");
                return "redirect:/cliente/restaurante/" + c.getRestaurante().getId();
            }

            carrinho.adicionar(new ItemCarrinho("COMBO", c.getId(), c.getNome(),
                    c.getRestaurante().getNome(), c.getRestaurante().getId(),
                    c.getPreco(), quantidade, c.getQuantidade(), c.getImagemUrl()));
            redirectBack = "redirect:/cliente/restaurante/" + c.getRestaurante().getId();

        } else {
            ra.addFlashAttribute("erro", "Tipo de item inválido.");
            return "redirect:/cliente/home";
        }

        ra.addFlashAttribute("sucesso", "Item adicionado ao carrinho!");
        return redirectBack;
    }

    @PostMapping("/atualizar")
    public String atualizar(@RequestParam String chave,
                            @RequestParam int quantidade,
                            HttpSession session,
                            RedirectAttributes ra) {
        carrinho(session).atualizarQuantidade(chave, quantidade);
        return "redirect:/cliente/carrinho";
    }

    @PostMapping("/remover")
    public String remover(@RequestParam String chave,
                          HttpSession session,
                          RedirectAttributes ra) {
        carrinho(session).remover(chave);
        ra.addFlashAttribute("sucesso", "Item removido do carrinho.");
        return "redirect:/cliente/carrinho";
    }

    @PostMapping("/limpar")
    public String limpar(HttpSession session, RedirectAttributes ra) {
        carrinho(session).limpar();
        ra.addFlashAttribute("sucesso", "Carrinho esvaziado.");
        return "redirect:/cliente/carrinho";
    }
}
