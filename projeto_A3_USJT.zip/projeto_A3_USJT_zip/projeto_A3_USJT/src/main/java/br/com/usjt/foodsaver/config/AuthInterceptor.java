package br.com.usjt.foodsaver.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Intercepta as rotas privadas e garante que apenas o perfil correto
 * (CLIENTE ou RESTAURANTE) acesse suas proprias telas.
 */
@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String uri = request.getRequestURI();
        HttpSession session = request.getSession(false);

        if (uri.startsWith("/cliente")) {
            if (session == null || session.getAttribute("clienteId") == null) {
                response.sendRedirect("/login");
                return false;
            }
        } else if (uri.startsWith("/restaurante")) {
            if (session == null || session.getAttribute("restauranteId") == null) {
                response.sendRedirect("/login");
                return false;
            }
        }
        return true;
    }
}
