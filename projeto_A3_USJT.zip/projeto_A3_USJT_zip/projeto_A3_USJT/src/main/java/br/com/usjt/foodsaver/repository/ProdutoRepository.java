package br.com.usjt.foodsaver.repository;

import br.com.usjt.foodsaver.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    List<Produto> findByRestauranteId(Long restauranteId);

    List<Produto> findByRestauranteIdAndAtivoTrue(Long restauranteId);

    List<Produto> findByAtivoTrueAndQuantidadeGreaterThan(int quantidade);

    List<Produto> findByAtivoTrueAndNomeContainingIgnoreCaseOrAtivoTrueAndDescricaoContainingIgnoreCase(
            String nome, String descricao);

    long countByRestauranteId(Long restauranteId);
}
