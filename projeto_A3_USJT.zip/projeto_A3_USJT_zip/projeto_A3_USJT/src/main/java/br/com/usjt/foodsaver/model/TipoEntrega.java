package br.com.usjt.foodsaver.model;

public enum TipoEntrega {
    RETIRADA("Retirada no local"),
    ENTREGA("Entrega a domicílio");

    private final String descricao;

    TipoEntrega(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() { return descricao; }
}
