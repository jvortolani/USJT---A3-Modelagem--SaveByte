-- ============================================================================
-- SaveByte - Projeto A3 (USJT)
-- Script de criacao do banco de dados MySQL
--
-- COMO USAR (migracao para outro computador):
--   1. Abra o MySQL Workbench (ou o cliente MySQL de sua preferencia)
--   2. Execute este arquivo inteiro (icone de raio / "Execute")
--   3. Pronto: o banco "savebyte" e todas as tabelas serao criados
--
-- Este script pode ser executado mais de uma vez: ele apaga e recria
-- as tabelas. Para preservar dados existentes, remova as linhas DROP.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS savebyte
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE savebyte;

-- ----------------------------------------------------------------------------
-- Remocao das tabelas (ordem inversa das chaves estrangeiras)
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS pedido_item;
DROP TABLE IF EXISTS pedido;
DROP TABLE IF EXISTS combo_item;
DROP TABLE IF EXISTS combo;
DROP TABLE IF EXISTS produto;
DROP TABLE IF EXISTS restaurante;
DROP TABLE IF EXISTS cliente;

-- ----------------------------------------------------------------------------
-- CLIENTE: usuario que busca e reserva alimentos
-- ----------------------------------------------------------------------------
CREATE TABLE cliente (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    nome        VARCHAR(120) NOT NULL,
    email       VARCHAR(120) NOT NULL,
    senha       VARCHAR(60)  NOT NULL COMMENT 'Hash BCrypt da senha',
    telefone    VARCHAR(20)  NULL,
    endereco    VARCHAR(200) NULL,
    bairro      VARCHAR(80)  NULL,
    cidade      VARCHAR(80)  NULL,
    estado      CHAR(2)      NULL,
    cep         VARCHAR(10)  NULL,
    criado_em   DATETIME     NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_cliente_email (email)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- RESTAURANTE: estabelecimento que cadastra produtos e combos
-- ----------------------------------------------------------------------------
CREATE TABLE restaurante (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    nome        VARCHAR(120) NOT NULL COMMENT 'Nome fantasia',
    cnpj        VARCHAR(18)  NULL,
    email       VARCHAR(120) NOT NULL,
    senha       VARCHAR(60)  NOT NULL COMMENT 'Hash BCrypt da senha',
    telefone    VARCHAR(20)  NULL,
    endereco    VARCHAR(200) NULL COMMENT 'Rua / avenida',
    numero      VARCHAR(10)  NULL,
    complemento VARCHAR(80)  NULL,
    bairro      VARCHAR(80)  NULL,
    cidade      VARCHAR(80)  NULL,
    estado      CHAR(2)      NULL,
    cep         VARCHAR(10)  NULL,
    descricao   TEXT         NULL,
    imagem_url  VARCHAR(500) NULL COMMENT 'URL opcional de foto/logo',
    criado_em   DATETIME     NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_restaurante_email (email)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- PRODUTO: item avulso vendido com desconto (ex.: pao do dia, marmita)
-- preco_original  -> valor normal de venda
-- preco_desconto  -> valor promocional (evita o desperdicio)
-- ----------------------------------------------------------------------------
CREATE TABLE produto (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    restaurante_id BIGINT        NOT NULL,
    nome           VARCHAR(120)  NOT NULL,
    descricao      TEXT          NULL,
    categoria      VARCHAR(50)   NULL,
    preco_original DECIMAL(10,2) NOT NULL,
    preco_desconto DECIMAL(10,2) NOT NULL,
    quantidade     INT           NOT NULL DEFAULT 0 COMMENT 'Estoque disponivel',
    ativo          TINYINT(1)    NOT NULL DEFAULT 1,
    imagem_url     VARCHAR(500)  NULL,
    criado_em      DATETIME      NOT NULL,
    PRIMARY KEY (id),
    KEY fk_produto_restaurante (restaurante_id),
    CONSTRAINT fk_produto_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- COMBO: "caixa surpresa" - conjunto de produtos vendidos junto por um preco
-- ----------------------------------------------------------------------------
CREATE TABLE combo (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    restaurante_id BIGINT        NOT NULL,
    nome           VARCHAR(120)  NOT NULL,
    descricao      TEXT          NULL,
    preco          DECIMAL(10,2) NOT NULL,
    quantidade     INT           NOT NULL DEFAULT 0 COMMENT 'Combos disponiveis',
    ativo          TINYINT(1)    NOT NULL DEFAULT 1,
    imagem_url     VARCHAR(500)  NULL,
    criado_em      DATETIME      NOT NULL,
    PRIMARY KEY (id),
    KEY fk_combo_restaurante (restaurante_id),
    CONSTRAINT fk_combo_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- COMBO_ITEM: produtos que compoem um combo (N:N entre combo e produto)
-- ----------------------------------------------------------------------------
CREATE TABLE combo_item (
    id         BIGINT NOT NULL AUTO_INCREMENT,
    combo_id   BIGINT NOT NULL,
    produto_id BIGINT NOT NULL,
    quantidade INT    NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY fk_ci_combo (combo_id),
    KEY fk_ci_produto (produto_id),
    CONSTRAINT fk_ci_combo FOREIGN KEY (combo_id)
        REFERENCES combo (id),
    CONSTRAINT fk_ci_produto FOREIGN KEY (produto_id)
        REFERENCES produto (id)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- PEDIDO: reserva feita pelo cliente (retirada no local)
-- status: PENDENTE -> CONFIRMADO -> ENTREGUE  (ou CANCELADO)
-- ----------------------------------------------------------------------------
CREATE TABLE pedido (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    cliente_id     BIGINT        NOT NULL,
    restaurante_id BIGINT        NOT NULL,
    data_pedido    DATETIME      NOT NULL,
    status         ENUM('PENDENTE','CONFIRMADO','ENTREGUE','CANCELADO')
                   NOT NULL DEFAULT 'PENDENTE',
    valor_total    DECIMAL(10,2) NOT NULL,
    observacao     VARCHAR(500)  NULL,
    tipo_entrega   ENUM('RETIRADA','ENTREGA') NULL COMMENT 'Retirada no local ou entrega',
    endereco_entrega VARCHAR(300) NULL COMMENT 'Preenchido apenas quando tipo_entrega = ENTREGA',
    forma_pagamento ENUM('NA_ENTREGA','PIX','CARTAO') NULL,
    status_pagamento ENUM('PENDENTE','PAGO','ESTORNADO') NULL,
    cartao_final   VARCHAR(4)    NULL COMMENT 'Somente os 4 ultimos digitos do cartao',
    valor_dinheiro DECIMAL(10,2) NULL COMMENT 'Valor em dinheiro informado pelo cliente',
    troco          DECIMAL(10,2) NULL COMMENT 'Troco calculado (valor_dinheiro - valor_total)',
    PRIMARY KEY (id),
    KEY fk_pedido_cliente (cliente_id),
    KEY fk_pedido_restaurante (restaurante_id),
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (cliente_id)
        REFERENCES cliente (id),
    CONSTRAINT fk_pedido_restaurante FOREIGN KEY (restaurante_id)
        REFERENCES restaurante (id)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- PEDIDO_ITEM: item do pedido. Aponta para produto OU combo (o outro fica NULL)
-- ----------------------------------------------------------------------------
CREATE TABLE pedido_item (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    pedido_id      BIGINT        NOT NULL,
    produto_id     BIGINT        NULL,
    combo_id       BIGINT        NULL,
    descricao      VARCHAR(200)  NOT NULL COMMENT 'Nome do item na data do pedido',
    quantidade     INT           NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL COMMENT 'Preco praticado na data do pedido',
    PRIMARY KEY (id),
    KEY fk_pi_pedido (pedido_id),
    KEY fk_pi_produto (produto_id),
    KEY fk_pi_combo (combo_id),
    CONSTRAINT fk_pi_pedido FOREIGN KEY (pedido_id)
        REFERENCES pedido (id),
    CONSTRAINT fk_pi_produto FOREIGN KEY (produto_id)
        REFERENCES produto (id),
    CONSTRAINT fk_pi_combo FOREIGN KEY (combo_id)
        REFERENCES combo (id)
) ENGINE = InnoDB;

-- ============================================================================
-- DADOS DE EXEMPLO
-- Nao e necessario inserir nada aqui: ao subir a aplicacao pela primeira vez,
-- o Spring Boot cria automaticamente dados de demonstracao:
--   Cliente:     cliente@teste.com     / senha: 123456
--   Restaurante: restaurante@teste.com / senha: 123456
-- ============================================================================
